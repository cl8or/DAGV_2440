if False:
    from typing import Dict, List, Tuple, Union, Optional

def positionAlongCurve():
    """
    Space selected objects along selected curve by its parameterization.
    Rebuilding the curve to even parameterization will space the objects evenly.
    """
    pass

