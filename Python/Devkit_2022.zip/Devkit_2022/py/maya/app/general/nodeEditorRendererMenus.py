if False:
    from typing import Dict, List, Tuple, Union, Optional

def addMrShaderMenuItems(ned, node):
    """
    Check for mental ray shader node and create necessary menu items
    """
    pass
def _addMrLightShaderMenuItems(ned, node):
    """
    Check for mental ray light shader node and create necessary menu items
    """
    pass
def _addMrTextureShaderMenuItems(ned, node):
    """
    Check for mental ray texture shader node and create necessary menu items
    """
    pass
def _isClassified(node, classification): pass
def _createMrLightShaderMenuItems(node):
    """
    Create node item marking menu items specific to mental ray light shader nodes
    """
    pass
def _createMrTextureShaderMenuItems(node):
    """
    Create node item marking menu items specific to mental ray texture shader nodes
    """
    pass


customMrNodeItemMenuCallbacks = []


