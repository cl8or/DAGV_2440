from PySide2.QtCore import *
from PySide2.QtWidgets import *
from PySide2.QtGui import *


if False:
    from typing import Dict, List, Tuple, Union, Optional

def show(): pass
def doNotShowChanged(): pass

