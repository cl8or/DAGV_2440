if False:
    from typing import Dict, List, Tuple, Union, Optional

def displayError(strId, arg1='None', arg2='None'):
    """
    # Display an error defined by a stringId.
    """
    pass
def __getMessage(strId, arg1, arg2):
    """
    # Internal method to get a message from the stringId
    """
    pass
def displayWarning(strId, arg1='None', arg2='None'):
    """
    # Display a warning defined by a stringId.
    """
    pass


gMsgTable = []


