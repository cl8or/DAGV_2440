if False:
    from typing import Dict, List, Tuple, Union, Optional

def createRig(basename="'stereoCameraHier'"):
    """
    Creates a new stereo rig. Uses a series of Maya commands to build
    a stereo rig.
    The optionnal argument basename defines the base name for each DAG
    object that will be created.
    """
    pass
def registerThisRig():
    """
    Registers the rig in Maya's database
    """
    pass

