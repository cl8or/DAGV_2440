from PySide2.QtCore import Slot


if False:
    from typing import Dict, List, Tuple, Union, Optional

def wrapInstance(*args, **kwargs): pass
def unwrapInstance(*args, **kwargs): pass

