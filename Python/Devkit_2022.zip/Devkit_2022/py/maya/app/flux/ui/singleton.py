if False:
    from typing import Dict, List, Tuple, Union, Optional

nameCounters = {}


