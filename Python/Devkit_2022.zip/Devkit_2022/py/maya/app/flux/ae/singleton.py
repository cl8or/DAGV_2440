if False:
    from typing import Dict, List, Tuple, Union, Optional

registeredTemplates = {}

customInstances = {}

registeredFuncs = set()


