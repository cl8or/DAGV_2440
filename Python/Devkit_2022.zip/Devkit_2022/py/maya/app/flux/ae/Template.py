if False:
    from typing import Dict, List, Tuple, Union, Optional

class Template(object):
    def __init__(self, nodeName): pass
    def addCustom(self, obj): pass
    def suppress(self, control): pass
    def suppressAll(self): pass
    __dict__ = None
    
    
    __weakref__ = None



