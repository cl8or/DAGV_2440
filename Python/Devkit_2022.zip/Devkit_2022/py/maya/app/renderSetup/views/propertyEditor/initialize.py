from maya.app.renderSetup.views.propertyEditor.basicCollection import BasicCollection
from maya.app.renderSetup.views.propertyEditor.staticCollection import StaticCollection


if False:
    from typing import Dict, List, Tuple, Union, Optional

def initialize(): pass
def uninitialize(): pass


_collectionEntries = {}

_selectorEntries = {}


