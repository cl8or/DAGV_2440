"""
# This file exists only to work around a localization script limitation.
# As of April 2016, the script requires that files with localized
# strings have unique names.
"""


if False:
    from typing import Dict, List, Tuple, Union, Optional

kOverrideWarningStr = []

kAOVs = []

kRelative = []

kFilterShaders = []

kCollectionWarningStr = []

kFilterSets = []

kSetRenderableAction = []

kCreateRenderSettingsChildCollectionAction = []

kCreateConnectionOverrideAction = []

kSelectionTypeError = []

kExpandCollapseAction = []

kConnectionType = []

kRenderSettings = []

kRenameAction = []

kCameras = []

kNewFilter = []

kRenderLayerWarningStr = []

kCreateCollectionAction = []

kCreateAbsoluteOverrideAction = []

kFilterTransformsAndShapes = []

kFilterCustom = []

kCreateShaderOverrideAction = []

kDragAndDrop = []

kMaterialType = []

kFilterAll = []

kNoOverride = []

kLights = []

kFilterCameras = []

kFullyExpandCollapseAction = []

kSetLocalRender = []

kAbsoluteType = []

kFilterLights = []

kFilterTransformsShapesShaders = []

kCreateMaterialOverrideAction = []

kCreateRelativeOverrideAction = []

kShaderType = []

kDeleteAction = []

kFiltersMenu = []

kAbsolute = []

kSetVisibilityAction = []

kDragAndDropFailed = []

kFilterTransforms = []

kFilterGeometry = []

kSetEnabledAction = []

kRelativeType = []

kSetIsolateSelectedAction = []


