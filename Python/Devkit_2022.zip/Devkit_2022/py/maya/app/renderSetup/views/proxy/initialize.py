if False:
    from typing import Dict, List, Tuple, Union, Optional

def uninitialize(): pass
def initialize(): pass


_entries = {}


