if False:
    from typing import Dict, List, Tuple, Union, Optional

kNbObjects = []

kSelectAllTooltip = []

kViewAll = []

kViewAllTooltip = []

kSelectAll = []

kViewCollectionObjects = []

kDragAttributesFromAE = []

kOK = []

kAddOverride = []

kRelativeWarning = []

kAddOverrideTooltipStr = []


