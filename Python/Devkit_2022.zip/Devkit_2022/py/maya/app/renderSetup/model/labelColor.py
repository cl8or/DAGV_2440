if False:
    from typing import Dict, List, Tuple, Union, Optional

class LabelColor(object):
    """
    The class adds the support to the label color dynamic attribute.
    """
    
    
    
    def __init__(self): pass
    def getLabelColor(self): pass
    def setLabelColor(self, string): pass
    __dict__ = None
    
    
    __weakref__ = None




_LABEL_COLOR_ATTRIBUTE_SHORT_NAME = 'lc'


