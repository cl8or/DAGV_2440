if False:
    from typing import Dict, List, Tuple, Union, Optional

class Node(object):
    def __eq__(self, o): pass
    def __hash__(self): pass
    def __init__(self, obj): pass
    def object(self): pass
    __dict__ = None
    
    
    __weakref__ = None


class Selection(object):
    """
    Selection of nodes (MObject) and paths (MDagPath). Behaves like a set.
    """
    
    
    
    def __contains__(self, item): pass
    def __init__(self, items='None'): pass
    def add(self, item): pass
    def clear(self): pass
    def dagNodes(self): pass
    def hierarchy(self): pass
    def ls(self, patterns): pass
    def names(self, allPaths='True'): pass
    def nodes(self): pass
    def nonDagNodes(self): pass
    def paths(self): pass
    def sets(self): pass
    def shapes(self): pass
    def update(self, items): pass
    __dict__ = None
    
    
    __weakref__ = None




def createNameFilter(expressions): pass
def createProgram(e): pass

