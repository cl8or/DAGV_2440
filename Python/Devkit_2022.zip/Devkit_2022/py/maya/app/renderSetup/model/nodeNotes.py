if False:
    from typing import Dict, List, Tuple, Union, Optional

class NodeNotes(object):
    """
    The class adds the support to the notes dynamic attribute.
    """
    
    
    
    def __init__(self): pass
    def getNotes(self): pass
    def setNotes(self, string): pass
    __dict__ = None
    
    
    __weakref__ = None




_NOTES_ATTRIBUTE_SHORT_NAME = 'nts'


