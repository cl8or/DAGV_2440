if False:
    from typing import Dict, List, Tuple, Union, Optional

def exportFileNoLabelColor(filename): pass
def importFileNoLabelColor(filename): pass
def exportFile(filename, includeSceneSettings='True'): pass
def exportFileNoRenderSettings(filename): pass
def readFile(file):
    """
    Returns a list of the lines in the argument file.
    """
    pass
def importFile(filename):
    """
    # Cannot name function "import", as this is a reserved Python keyword.
    """
    pass

