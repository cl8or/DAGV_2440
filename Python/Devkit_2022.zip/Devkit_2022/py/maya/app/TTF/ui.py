from maya.app.flux.ui.core import dpi
from PySide2.QtCore import Slot
from maya.app.flux.ui.core import pix


if False:
    from typing import Dict, List, Tuple, Union, Optional

def wrapInstance(*args, **kwargs): pass
def unwrapInstance(*args, **kwargs): pass
def lineEditStyleSheet(): pass
def adjustPosition(window): pass
def resultsListStyleSheet(): pass
def getColoredCircle(color, width='14', height='14'): pass
def getColoredXshape(color): pass
def windowStyleSheet(): pass
def fixTTFIconScaling(pixmap): pass


colors = {}


