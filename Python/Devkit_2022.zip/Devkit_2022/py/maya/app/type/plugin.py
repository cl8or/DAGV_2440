if False:
    from typing import Dict, List, Tuple, Union, Optional

def removeAnimCallback(): pass
def animCurveEdited(objs, clientData): pass
def register(): pass
def registerAnimCallback(): pass
def deregister(): pass
def getAnimCallbackOption(): pass
def setAnimCallbackOption(enabled): pass


animCallback = None


