if False:
    from typing import Dict, List, Tuple, Union, Optional

def setViewTransform(editor, optionMenuPath, cmdName):
    """
    # Purpose: Sets the viewTransformName used by the Editor
    """
    pass
def toggleCM(editor, buttonPath, cmdName):
    """
    # Purpose: Toggles the color management in the editor
    """
    pass
def updateGamma(editor, floatFieldPath, cmdName):
    """
    # Purpose: Updates the gamma of the Editor
    """
    pass
def updateExposure(editor, floatFieldPath, cmdName):
    """
    # Purpose: Updates the exposure of the Editor
    """
    pass
def __runCommand(cmdName, parameterContent): pass
def syncGammaField(editor, floatFieldPath, cmdName):
    """
    # Purpose: Synchronizes the gamma of the editor with a floatField
    """
    pass
def syncExposureField(editor, floatFieldPath, cmdName):
    """
    # Purpose: Synchronizes the exposure of the editor with a floatField
    """
    pass

