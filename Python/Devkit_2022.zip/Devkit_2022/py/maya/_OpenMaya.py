if False:
    from typing import Dict, List, Tuple, Union, Optional

def MPlug_setChar(*args, **kwargs): pass
def MDataHandle_asFloat(*args, **kwargs): pass
def MCameraSetMessage_swigregister(*args, **kwargs): pass
def MIteratorType_filterListEnabled(*args, **kwargs): pass
def MSyntax_setMinObjects(*args, **kwargs): pass
def MCurveAttribute_setCurve(*args, **kwargs): pass
def MDataHandle_isGeneric(*args, **kwargs): pass
def MDGMessage_addTimeChangeCallback(*args, **kwargs): pass
def MFnCamera_farFocusDistance(*args, **kwargs): pass
def MArrayDataBuilder_addElementArray(*args, **kwargs): pass
def MFnCompoundAttribute_addChild(*args, **kwargs): pass
def MSyntax_minObjects(*args, **kwargs): pass
def MFnCamera_computeDepthOfField(*args, **kwargs): pass
def MVector_x_set(*args, **kwargs): pass
def MDataBlock_className(*args, **kwargs): pass
def MArgList_asDistance(*args, **kwargs): pass
def delete_MFnNurbsCurveData(*args, **kwargs): pass
def MFnCamera_setMotionBlur(*args, **kwargs): pass
def MStreamUtils_readDouble(*args, **kwargs): pass
def MVector___isub__(*args, **kwargs): pass
def MArgDatabase_swigregister(*args, **kwargs): pass
def MDagPath_isVisible(*args, **kwargs): pass
def MFnCamera_isMotionBlur(*args, **kwargs): pass
def delete_MSetAttrEdit(*args, **kwargs): pass
def delete_MCommandMessage(*args, **kwargs): pass
def MFnSubd_className(*args, **kwargs): pass
def MFnAmbientLight_type(*args, **kwargs): pass
def MVectorArray_clear(*args, **kwargs): pass
def MPoint___add__(*args, **kwargs): pass
def MFloatVector___iadd__(*args, **kwargs): pass
def new_MFnSubdData(*args, **kwargs): pass
def MFnCamera_shutterAngle(*args, **kwargs): pass
def MFnCamera_setCenterOfInterest(*args, **kwargs): pass
def MSelectionList_getDagPath(*args, **kwargs): pass
def MMessageNode_fServerPtr_get(*args, **kwargs): pass
def delete_MFnSet(*args, **kwargs): pass
def MUserData_className(*args, **kwargs): pass
def new_MPlug(*args, **kwargs): pass
def MSceneMessage_addCheckCallback(*args, **kwargs): pass
def MFnSubd_copy(*args, **kwargs): pass
def MItMeshVertex_numUVs(*args, **kwargs): pass
def MFnStringArrayData_swigregister(*args, **kwargs): pass
def MDataHandle_setBool(*args, **kwargs): pass
def MFnMesh_copy(*args, **kwargs): pass
def MFnDagNode_removeChildAt(*args, **kwargs): pass
def array3dDouble_get(*args, **kwargs): pass
def MAttributePatternArray_assign(*args, **kwargs): pass
def MFnLayeredShader_hardwareShader(*args, **kwargs): pass
def MUintArray_swigregister(*args, **kwargs): pass
def MIffFile_getChunk(*args, **kwargs): pass
def MPlug_asFloat(*args, **kwargs): pass
def MRenderPassRegistry_getRenderPassDefinition(*args, **kwargs): pass
def new_MFnSingleIndexedComponent(*args, **kwargs): pass
def new_MFnMessageAttribute(*args, **kwargs): pass
def MFnMesh_getRawDoublePoints(*args, **kwargs): pass
def MPlug_numElements(*args, **kwargs): pass
def MRampAttribute_getColorAtPosition(*args, **kwargs): pass
def MCacheConfigRuleRegistry_className(*args, **kwargs): pass
def MFnDagNode_hasParent(*args, **kwargs): pass
def MFnMatrixArrayData_set(*args, **kwargs): pass
def delete_MFnAssembly(*args, **kwargs): pass
def MUint64Array___delitem__(*args, **kwargs): pass
def delete_doublePtr(*args, **kwargs): pass
def MDistance_className(*args, **kwargs): pass
def MGlobal_upAxis(*args, **kwargs): pass
def MAttributePatternArray_remove(*args, **kwargs): pass
def MFnReference_isExportEditsFile(*args, **kwargs): pass
def MRampAttribute_getEntries(*args, **kwargs): pass
def new_MBoundingBox(*args, **kwargs): pass
def MFnLayeredShader_setHardwareShader(*args, **kwargs): pass
def MItGeometry_allPositions(*args, **kwargs): pass
def intPtr_frompointer(*args, **kwargs): pass
def new_MPlugArray(*args, **kwargs): pass
def MGlobal_setTrackSelectionOrderEnabled(*args, **kwargs): pass
def MFileIO_currentFile(*args, **kwargs): pass
def MQuaternion_invertIt(*args, **kwargs): pass
def delete_MFnMatrixData(*args, **kwargs): pass
def MTime_swigregister(*args, **kwargs): pass
def MFnLatticeData_swigregister(*args, **kwargs): pass
def MTrimBoundaryArray_set(*args, **kwargs): pass
def new_MObjectHandle(*args, **kwargs): pass
def MFnCamera_unnormalizedFarClippingPlane(*args, **kwargs): pass
def MFnReflectShader_reflectedRayDepthLimit(*args, **kwargs): pass
def MQuaternion_get(*args, **kwargs): pass
def delete_MFnIntArrayData(*args, **kwargs): pass
def MFnCamera_aspectRatio(*args, **kwargs): pass
def MFnDagNode_parent(*args, **kwargs): pass
def MDataBlock_setClean(*args, **kwargs): pass
def MPointOnNurbs_swigregister(*args, **kwargs): pass
def MFnMesh_getNormals(*args, **kwargs): pass
def array4dInt_swigregister(*args, **kwargs): pass
def MItMeshEdge_isDone(*args, **kwargs): pass
def MPlug_asChar(*args, **kwargs): pass
def delete_MNodeMessage(*args, **kwargs): pass
def MFnVolumeLight_setLightShape(*args, **kwargs): pass
def MFnAssembly_getSubAssemblies(*args, **kwargs): pass
def MFnSubd_vertexEditsGetAllNonBase(*args, **kwargs): pass
def delete_uCharPtr(*args, **kwargs): pass
def MTransformationMatrix_assign(*args, **kwargs): pass
def MFnCamera_projectionMatrix(*args, **kwargs): pass
def MFnUnitAttribute_swigregister(*args, **kwargs): pass
def MEulerRotation___isub__(*args, **kwargs): pass
def MScriptUtil_getUintArrayItem(*args, **kwargs): pass
def MFnNurbsCurve_numSpans(*args, **kwargs): pass
def MAttributePattern_removeRootAttr(*args, **kwargs): pass
def MDagPath_fullPathName(*args, **kwargs): pass
def MItGeometry_next(*args, **kwargs): pass
def MFnDagNode_isInstancedAttribute(*args, **kwargs): pass
def MFnExpression_isAnimated(*args, **kwargs): pass
def MFnDependencyNode_getAffectedByAttributes(*args, **kwargs): pass
def MTimer_beginTimer(*args, **kwargs): pass
def MNamespace_makeNamepathAbsolute(*args, **kwargs): pass
def new_MFnUnitAttribute(*args, **kwargs): pass
def MFnAttribute_usesArrayDataBuilder(*args, **kwargs): pass
def MDataHandle_set3Float(*args, **kwargs): pass
def MPlane_normal(*args, **kwargs): pass
def MItEdits_fcurveEdit(*args, **kwargs): pass
def MFnNurbsSurface_numKnotsInU(*args, **kwargs): pass
def MAttributeSpecArray_setSizeIncrement(*args, **kwargs): pass
def MFnEnumAttribute_fieldIndex(*args, **kwargs): pass
def new_MFnDependencyNode(*args, **kwargs): pass
def MTime___ge__(*args, **kwargs): pass
def MComputation_endComputation(*args, **kwargs): pass
def MModelMessage_swigregister(*args, **kwargs): pass
def MItInstancer_nextInstancer(*args, **kwargs): pass
def MFnUInt64ArrayData_create(*args, **kwargs): pass
def MFnAttribute_isCached(*args, **kwargs): pass
def MDataHandle_setInt(*args, **kwargs): pass
def MDoubleArray_set(*args, **kwargs): pass
def MScriptUtil_asDouble3Ptr(*args, **kwargs): pass
def MAttributeSpecArray_assign(*args, **kwargs): pass
def MItDependencyNodes_isDone(*args, **kwargs): pass
def MFnNurbsSurface_setCV(*args, **kwargs): pass
def delete_MDGContext(*args, **kwargs): pass
def MFnDoubleIndexedComponent_className(*args, **kwargs): pass
def MFloatVector_x_set(*args, **kwargs): pass
def new_MPointOnMesh(*args, **kwargs): pass
def MMatrixArray_insert(*args, **kwargs): pass
def delete_MFnTypedAttribute(*args, **kwargs): pass
def MArgList_asBool(*args, **kwargs): pass
def MFnArrayAttrsData_intArray(*args, **kwargs): pass
def MFnDagNode_getAllPaths(*args, **kwargs): pass
def MDistance_asYards(*args, **kwargs): pass
def MScriptUtil_asUshortPtr(*args, **kwargs): pass
def MFnMesh_deleteColorSet(*args, **kwargs): pass
def MAttributeIndex_hasUpperBound(*args, **kwargs): pass
def MItDependencyGraph_prune(*args, **kwargs): pass
def MFileIO_beforeSaveUserFileTranslator(*args, **kwargs): pass
def MFnNurbsSurfaceData_className(*args, **kwargs): pass
def MFnCameraSet_getSortedIndices(*args, **kwargs): pass
def MFloatVector___truediv__(*args, **kwargs): pass
def MTesselationParams_assign(*args, **kwargs): pass
def MDagMessage_addAllDagChangesDagPathCallback(*args, **kwargs): pass
def MPlane_className(*args, **kwargs): pass
def MFnSubdNames_fromSelectionIndices(*args, **kwargs): pass
def MFnAreaLight_create(*args, **kwargs): pass
def MDataHandle_asDouble(*args, **kwargs): pass
def MCameraMessage_addBeginManipulationCallback(*args, **kwargs): pass
def new_MPolyMessage(*args, **kwargs): pass
def MArrayDataHandle_jumpToArrayElement(*args, **kwargs): pass
def MItDependencyGraph_isPruningOnFilter(*args, **kwargs): pass
def MFnContainerNode_getPublishedPlugs(*args, **kwargs): pass
def MPlug___ne__(*args, **kwargs): pass
def MFnNurbsCurve_normal(*args, **kwargs): pass
def MItInstancer_path(*args, **kwargs): pass
def MFloatVectorArray_remove(*args, **kwargs): pass
def MTesselationParams_setMinEdgeLength(*args, **kwargs): pass
def MMatrix_assign(*args, **kwargs): pass
def MFnLambertShader_setColor(*args, **kwargs): pass
def MFnSubdNames_path(*args, **kwargs): pass
def MFnNonExtendedLight_depthMapFilterSize(*args, **kwargs): pass
def MDGMessage_addDelayedTimeChangeCallback(*args, **kwargs): pass
def MFnMesh_setFaceVertexNormals(*args, **kwargs): pass
def MItDag_partialPathName(*args, **kwargs): pass
def new_MFnComponentListData(*args, **kwargs): pass
def MFnNurbsCurve_degree(*args, **kwargs): pass
def MFnCompoundAttribute_removeChild(*args, **kwargs): pass
def MFloatPoint_x_get(*args, **kwargs): pass
def MSyntax_maxObjects(*args, **kwargs): pass
def new_MCurveAttribute(*args, **kwargs): pass
def MScriptUtil_getUint(*args, **kwargs): pass
def MItSurfaceCV_getIndex(*args, **kwargs): pass
def MFnSubd_polygonGetCenterUV(*args, **kwargs): pass
def MFnDagNode_isIntermediateObject(*args, **kwargs): pass
def MFnNonAmbientLight_type(*args, **kwargs): pass
def MVector_x_get(*args, **kwargs): pass
def MDataBlock_swigregister(*args, **kwargs): pass
def MProfiler_getEventTime(*args, **kwargs): pass
def MArgList_asAngle(*args, **kwargs): pass
def MItCurveCV_hasHistoryOnCreate(*args, **kwargs): pass
def MFnNurbsCurveData_className(*args, **kwargs): pass
def delete_MFnComponentListData(*args, **kwargs): pass
def delete_MPointArray(*args, **kwargs): pass
def MFloatPoint___call__(*args, **kwargs): pass
def new_MStreamUtils(*args, **kwargs): pass
def MComputation_progress(*args, **kwargs): pass
def MItSubdVertex_level(*args, **kwargs): pass
def MFnSubd_edgeSetCrease(*args, **kwargs): pass
def MFnAnisotropyShader_setTangentUCamera(*args, **kwargs): pass
def MVector___sub__(*args, **kwargs): pass
def MItMeshFaceVertex_setIndex(*args, **kwargs): pass
def MPoint_y_get(*args, **kwargs): pass
def MFnNurbsSurface_assignUV(*args, **kwargs): pass
def MBoundingBox_depth(*args, **kwargs): pass
def MArgParser_className(*args, **kwargs): pass
def MInt64Array___eq__(*args, **kwargs): pass
def MFnNumericData_getData3Short(*args, **kwargs): pass
def MFnCamera_swigregister(*args, **kwargs): pass
def MFloatPointArray_setLength(*args, **kwargs): pass
def MCommandMessage_swigregister(*args, **kwargs): pass
def MItSubdEdge_swigregister(*args, **kwargs): pass
def MFnSubd_vertexIsValid(*args, **kwargs): pass
def MTimerMessage_swigregister(*args, **kwargs): pass
def delete_MFnAmbientLight(*args, **kwargs): pass
def MGlobal_disableStow(*args, **kwargs): pass
def MPoint___sub__(*args, **kwargs): pass
def MArgParser_flagArgumentInt(*args, **kwargs): pass
def MInt64Array_setLength(*args, **kwargs): pass
def MFnNumericAttribute_setMax(*args, **kwargs): pass
def MFnArrayAttrsData_vectorArray(*args, **kwargs): pass
def MFnComponent_weight(*args, **kwargs): pass
def MFloatMatrix___eq__(*args, **kwargs): pass
def MMessage_nodeCallbacks(*args, **kwargs): pass
def new_MItSelectionList(*args, **kwargs): pass
def MFnSubd_vertexEditsSetAllNonBase(*args, **kwargs): pass
def MFnLight_shadowColor(*args, **kwargs): pass
def MUuid_copy(*args, **kwargs): pass
def MItMeshVertex_translateBy(*args, **kwargs): pass
def MDAGDrawOverrideInfo_fPlaybackVisible_get(*args, **kwargs): pass
def MDGContext_swigregister(*args, **kwargs): pass
def MFnNumericAttribute_className(*args, **kwargs): pass
def MFnCamera_farClippingPlane(*args, **kwargs): pass
def MFloatArray_swigregister(*args, **kwargs): pass
def MMessageNode_fSubClientPtr_set(*args, **kwargs): pass
def MItMeshVertex_hasColor(*args, **kwargs): pass
def MURI_addQueryItem(*args, **kwargs): pass
def new_MFnSubd(*args, **kwargs): pass
def MPointArray_length(*args, **kwargs): pass
def MFnContainerNode_getRootTransform(*args, **kwargs): pass
def MUserData_swigregister(*args, **kwargs): pass
def MPoint_z_get(*args, **kwargs): pass
def MDagPathArray_sizeIncrement(*args, **kwargs): pass
def MPlug_asString(*args, **kwargs): pass
def MObject___eq__(*args, **kwargs): pass
def MImage_haveDepth(*args, **kwargs): pass
def MFnMesh_polyTriangulate(*args, **kwargs): pass
def MFnCamera_isDisplayGateMask(*args, **kwargs): pass
def MFloatArray_append(*args, **kwargs): pass
def MPointArray_remove(*args, **kwargs): pass
def MColor___eq__(*args, **kwargs): pass
def MItMeshVertex_setUV(*args, **kwargs): pass
def MFnStringData_type(*args, **kwargs): pass
def MFnMesh_closestIntersection(*args, **kwargs): pass
def MTimeArray_setLength(*args, **kwargs): pass
def MFnTransform_limitValue(*args, **kwargs): pass
def MURI_getAllQueryItemValues(*args, **kwargs): pass
def MDagModifier_reparentNode(*args, **kwargs): pass
def delete_MDoubleArray(*args, **kwargs): pass
def MPlug_setNumElements(*args, **kwargs): pass
def array4dDouble_set(*args, **kwargs): pass
def MImage_setPixels(*args, **kwargs): pass
def MFnComponentListData_type(*args, **kwargs): pass
def MFnMesh_stringBlindDataComponentId(*args, **kwargs): pass
def MFnCamera_setHorizontalRollPivot(*args, **kwargs): pass
def MFileObject_resolveMethod(*args, **kwargs): pass
def MFcurveEdit_fcurveName(*args, **kwargs): pass
def MColorArray_setSizeIncrement(*args, **kwargs): pass
def MItMeshPolygon_swigregister(*args, **kwargs): pass
def MFnSpotLight_setUseDecayRegions(*args, **kwargs): pass
def MFnMesh_numPolygons(*args, **kwargs): pass
def MTransformationMatrix_asScaleMatrix(*args, **kwargs): pass
def MFnTransform_rotatePivot(*args, **kwargs): pass
def MURI_setPort(*args, **kwargs): pass
def MDGModifier_newPlugValueMDistance(*args, **kwargs): pass
def MPlug_setMPxData(*args, **kwargs): pass
def MImageFileInfo_pixelType(*args, **kwargs): pass
def MFnMesh_displayColors(*args, **kwargs): pass
def MFnCamera_horizontalPan(*args, **kwargs): pass
def MFnMatrixData_transformation(*args, **kwargs): pass
def MAddRemoveAttrEdit_node(*args, **kwargs): pass
def MPointArray_copy(*args, **kwargs): pass
def MCallbackIdArray_setSizeIncrement(*args, **kwargs): pass
def MItMeshPolygon_isConnectedToFace(*args, **kwargs): pass
def MFnSphereData_swigregister(*args, **kwargs): pass
def MFnMesh_setSmoothMeshDisplayOptions(*args, **kwargs): pass
def new_MURI(*args, **kwargs): pass
def MDGModifier_connect(*args, **kwargs): pass
def MPlug_setKeyable(*args, **kwargs): pass
def MIffFile_beginGet(*args, **kwargs): pass
def MItMeshEdge_center(*args, **kwargs): pass
def MFnMesh_setVertexColors(*args, **kwargs): pass
def MFnCamera_setHorizontalFilmOffset(*args, **kwargs): pass
def MFileIO_getReferenceFileByNode(*args, **kwargs): pass
def MRenderPassRegistry_registerRenderPassDefinition(*args, **kwargs): pass
def MCacheFormatDescription_getChannelStartTime(*args, **kwargs): pass
def MItMeshPolygon_hasColor(*args, **kwargs): pass
def MFnSingleIndexedComponent_create(*args, **kwargs): pass
def MFnCamera_horizontalFilmOffset(*args, **kwargs): pass
def MFnMatrixData_matrix(*args, **kwargs): pass
def MFnMesh_getFaceVertexTangents(*args, **kwargs): pass
def MFnAssembly_deleteAllRepresentations(*args, **kwargs): pass
def MUintArray_copy(*args, **kwargs): pass
def MMeshSmoothOptions_openSubdivVertexBoundary(*args, **kwargs): pass
def MPlug_evaluateNumElements(*args, **kwargs): pass
def MGlobal_errorLoggingIsOn(*args, **kwargs): pass
def MFnMesh_getUvShellsIds(*args, **kwargs): pass
def MFnCamera_copyViewFrom(*args, **kwargs): pass
def MFileIO_beforeSaveFilename(*args, **kwargs): pass
def MRampAttribute_getValueAtPosition(*args, **kwargs): pass
def MFnUnitAttribute_setDefault(*args, **kwargs): pass
def MFnDagNode_activeColor(*args, **kwargs): pass
def MItMeshPolygon_getPoints(*args, **kwargs): pass
def MFnSet_clear(*args, **kwargs): pass
def MFnMatrixArrayData_array(*args, **kwargs): pass
def MFnAssembly_className(*args, **kwargs): pass
def MUint64Array___repr__(*args, **kwargs): pass
def doublePtr_assign(*args, **kwargs): pass
def MPlug_setAttribute(*args, **kwargs): pass
def MFnLambertShader_transparency(*args, **kwargs): pass
def MGlobal_displayInfo(*args, **kwargs): pass
def MCacheFormatDescription_setDistribution(*args, **kwargs): pass
def MMessage_registeringCallableScript(*args, **kwargs): pass
def MFnReference_ignoreReferenceEdits(*args, **kwargs): pass
def MFileIO_getFiles(*args, **kwargs): pass
def MRampAttribute_addEntries(*args, **kwargs): pass
def delete_MBoundingBox(*args, **kwargs): pass
def MItMeshFaceVertex_className(*args, **kwargs): pass
def MFnPointArrayData_set(*args, **kwargs): pass
def MFnLayeredShader_swigregister(*args, **kwargs): pass
def MFnDagNode_hiliteColor(*args, **kwargs): pass
def MTransformationMatrix_eulerRotation(*args, **kwargs): pass
def intPtr_swigregister(*args, **kwargs): pass
def delete_MPlugArray(*args, **kwargs): pass
def MGlobal_getPreselectionHiliteList(*args, **kwargs): pass
def MFnMesh_setInvisibleFaces(*args, **kwargs): pass
def MFnBlinnShader_swigregister(*args, **kwargs): pass
def MFileIO_setCurrentFile(*args, **kwargs): pass
def array4dDouble_get(*args, **kwargs): pass
def MQuaternion_log(*args, **kwargs): pass
def new_MAttributePatternArray(*args, **kwargs): pass
def MItMeshFaceVertex_faceVertex(*args, **kwargs): pass
def MFnMesh_isRightHandedTangent(*args, **kwargs): pass
def MFnPhongShader_setCosPower(*args, **kwargs): pass
def MFnLayeredShader_type(*args, **kwargs): pass
def MFnDagNode_instanceCount(*args, **kwargs): pass
def MTrimBoundaryArray_insert(*args, **kwargs): pass
def delete_MObjectHandle(*args, **kwargs): pass
def MGlobal_unselect(*args, **kwargs): pass
def MFnDependencyNode_getAffectedAttributes(*args, **kwargs): pass
def MFnMesh_getTangentId(*args, **kwargs): pass
def MFnDagNode_drawOverrideColor(*args, **kwargs): pass
def MFnReflectShader_setReflectedRayDepthLimit(*args, **kwargs): pass
def MEvaluationNode_dependencyNode(*args, **kwargs): pass
def MQuaternion___getitem__(*args, **kwargs): pass
def array4dFloat_swigregister(*args, **kwargs): pass
def MItMeshEdge_numConnectedFaces(*args, **kwargs): pass
def MFnPhongEShader_className(*args, **kwargs): pass
def MFnIntArrayData_className(*args, **kwargs): pass
def MEvaluationNode_dirtyPlug(*args, **kwargs): pass
def MTrimBoundaryArray_className(*args, **kwargs): pass
def MTransformationMatrix___eq__(*args, **kwargs): pass
def new_MDGMessage(*args, **kwargs): pass
def new_MObjectArray(*args, **kwargs): pass
def MGlobal_getAbsolutePathToResources(*args, **kwargs): pass
def MFnMesh_setNormals(*args, **kwargs): pass
def MFnLambertShader_setTransparency(*args, **kwargs): pass
def new_MEventMessage(*args, **kwargs): pass
def MScriptUtil_setUint2ArrayItem(*args, **kwargs): pass
def new_array2dFloat(*args, **kwargs): pass
def MItMeshEdge_next(*args, **kwargs): pass
def MTransformationMatrix_addRotation(*args, **kwargs): pass
def MFnNurbsSurface_clearUVs(*args, **kwargs): pass
def MFnGeometryData_matrixIsIdentity(*args, **kwargs): pass
def MFnDependencyNode_dgTimerOn(*args, **kwargs): pass
def MTransformationMatrix_setRotationOrientation(*args, **kwargs): pass
def MNodeMessage_swigregister(*args, **kwargs): pass
def MFnVolumeLight_volumeLightDirection(*args, **kwargs): pass
def MColorArray_get(*args, **kwargs): pass
def MFnSubd_edgeAdjacentPolygon(*args, **kwargs): pass
def MFnAttribute_swigregister(*args, **kwargs): pass
def MEulerRotation_closestSolution(*args, **kwargs): pass
def MScriptUtil_getShort3ArrayItem(*args, **kwargs): pass
def uCharPtr_assign(*args, **kwargs): pass
def MItInstancer_reset(*args, **kwargs): pass
def MFnNurbsSurface_getTrimBoundaries(*args, **kwargs): pass
def delete_MFnGenericAttribute(*args, **kwargs): pass
def MFnDependencyNode_setDoNotWrite(*args, **kwargs): pass
def MTransformationMatrix_asMatrix(*args, **kwargs): pass
def delete_MFnCompoundAttribute(*args, **kwargs): pass
def MNodeClass_hasAttribute(*args, **kwargs): pass
def MFnVectorArrayData_type(*args, **kwargs): pass
def MFnAttribute_setAffectsAppearance(*args, **kwargs): pass
def MDataHandle_setGenericInt(*args, **kwargs): pass
def MEulerRotation___neg__(*args, **kwargs): pass
def MScriptUtil_getUshortArrayItem(*args, **kwargs): pass
def MFnPhongEShader_highlightSize(*args, **kwargs): pass
def MAttributePattern_addRootAttr(*args, **kwargs): pass
def MItGeometry_position(*args, **kwargs): pass
def MCameraSetMessage_addCameraChangedCallback(*args, **kwargs): pass
def MFnExpression_setAnimated(*args, **kwargs): pass
def MFnDependencyNode_findPlug(*args, **kwargs): pass
def MTimer_endTimer(*args, **kwargs): pass
def MFnSubd_updateSubdSurface(*args, **kwargs): pass
def MNamespace_className(*args, **kwargs): pass
def MFnUnitAttribute_create(*args, **kwargs): pass
def MTransformationMatrix_rotationOrientation(*args, **kwargs): pass
def MDoubleArray___ne__(*args, **kwargs): pass
def MScriptUtil_getBool(*args, **kwargs): pass
def MAttributeSpec_setDimensions(*args, **kwargs): pass
def MItEdits_connectDisconnectEdit(*args, **kwargs): pass
def MFnNurbsSurface_numKnotsInV(*args, **kwargs): pass
def MFnEnumAttribute_getMin(*args, **kwargs): pass
def MFnDependencyNode_create(*args, **kwargs): pass
def MAttributeSpec_setName(*args, **kwargs): pass
def MTime___lt__(*args, **kwargs): pass
def MNamespace_addNamespace(*args, **kwargs): pass
def MFnSubd_edgeCreaseRelevant(*args, **kwargs): pass
def MFnUInt64ArrayData_swigregister(*args, **kwargs): pass
def MFnAttribute_isArray(*args, **kwargs): pass
def MDataHandle_setInt64(*args, **kwargs): pass
def MDoubleArray_setLength(*args, **kwargs): pass
def MScriptUtil_asDouble4Ptr(*args, **kwargs): pass
def MAttributeSpecArray_set(*args, **kwargs): pass
def MItDependencyNodes_item(*args, **kwargs): pass
def MFnNurbsSurface_formInU(*args, **kwargs): pass
def MFnMesh_getInvisibleFaces(*args, **kwargs): pass
def new_MFnDoubleIndexedComponent(*args, **kwargs): pass
def MFloatVector_x_get(*args, **kwargs): pass
def MPointOnMesh_getPoint(*args, **kwargs): pass
def MMatrixArray_append(*args, **kwargs): pass
def MFnTypedAttribute_className(*args, **kwargs): pass
def MEvaluationManager_evaluationInExecution(*args, **kwargs): pass
def MNamespace_swigregister(*args, **kwargs): pass
def MDataHandle_asMatrix(*args, **kwargs): pass
def MDistance_asMiles(*args, **kwargs): pass
def MScriptUtil_asFloatPtr(*args, **kwargs): pass
def MAttributeIndex_getLower(*args, **kwargs): pass
def MFloatPoint___eq__(*args, **kwargs): pass
def new_MFnNurbsSurfaceData(*args, **kwargs): pass
def MFnCameraSet_setLayerClearDepthValue(*args, **kwargs): pass
def MFloatVector___add__(*args, **kwargs): pass
def MDagMessage_addInstanceAddedCallback(*args, **kwargs): pass
def MMatrix_det4x4(*args, **kwargs): pass
def MCacheFormatDescription_getChannelSamplingRate(*args, **kwargs): pass
def MFnSubdNames_toSelectionIndices(*args, **kwargs): pass
def MFnAreaLight_swigregister(*args, **kwargs): pass
def MCameraMessage_addEndManipulationCallback(*args, **kwargs): pass
def delete_MPolyMessage(*args, **kwargs): pass
def MArrayDataHandle_setClean(*args, **kwargs): pass
def MItDependencyGraph_enablePruningOnFilter(*args, **kwargs): pass
def MDagPath_isTemplated(*args, **kwargs): pass
def MFnNurbsCurve_tangent(*args, **kwargs): pass
def MItMeshEdge_connectedToEdge(*args, **kwargs): pass
def MFnCameraSet_className(*args, **kwargs): pass
def MFloatVectorArray_insert(*args, **kwargs): pass
def MTesselationParams_setMaxEdgeLength(*args, **kwargs): pass
def MCurveAttribute_createCurve(*args, **kwargs): pass
def MMatrix___call__(*args, **kwargs): pass
def MFnCamera_isDisplayFilmGate(*args, **kwargs): pass
def MFnSubdNames_corner(*args, **kwargs): pass
def MFnNonExtendedLight_setDepthMapFilterSize(*args, **kwargs): pass
def MDataHandle_type(*args, **kwargs): pass
def MFnMesh_numUVSets(*args, **kwargs): pass
def MProfiler_isDataFromFile(*args, **kwargs): pass
def MArrayDataBuilder_elementCount(*args, **kwargs): pass
def MItDag_isInstanced(*args, **kwargs): pass
def MFnNurbsCurve_numCVs(*args, **kwargs): pass
def MFnCompoundAttribute_numChildren(*args, **kwargs): pass
def MItDag_willTraverseUnderWorld(*args, **kwargs): pass
def MCurveAttribute_assign(*args, **kwargs): pass
def MItSurfaceCV_cv(*args, **kwargs): pass
def MTransformationMatrix_addShear(*args, **kwargs): pass
def delete_MFnNonAmbientLight(*args, **kwargs): pass
def MVector_y_set(*args, **kwargs): pass
def new_MDGContext(*args, **kwargs): pass
def MProfiler_getEventDuration(*args, **kwargs): pass
def MArgList_asTime(*args, **kwargs): pass
def MItCurveCV_updateCurve(*args, **kwargs): pass
def new_MFnNurbsCurveData(*args, **kwargs): pass
def MFnComponentListData_className(*args, **kwargs): pass
def MCacheFormatDescription_swigregister(*args, **kwargs): pass
def MFloatPoint___getitem__(*args, **kwargs): pass
def delete_MStreamUtils(*args, **kwargs): pass
def MComputation_setProgressStatus(*args, **kwargs): pass
def MFnNurbsSurface_getCV(*args, **kwargs): pass
def MItSubdVertex_setLevel(*args, **kwargs): pass
def MFnSubd_edgeChildren(*args, **kwargs): pass
def MFnAnisotropyShader_tangentVCamera(*args, **kwargs): pass
def MFnSubdNames_baseFaceId(*args, **kwargs): pass
def MVector___mul__(*args, **kwargs): pass
def MPoint_z_set(*args, **kwargs): pass
def new_MCallbackIdArray(*args, **kwargs): pass
def MArgParser_swigregister(*args, **kwargs): pass
def MInt64Array___ne__(*args, **kwargs): pass
def MFnNumericData_getData3Int(*args, **kwargs): pass
def array4dDouble_swigregister(*args, **kwargs): pass
def MFnComponent_type(*args, **kwargs): pass
def MFloatPointArray_length(*args, **kwargs): pass
def MSetAttrEdit_plugName(*args, **kwargs): pass
def new_MItSubdFace(*args, **kwargs): pass
def MFnSubd_vertexIsCreased(*args, **kwargs): pass
def MFnMesh_renameUVSet(*args, **kwargs): pass
def MFnAmbientLight_className(*args, **kwargs): pass
def MVectorArray_setSizeIncrement(*args, **kwargs): pass
def MDagPath_childCount(*args, **kwargs): pass
def MPoint___iadd__(*args, **kwargs): pass
def MArgParser_flagArgumentDouble(*args, **kwargs): pass
def MInt64Array_length(*args, **kwargs): pass
def MFnNumericAttribute_setSoftMin(*args, **kwargs): pass
def MFnNurbsCurve_isPlanar(*args, **kwargs): pass
def MFnAssembly_activateNonRecursive(*args, **kwargs): pass
def MFloatMatrix___ne__(*args, **kwargs): pass
def MSelectionMask_intersects(*args, **kwargs): pass
def MMessage_setRegisteringCallableScript(*args, **kwargs): pass
def MFnSubd_vertexEditsClearAllNonBase(*args, **kwargs): pass
def MFnLight_setShadowColor(*args, **kwargs): pass
def MUuid_valid(*args, **kwargs): pass
def delete_MDAGDrawOverrideInfo(*args, **kwargs): pass
def MPointArray_insert(*args, **kwargs): pass
def MDistance_assign(*args, **kwargs): pass
def MAngle_uiUnit(*args, **kwargs): pass
def MIntArray_className(*args, **kwargs): pass
def MGlobal_setOptionVarValue(*args, **kwargs): pass
def MDistance_asFeet(*args, **kwargs): pass
def new_MFnNumericAttribute(*args, **kwargs): pass
def MURI_getQueryPairDelimiter(*args, **kwargs): pass
def new_MFloatMatrix(*args, **kwargs): pass
def MMessageNode_fSubClientPtr_get(*args, **kwargs): pass
def MItMeshVertex_getColor(*args, **kwargs): pass
def MFnNumericAttribute_createAddr(*args, **kwargs): pass
def MFnSubd_createBaseMesh(*args, **kwargs): pass
def MPoint_isEquivalent(*args, **kwargs): pass
def MFnContainerNode_getPublishedNodes(*args, **kwargs): pass
def MUserEventMessage_registerUserEvent(*args, **kwargs): pass
def MDagPathArray_className(*args, **kwargs): pass
def MObject___ne__(*args, **kwargs): pass
def MImage_convertPixelFormat(*args, **kwargs): pass
def MFnDependencyNode_findAlias(*args, **kwargs): pass
def MFnMesh_createColorSetWithName(*args, **kwargs): pass
def MFnCamera_setDisplayFilmGate(*args, **kwargs): pass
def MFnSubd_polygonSetUseUVs(*args, **kwargs): pass
def MSceneMessage_addStringArrayCallback(*args, **kwargs): pass
def MColor___ne__(*args, **kwargs): pass
def MItMeshVertex_getUV(*args, **kwargs): pass
def delete_MFnStringData(*args, **kwargs): pass
def MFnMesh_anyIntersection(*args, **kwargs): pass
def MFnTransform_setLimit(*args, **kwargs): pass
def MURI_getQueryValueDelimiter(*args, **kwargs): pass
def MFnMesh_numColorSets(*args, **kwargs): pass
def MDagModifier_className(*args, **kwargs): pass
def MPlug_isSource(*args, **kwargs): pass
def array4dDouble_getptr(*args, **kwargs): pass
def MFnDirectionalLight_useLightPosition(*args, **kwargs): pass
def MFnReference_containsNodeExactly(*args, **kwargs): pass
def MFnMesh_getStringBlindData(*args, **kwargs): pass
def MFnCamera_horizontalRollPivot(*args, **kwargs): pass
def MFileObject_setName(*args, **kwargs): pass
def MFcurveEdit_editType(*args, **kwargs): pass
def MColorArray_sizeIncrement(*args, **kwargs): pass
def new_MItMeshVertex(*args, **kwargs): pass
def MFnSpotLight_startDistance(*args, **kwargs): pass
def MFloatVector___itruediv__(*args, **kwargs): pass
def MFnMesh_numFaceVertices(*args, **kwargs): pass
def MDistance_setValue(*args, **kwargs): pass
def MDGModifier_newPlugValueMTime(*args, **kwargs): pass
def MPlug_setMDataHandle(*args, **kwargs): pass
def MFnMesh_polygonVertexCount(*args, **kwargs): pass
def MImageFileInfo_imageType(*args, **kwargs): pass
def MFnMesh_setDisplayColors(*args, **kwargs): pass
def MFnCamera_setHorizontalPan(*args, **kwargs): pass
def MFileObject_rawPath(*args, **kwargs): pass
def MFileObject_overrideResolvedFullName(*args, **kwargs): pass
def MAddRemoveAttrEdit_attributeName(*args, **kwargs): pass
def MCallbackIdArray_sizeIncrement(*args, **kwargs): pass
def MItMeshPolygon_isConnectedToEdge(*args, **kwargs): pass
def MFnSpotLight_type(*args, **kwargs): pass
def MFnBlinnShader_eccentricity(*args, **kwargs): pass
def MFnMesh_addPolygon(*args, **kwargs): pass
def MVector___getitem__(*args, **kwargs): pass
def MFnTransform_create(*args, **kwargs): pass
def MDGModifier_disconnect(*args, **kwargs): pass
def MPlug_isLocked(*args, **kwargs): pass
def MFnNumericData_className(*args, **kwargs): pass
def MIffFile_endGet(*args, **kwargs): pass
def MFnSubd_polygonSetVertexUVs(*args, **kwargs): pass
def MFnMesh_setFaceVertexColors(*args, **kwargs): pass
def MFnCamera_verticalFilmOffset(*args, **kwargs): pass
def MFileIO_cleanReference(*args, **kwargs): pass
def MCacheFormatDescription_getChannelEndTime(*args, **kwargs): pass
def MItMeshPolygon_getColor(*args, **kwargs): pass
def MFnSingleIndexedComponent_addElement(*args, **kwargs): pass
def MSyntax_makeFlagMultiUse(*args, **kwargs): pass
def MFnCameraSet_type(*args, **kwargs): pass
def MFnAssembly_getRepNamespace(*args, **kwargs): pass
def MUintArray_clear(*args, **kwargs): pass
def MMeshSmoothOptions_setOpenSubdivFaceVaryingBoundary(*args, **kwargs): pass
def MFnSubdNames_nonBaseFaceEdges(*args, **kwargs): pass
def MPlug_numChildren(*args, **kwargs): pass
def MGlobal_stopErrorLogging(*args, **kwargs): pass
def MFnMesh_getPinUVs(*args, **kwargs): pass
def MFnCamera_getFilmFrustum(*args, **kwargs): pass
def MRampAttribute_sampleColorRamp(*args, **kwargs): pass
def MFnSubd_evaluatePosition(*args, **kwargs): pass
def MCacheConfigRuleRegistry_registeringCallableScript(*args, **kwargs): pass
def MItMeshPolygon_setPoint(*args, **kwargs): pass
def MFnSet_getMembers(*args, **kwargs): pass
def MFnMatrixArrayData_create(*args, **kwargs): pass
def new_MFnAssembly(*args, **kwargs): pass
def MUint64Array___eq__(*args, **kwargs): pass
def MItGeometry_index(*args, **kwargs): pass
def doublePtr_value(*args, **kwargs): pass
def MPlug_attribute(*args, **kwargs): pass
def MDoubleArray_insert(*args, **kwargs): pass
def MGlobal_displayWarning(*args, **kwargs): pass
def MCallbackIdArray_clear(*args, **kwargs): pass
def MFnMesh_getAssociatedUVSetInstances(*args, **kwargs): pass
def MFnReference_setIgnoreReferenceEdits(*args, **kwargs): pass
def MFileIO_getReferenceNodes(*args, **kwargs): pass
def MBoundingBox_clear(*args, **kwargs): pass
def MItMeshFaceVertex_swigregister(*args, **kwargs): pass
def MFnPointArrayData_array(*args, **kwargs): pass
def MFnLightDataAttribute_type(*args, **kwargs): pass
def MItMeshFaceVertex_getNormal(*args, **kwargs): pass
def MUint64Array_set(*args, **kwargs): pass
def MObjectSetMessage_className(*args, **kwargs): pass
def new_shortPtr(*args, **kwargs): pass
def MPlugArray___getitem__(*args, **kwargs): pass
def MGlobal_setPreselectionHiliteList(*args, **kwargs): pass
def MFnReference_type(*args, **kwargs): pass
def MPolyMessage_className(*args, **kwargs): pass
def new_MFn(*args, **kwargs): pass
def MFileIO_fileType(*args, **kwargs): pass
def MQuaternion_exp(*args, **kwargs): pass
def delete_MAttributePatternArray(*args, **kwargs): pass
def MFnMesh_setSomeUVs(*args, **kwargs): pass
def MFnPhongShader_swigregister(*args, **kwargs): pass
def delete_MFnLayeredShader(*args, **kwargs): pass
def MAddRemoveAttrEdit_nodeName(*args, **kwargs): pass
def MFnDagNode_duplicate(*args, **kwargs): pass
def MTrimBoundaryArray_append(*args, **kwargs): pass
def MObjectHandle_object(*args, **kwargs): pass
def MGlobal_selectFromScreen(*args, **kwargs): pass
def MFnMesh_getTangents(*args, **kwargs): pass
def MFnAssembly_setRepLabel(*args, **kwargs): pass
def MFnReflectShader_specularColor(*args, **kwargs): pass
def MEvaluationNode_datablock(*args, **kwargs): pass
def MQuaternion___add__(*args, **kwargs): pass
def new_array2dDouble(*args, **kwargs): pass
def MItMeshEdge_numConnectedEdges(*args, **kwargs): pass
def new_MFnPhongEShader(*args, **kwargs): pass
def new_MFnIntArrayData(*args, **kwargs): pass
def MPlugArray_insert(*args, **kwargs): pass
def MVectorArray_set(*args, **kwargs): pass
def MFnDagNode_addChild(*args, **kwargs): pass
def MTransformationMatrix___ne__(*args, **kwargs): pass
def MCallbackIdArray_swigregister(*args, **kwargs): pass
def delete_MObjectArray(*args, **kwargs): pass
def MGlobal_mayaState(*args, **kwargs): pass
def MFnMesh_getFaceVertexNormal(*args, **kwargs): pass
def MFnLambertShader_ambientColor(*args, **kwargs): pass
def delete_MEventMessage(*args, **kwargs): pass
def MScriptUtil_getUint3ArrayItem(*args, **kwargs): pass
def delete_array2dFloat(*args, **kwargs): pass
def MItMeshEdge_reset(*args, **kwargs): pass
def MItMeshFaceVertex_getBinormal(*args, **kwargs): pass
def MFnNurbsSurface_getAssignedUVs(*args, **kwargs): pass
def MFnDependencyNode_dgTimerOff(*args, **kwargs): pass
def MTransformationMatrix_getTranslation(*args, **kwargs): pass
def new_MNurbsIntersector(*args, **kwargs): pass
def MProfiler_getColor(*args, **kwargs): pass
def MFnMesh_getPointAtUV(*args, **kwargs): pass
def MFnLambertShader_type(*args, **kwargs): pass
def MEulerRotation_setToClosestSolution(*args, **kwargs): pass
def MScriptUtil_setShort3ArrayItem(*args, **kwargs): pass
def MItInstancer_next(*args, **kwargs): pass
def MFnNurbsSurface_trimWithBoundaries(*args, **kwargs): pass
def MFnGenericAttribute_className(*args, **kwargs): pass
def MFnDependencyNode_canBeWritten(*args, **kwargs): pass
def MTransformationMatrix_asMatrixInverse(*args, **kwargs): pass
def MItMeshPolygon_hasUVs(*args, **kwargs): pass
def MFnCameraSet_getNumLayers(*args, **kwargs): pass
def MNodeClass_className(*args, **kwargs): pass
def delete_MFnVectorArrayData(*args, **kwargs): pass
def MFnAttribute_setProxyAttribute(*args, **kwargs): pass
def MDataHandle_setGenericInt64(*args, **kwargs): pass
def MEulerRotation___mul__(*args, **kwargs): pass
def MScriptUtil_getBoolArrayItem(*args, **kwargs): pass
def MFileObject_rawURI(*args, **kwargs): pass
def MAttributePattern_className(*args, **kwargs): pass
def MDistance_internalUnit(*args, **kwargs): pass
def MFnNurbsSurface_area(*args, **kwargs): pass
def MFnExpression_evaluate(*args, **kwargs): pass
def MFnDependencyNode_userNode(*args, **kwargs): pass
def MTimer_elapsedTime(*args, **kwargs): pass
def new_MNamespace(*args, **kwargs): pass
def MFnUnitAttribute_unitType(*args, **kwargs): pass
def MProfiler_setCategoryRecording(*args, **kwargs): pass
def MDataHandle_set4Double(*args, **kwargs): pass
def MDoubleArray___add__(*args, **kwargs): pass
def MScriptUtil_getChar(*args, **kwargs): pass
def MAttributeSpec_assign(*args, **kwargs): pass
def MItEdits_className(*args, **kwargs): pass
def MFnNurbsSurface_getKnotsInU(*args, **kwargs): pass
def MContainerMessage_swigregister(*args, **kwargs): pass
def MFnEnumAttribute_getMax(*args, **kwargs): pass
def MItMeshVertex_getConnectedFaces(*args, **kwargs): pass
def MFnDependencyNode_typeId(*args, **kwargs): pass
def MTime___gt__(*args, **kwargs): pass
def MTrimBoundaryArray_size(*args, **kwargs): pass
def MFnUint64SingleIndexedComponent_type(*args, **kwargs): pass
def MFnAttribute_indexMatters(*args, **kwargs): pass
def MDataHandle_setFloat(*args, **kwargs): pass
def MDoubleArray_length(*args, **kwargs): pass
def MScriptUtil_asUint2Ptr(*args, **kwargs): pass
def MAttributeSpecArray_setLength(*args, **kwargs): pass
def MItDependencyNodes_className(*args, **kwargs): pass
def MFnNurbsSurface_formInV(*args, **kwargs): pass
def MFnCameraSet_getLayerSceneData(*args, **kwargs): pass
def MFnDoubleIndexedComponent_create(*args, **kwargs): pass
def MFloatVector_y_set(*args, **kwargs): pass
def MPointOnMesh_getNormal(*args, **kwargs): pass
def MMatrixArray_copy(*args, **kwargs): pass
def MFnNurbsSurface_numUVs(*args, **kwargs): pass
def MFnArrayAttrsData_stringArray(*args, **kwargs): pass
def MDataHandle_asFloatMatrix(*args, **kwargs): pass
def MDistance_setInternalUnit(*args, **kwargs): pass
def MDistance_asMillimeters(*args, **kwargs): pass
def MScriptUtil_asDoublePtr(*args, **kwargs): pass
def MAttributeIndex_getUpper(*args, **kwargs): pass
def MItDependencyGraph_currentItem(*args, **kwargs): pass
def MFnNurbsSurfaceData_create(*args, **kwargs): pass
def MFnCameraSet_getLayerClearDepthValue(*args, **kwargs): pass
def MTesselationParams_fsDefaultTesselationParams_get(*args, **kwargs): pass
def MDagMessage_addInstanceAddedDagPathCallback(*args, **kwargs): pass
def MMatrix_det3x3(*args, **kwargs): pass
def MProfiler_getEventCount(*args, **kwargs): pass
def MFnSubdNames_className(*args, **kwargs): pass
def MFnData_type(*args, **kwargs): pass
def MDataHandle_asAngle(*args, **kwargs): pass
def MCameraMessage_className(*args, **kwargs): pass
def MPolyMessage_swigregister(*args, **kwargs): pass
def MArrayDataHandle_setAllClean(*args, **kwargs): pass
def MItDependencyGraph_disablePruningOnFilter(*args, **kwargs): pass
def MFnNurbsCurve_length(*args, **kwargs): pass
def MFnSubdNames_level(*args, **kwargs): pass
def new_MFnCameraSet(*args, **kwargs): pass
def MDataHandle_setMVector(*args, **kwargs): pass
def MFloatVectorArray_append(*args, **kwargs): pass
def MTesselationParams_setMaxNumberPolys(*args, **kwargs): pass
def MCurveAttribute_className(*args, **kwargs): pass
def MMatrix___getitem__(*args, **kwargs): pass
def MFnSubdNames_fromMUint64(*args, **kwargs): pass
def MFnNonExtendedLight_depthMapResolution(*args, **kwargs): pass
def MDataHandle_typeId(*args, **kwargs): pass
def MFnMesh_getAssignedUVs(*args, **kwargs): pass
def MDGMessage_addForceUpdateCallback(*args, **kwargs): pass
def MProfiler_getNumberOfCPUs(*args, **kwargs): pass
def MArrayDataBuilder_growArray(*args, **kwargs): pass
def MItDag_instanceCount(*args, **kwargs): pass
def MFnCompoundAttribute_child(*args, **kwargs): pass
def MFloatPoint_y_get(*args, **kwargs): pass
def MSyntax_canEdit(*args, **kwargs): pass
def MFnGeometryData_objectGroup(*args, **kwargs): pass
def delete_MCurveAttribute(*args, **kwargs): pass
def MItSurfaceCV_currentItem(*args, **kwargs): pass
def MFnTransform_className(*args, **kwargs): pass
def MFnSubd_evaluateNormal(*args, **kwargs): pass
def MFnNonAmbientLight_className(*args, **kwargs): pass
def MVector_y_get(*args, **kwargs): pass
def MProfiler_getEventName(*args, **kwargs): pass
def MArgList_asVector(*args, **kwargs): pass
def MItCurveCV_className(*args, **kwargs): pass
def MFnNurbsCurveData_create(*args, **kwargs): pass
def new_MFnTransform(*args, **kwargs): pass
def MFloatPoint___add__(*args, **kwargs): pass
def MComputation_className(*args, **kwargs): pass
def MItSubdVertex_isValid(*args, **kwargs): pass
def MFnSubd_polygonCount(*args, **kwargs): pass
def MFnMesh_getColorSetNames(*args, **kwargs): pass
def MFnAnisotropyShader_setTangentVCamera(*args, **kwargs): pass
def MVector___imul__(*args, **kwargs): pass
def MDagPath_getDrawOverrideInfo(*args, **kwargs): pass
def delete_MItMeshPolygon(*args, **kwargs): pass
def new_MArgDatabase(*args, **kwargs): pass
def MInt64Array___add__(*args, **kwargs): pass
def MFnNumericData_getData3Float(*args, **kwargs): pass
def delete_MFnComponent(*args, **kwargs): pass
def MFloatPointArray_remove(*args, **kwargs): pass
def MSetAttrEdit_editType(*args, **kwargs): pass
def delete_MCommandResult(*args, **kwargs): pass
def delete_MItSubdFace(*args, **kwargs): pass
def MFnSubd_vertexCreaseRelevant(*args, **kwargs): pass
def MFnMesh_isPolygonUVReversed(*args, **kwargs): pass
def MColor___imul__(*args, **kwargs): pass
def new_MFnAmbientLight(*args, **kwargs): pass
def MVectorArray_sizeIncrement(*args, **kwargs): pass
def MDagPath_child(*args, **kwargs): pass
def MPoint___isub__(*args, **kwargs): pass
def MArgParser_flagArgumentString(*args, **kwargs): pass
def MInt64Array_remove(*args, **kwargs): pass
def MFnNumericAttribute_setSoftMax(*args, **kwargs): pass
def MItGeometry_exactCount(*args, **kwargs): pass
def MFnCamera_centerOfInterest(*args, **kwargs): pass
def MFnDoubleArrayData_type(*args, **kwargs): pass
def MFloatMatrix_inverse(*args, **kwargs): pass
def MSelectionMask___or__(*args, **kwargs): pass
def MItSelectionList_className(*args, **kwargs): pass
def MFnSubd_vertexPositionGet(*args, **kwargs): pass
def MFnLight_centerOfIllumination(*args, **kwargs): pass
def MUuid_generate(*args, **kwargs): pass
def MDAGDrawOverrideInfo_swigregister(*args, **kwargs): pass
def MPointArray_append(*args, **kwargs): pass
def MColorArray_swigregister(*args, **kwargs): pass
def MAngle_setUIUnit(*args, **kwargs): pass
def MIntArray___len__(*args, **kwargs): pass
def MFileIO_getReferenceConnectionsMade(*args, **kwargs): pass
def MFnNumericAttribute_createColor(*args, **kwargs): pass
def MFnCamera_setDepthOfField(*args, **kwargs): pass
def MSelectionList_remove(*args, **kwargs): pass
def MMessageNode_fId_set(*args, **kwargs): pass
def MItMeshVertex_getColors(*args, **kwargs): pass
def MFnAmbientLight_shadowRadius(*args, **kwargs): pass
def MItMeshPolygon_count(*args, **kwargs): pass
def MUserEventMessage_isUserEvent(*args, **kwargs): pass
def MDagPathArray_swigregister(*args, **kwargs): pass
def new_MPlane(*args, **kwargs): pass
def MObject_assign(*args, **kwargs): pass
def MImage_className(*args, **kwargs): pass
def MFnMesh_generateSmoothMesh(*args, **kwargs): pass
def delete_MColor(*args, **kwargs): pass
def MFloatArray_clear(*args, **kwargs): pass
def MSceneMessage_addReferenceCallback(*args, **kwargs): pass
def MColor_get(*args, **kwargs): pass
def MItMeshVertex_setUVs(*args, **kwargs): pass
def MFnStringData_className(*args, **kwargs): pass
def MFnMesh_allIntersections(*args, **kwargs): pass
def MFnTransform_enableLimit(*args, **kwargs): pass
def MRichSelection_clear(*args, **kwargs): pass
def MDagModifier_swigregister(*args, **kwargs): pass
def MPlug_isDestination(*args, **kwargs): pass
def MFnDoubleArrayData_length(*args, **kwargs): pass
def MImage_depth(*args, **kwargs): pass
def MFnMesh_binaryBlindDataComponentId(*args, **kwargs): pass
def MFnCamera_setVerticalRollPivot(*args, **kwargs): pass
def MFileObject_setFullName(*args, **kwargs): pass
def MFcurveEdit_className(*args, **kwargs): pass
def MColorArray_className(*args, **kwargs): pass
def delete_MItMeshVertex(*args, **kwargs): pass
def MFnSpotLight_setStartDistance(*args, **kwargs): pass
def MDoubleArray_get(*args, **kwargs): pass
def MFnTransform_rotatePivotTranslation(*args, **kwargs): pass
def MURI_setQueryDelimiters(*args, **kwargs): pass
def MDGModifier_newPlugValueShort(*args, **kwargs): pass
def MPlug_setDouble(*args, **kwargs): pass
def MImageFileInfo_hardwareType(*args, **kwargs): pass
def MFnMesh_getHoles(*args, **kwargs): pass
def MVector_angle(*args, **kwargs): pass
def MFnCamera_verticalPan(*args, **kwargs): pass
def MFileObject_rawName(*args, **kwargs): pass
def MProfiler_recordingActive(*args, **kwargs): pass
def MCallbackIdArray_className(*args, **kwargs): pass
def MItMeshPolygon_isConnectedToVertex(*args, **kwargs): pass
def delete_MFnSpotLight(*args, **kwargs): pass
def MFnMesh_addHoles(*args, **kwargs): pass
def MFnTransform_transformation(*args, **kwargs): pass
def MURI_assign(*args, **kwargs): pass
def MDGModifier_renameAttribute(*args, **kwargs): pass
def MPlug_setLocked(*args, **kwargs): pass
def MIffFile_get(*args, **kwargs): pass
def MFnSubdNames_baseFaceIdFromLong(*args, **kwargs): pass
def MFnMesh_removeFaceColors(*args, **kwargs): pass
def MFnCamera_setVerticalFilmOffset(*args, **kwargs): pass
def MFileIO_saveReference(*args, **kwargs): pass
def MRenderPassRegistry_swigregister(*args, **kwargs): pass
def MCacheFormatDescription_className(*args, **kwargs): pass
def MItMeshPolygon_getColors(*args, **kwargs): pass
def MFnSingleIndexedComponent_addElements(*args, **kwargs): pass
def MURI_getPassword(*args, **kwargs): pass
def MFnMatrixData_set(*args, **kwargs): pass
def MFnDoubleArrayData_array(*args, **kwargs): pass
def MFnAssembly_setRepName(*args, **kwargs): pass
def MUintArray_get(*args, **kwargs): pass
def MMeshSmoothOptions_openSubdivFaceVaryingBoundary(*args, **kwargs): pass
def MPlug_numConnectedElements(*args, **kwargs): pass
def MGlobal_closeErrorLog(*args, **kwargs): pass
def MFnMesh_setPinUVs(*args, **kwargs): pass
def MAttributePatternArray___getitem__(*args, **kwargs): pass
def MFnCamera_getPortFieldOfView(*args, **kwargs): pass
def MFileIO_beforeReferenceFilename(*args, **kwargs): pass
def MRampAttribute_sampleValueRamp(*args, **kwargs): pass
def MItDependencyGraph_isTraversalDepthFirst(*args, **kwargs): pass
def MFnTransform_scalePivotTranslation(*args, **kwargs): pass
def MCacheConfigRuleRegistry_swigregister(*args, **kwargs): pass
def MItMeshPolygon_setPoints(*args, **kwargs): pass
def MFnSet_addMember(*args, **kwargs): pass
def MFnMatrixArrayData_swigregister(*args, **kwargs): pass
def MFnAssembly_getTopLevelAssemblies(*args, **kwargs): pass
def MUint64Array___ne__(*args, **kwargs): pass
def MItMeshPolygon_zeroUVArea(*args, **kwargs): pass
def doublePtr_cast(*args, **kwargs): pass
def MPlug_node(*args, **kwargs): pass
def MArgList_assign(*args, **kwargs): pass
def MProfiler_saveRecording(*args, **kwargs): pass
def MDGModifier_newPlugValue(*args, **kwargs): pass
def MFnMesh_setUVs(*args, **kwargs): pass
def MFnReference_swigregister(*args, **kwargs): pass
def MRampAttribute_setColorAtIndex(*args, **kwargs): pass
def MBoundingBox_transformUsing(*args, **kwargs): pass
def new_MItMeshPolygon(*args, **kwargs): pass
def MFnPointArrayData_create(*args, **kwargs): pass
def delete_MFnLightDataAttribute(*args, **kwargs): pass
def MDoubleArray___getitem__(*args, **kwargs): pass
def MFnDagNode_dormantColor(*args, **kwargs): pass
def delete_shortPtr(*args, **kwargs): pass
def MPlugArray_assign(*args, **kwargs): pass
def MGlobal_currentToolContext(*args, **kwargs): pass
def MFloatMatrix___mul__(*args, **kwargs): pass
def MFnMesh_setCreaseVertices(*args, **kwargs): pass
def delete_MFnReference(*args, **kwargs): pass
def MQuaternion_x_set(*args, **kwargs): pass
def MTime_ticksPerSecond(*args, **kwargs): pass
def MFileIO_getFileTypes(*args, **kwargs): pass
def MFnMesh_setFaceColors(*args, **kwargs): pass
def MItMeshFaceVertex_position(*args, **kwargs): pass
def MFnPluginData_type(*args, **kwargs): pass
def MFnLayeredShader_className(*args, **kwargs): pass
def MFnDagNode_getPath(*args, **kwargs): pass
def MTrimBoundaryArray_remove(*args, **kwargs): pass
def MObjectHandle_objectRef(*args, **kwargs): pass
def MGlobal_selectionMethod(*args, **kwargs): pass
def MFnNonExtendedLight_useDepthMapAutoFocus(*args, **kwargs): pass
def MUint64Array_setLength(*args, **kwargs): pass
def MFnReflectShader_setSpecularColor(*args, **kwargs): pass
def MEvaluationNode_connect(*args, **kwargs): pass
def MQuaternion___mul__(*args, **kwargs): pass
def delete_array2dDouble(*args, **kwargs): pass
def MItMeshEdge_connectedToFace(*args, **kwargs): pass
def MFnCamera_shakeOverscanEnabled(*args, **kwargs): pass
def MFnPhongEShader_create(*args, **kwargs): pass
def MSyntax_setMaxObjects(*args, **kwargs): pass
def MFnIntArrayData_length(*args, **kwargs): pass
def MFnDagNode_removeChild(*args, **kwargs): pass
def MColor___sub__(*args, **kwargs): pass
def MObjectArray_assign(*args, **kwargs): pass
def MFnExpression_expression(*args, **kwargs): pass
def MGlobal_getFunctionSetList(*args, **kwargs): pass
def MFnMesh_getFaceVertexNormals(*args, **kwargs): pass
def MFnLambertShader_setAmbientColor(*args, **kwargs): pass
def MEventMessage_swigregister(*args, **kwargs): pass
def MScriptUtil_setUint3ArrayItem(*args, **kwargs): pass
def array2dFloat_get(*args, **kwargs): pass
def MItMeshEdge_count(*args, **kwargs): pass
def MItMeshPolygon_normalIndex(*args, **kwargs): pass
def MFnNurbsSurface_getConnectedShaders(*args, **kwargs): pass
def MFnGeometryData_hasObjectGroup(*args, **kwargs): pass
def MFnDependencyNode_dgTimerQueryState(*args, **kwargs): pass
def MTransformationMatrix_setTranslation(*args, **kwargs): pass
def delete_MNurbsIntersector(*args, **kwargs): pass
def MFnMesh_getFaceVertexTangent(*args, **kwargs): pass
def MFnVolumeLight_arc(*args, **kwargs): pass
def MIntArray_append(*args, **kwargs): pass
def MFnMesh_getConnectedShaders(*args, **kwargs): pass
def MFnMesh_removeVertexColors(*args, **kwargs): pass
def MDataHandle_copyWritable(*args, **kwargs): pass
def delete_MFnLambertShader(*args, **kwargs): pass
def MEulerRotation_closestCut(*args, **kwargs): pass
def MScriptUtil_getShort4ArrayItem(*args, **kwargs): pass
def uCharPtr_cast(*args, **kwargs): pass
def MItInstancer_nextParticle(*args, **kwargs): pass
def MFnNurbsSurface_projectCurve(*args, **kwargs): pass
def new_MFnGenericAttribute(*args, **kwargs): pass
def MFnDependencyNode_hasAttribute(*args, **kwargs): pass
def MFnTransform_setRotatePivotTranslation(*args, **kwargs): pass
def MFnSingleIndexedComponent_swigregister(*args, **kwargs): pass
def delete_MNodeClass(*args, **kwargs): pass
def MFnVectorArrayData_className(*args, **kwargs): pass
def MFnAttribute_setDisconnectBehavior(*args, **kwargs): pass
def MDataHandle_child(*args, **kwargs): pass
def MEulerRotation___imul__(*args, **kwargs): pass
def MGlobal_defaultErrorLogPathName(*args, **kwargs): pass
def MUint64Array_copy(*args, **kwargs): pass
def MFnNurbsSurface_closestPoint(*args, **kwargs): pass
def new_MAttributeSpec(*args, **kwargs): pass
def MFnExpression_unitConversion(*args, **kwargs): pass
def MFnDependencyNode_isFromReferencedFile(*args, **kwargs): pass
def MIntArray_setSizeIncrement(*args, **kwargs): pass
def delete_MNamespace(*args, **kwargs): pass
def MFnUnitAttribute_hasMin(*args, **kwargs): pass
def new_MFnTripleIndexedComponent(*args, **kwargs): pass
def MFnAttribute_setWritable(*args, **kwargs): pass
def MDataHandle_setString(*args, **kwargs): pass
def MDoubleArray___radd__(*args, **kwargs): pass
def MScriptUtil_getUchar(*args, **kwargs): pass
def MAttributeSpec___getitem__(*args, **kwargs): pass
def MItEdits_swigregister(*args, **kwargs): pass
def MFnNurbsSurface_getKnotsInV(*args, **kwargs): pass
def MFnEnumAttribute_setDefault(*args, **kwargs): pass
def MFnVolumeLight_className(*args, **kwargs): pass
def MFnDependencyNode_typeName(*args, **kwargs): pass
def MTime___add__(*args, **kwargs): pass
def MItSurfaceCV_className(*args, **kwargs): pass
def MFnTripleIndexedComponent_create(*args, **kwargs): pass
def MNamespace_currentNamespace(*args, **kwargs): pass
def delete_MFnUint64SingleIndexedComponent(*args, **kwargs): pass
def MDoubleArray_remove(*args, **kwargs): pass
def MScriptUtil_asUint3Ptr(*args, **kwargs): pass
def MAttributeSpecArray_length(*args, **kwargs): pass
def MItDependencyNodes_swigregister(*args, **kwargs): pass
def MFnDoubleIndexedComponent_getCompleteData(*args, **kwargs): pass
def MFnDoubleIndexedComponent_addElement(*args, **kwargs): pass
def MFloatVector_y_get(*args, **kwargs): pass
def MTimeArray_swigregister(*args, **kwargs): pass
def MPointOnMesh_getBarycentricCoords(*args, **kwargs): pass
def MMatrixArray_clear(*args, **kwargs): pass
def MFnTypedAttribute_create(*args, **kwargs): pass
def MFnMesh_getAssociatedColorSetInstances(*args, **kwargs): pass
def MFnArrayAttrsData_create(*args, **kwargs): pass
def MEulerRotation_assign(*args, **kwargs): pass
def MDistance_asCentimeters(*args, **kwargs): pass
def MScriptUtil_asUintPtr(*args, **kwargs): pass
def MAttributeIndex_isBounded(*args, **kwargs): pass
def MItDependencyGraph_thisNodeHasUnknownType(*args, **kwargs): pass
def MFnNurbsSurfaceData_swigregister(*args, **kwargs): pass
def MFnCameraSet_swigregister(*args, **kwargs): pass
def MTransformationMatrix_getRotation(*args, **kwargs): pass
def MFloatVector___neg__(*args, **kwargs): pass
def MTesselationParams_fsDefaultTesselationParams_set(*args, **kwargs): pass
def MDagMessage_addInstanceRemovedCallback(*args, **kwargs): pass
def MMatrix_isEquivalent(*args, **kwargs): pass
def MPolyMessage_addPolyTopologyChangedCallback(*args, **kwargs): pass
def new_MWeight(*args, **kwargs): pass
def delete_MFnData(*args, **kwargs): pass
def MDataHandle_asTime(*args, **kwargs): pass
def MProfiler_getCPUId(*args, **kwargs): pass
def new_MCameraMessage(*args, **kwargs): pass
def delete_MScriptUtil(*args, **kwargs): pass
def MArrayDataHandle_builder(*args, **kwargs): pass
def MItDependencyGraph_isDirectionDownStream(*args, **kwargs): pass
def MFnMesh_getPolygonVertices(*args, **kwargs): pass
def MFnNurbsCurve_getDerivativesAtParm(*args, **kwargs): pass
def MFnTripleIndexedComponent_getElements(*args, **kwargs): pass
def MFnCameraSet_create(*args, **kwargs): pass
def MTesselationParams_setMaxSubdivisionLevel(*args, **kwargs): pass
def MCurveAttribute_swigregister(*args, **kwargs): pass
def MMatrix_get(*args, **kwargs): pass
def MFnSubdNames_toMUint64(*args, **kwargs): pass
def MFnNonExtendedLight_setDepthMapResolution(*args, **kwargs): pass
def MFnEnumAttribute_className(*args, **kwargs): pass
def MDGMessage_addNodeAddedCallback(*args, **kwargs): pass
def MProfiler_className(*args, **kwargs): pass
def MArrayDataBuilder_setGrowSize(*args, **kwargs): pass
def MItDag_traverseUnderWorld(*args, **kwargs): pass
def MFnNurbsCurve_numKnots(*args, **kwargs): pass
def MFnCompoundAttribute_getAddAttrCmds(*args, **kwargs): pass
def MFloatPoint_z_set(*args, **kwargs): pass
def MSyntax_className(*args, **kwargs): pass
def MFnCamera_setShakeOverscan(*args, **kwargs): pass
def MCurveAttribute_getNumEntries(*args, **kwargs): pass
def MUint64Array___getitem__(*args, **kwargs): pass
def MFnSubd_evaluatePositionAndNormal(*args, **kwargs): pass
def new_MFnNonAmbientLight(*args, **kwargs): pass
def MVector_z_set(*args, **kwargs): pass
def MDGContext_fsNormal_get(*args, **kwargs): pass
def MProfiler_getDescription(*args, **kwargs): pass
def MArgList_asPoint(*args, **kwargs): pass
def MItCurveCV_swigregister(*args, **kwargs): pass
def MColor_swigregister(*args, **kwargs): pass
def MFnComponentListData_length(*args, **kwargs): pass
def MFloatPoint___sub__(*args, **kwargs): pass
def new_MSyntax(*args, **kwargs): pass
def MFnSubd_polygonEdgeCount(*args, **kwargs): pass
def MComputation_swigregister(*args, **kwargs): pass
def MItSubdVertex_index(*args, **kwargs): pass
def MFnSubd_polygonCountMaxWithGivenBaseMesh(*args, **kwargs): pass
def MFnReflectShader_type(*args, **kwargs): pass
def MFnAnisotropyShader_correlationX(*args, **kwargs): pass
def MVector___ne__(*args, **kwargs): pass
def MItMeshPolygon_getUVSetNames(*args, **kwargs): pass
def MPoint_w_set(*args, **kwargs): pass
def delete_MArgDatabase(*args, **kwargs): pass
def MInt64Array___radd__(*args, **kwargs): pass
def MFnNumericData_getData3Double(*args, **kwargs): pass
def MFnComponent_className(*args, **kwargs): pass
def MFloatPointArray_insert(*args, **kwargs): pass
def MSetAttrEdit_className(*args, **kwargs): pass
def delete_MItDependencyNodes(*args, **kwargs): pass
def MCommandResult_resultType(*args, **kwargs): pass
def MItSubdFace_reset(*args, **kwargs): pass
def MFnMesh_clearColors(*args, **kwargs): pass
def MFnAmbientLight_create(*args, **kwargs): pass
def MVectorArray_className(*args, **kwargs): pass
def MDagPath_inclusiveMatrix(*args, **kwargs): pass
def MPoint___truediv__(*args, **kwargs): pass
def MArgParser_flagArgumentMDistance(*args, **kwargs): pass
def MInt64Array_insert(*args, **kwargs): pass
def MFnAttribute_isReadable(*args, **kwargs): pass
def MFnNumericAttribute_getDefault(*args, **kwargs): pass
def MFnCamera_setIsOrtho(*args, **kwargs): pass
def MFnTransform_isLimited(*args, **kwargs): pass
def MFloatMatrix_adjoint(*args, **kwargs): pass
def MSelectionMask_assign(*args, **kwargs): pass
def MMessage_stopRegisteringCallableScript(*args, **kwargs): pass
def MItSelectionList_swigregister(*args, **kwargs): pass
def MFnSubd_vertexEditGet(*args, **kwargs): pass
def MFnLight_setCenterOfIllumination(*args, **kwargs): pass
def MUuid_className(*args, **kwargs): pass
def new_MDagPath(*args, **kwargs): pass
def new_MFnTypedAttribute(*args, **kwargs): pass
def MIntArray___setitem__(*args, **kwargs): pass
def MFloatPointArray_clear(*args, **kwargs): pass
def MSelectionList_replace(*args, **kwargs): pass
def MContainerMessage_addBoundAttrCallback(*args, **kwargs): pass
def MItMeshPolygon_numColors(*args, **kwargs): pass
def MFnMesh_onBoundary(*args, **kwargs): pass
def MSceneMessage_addCheckReferenceCallback(*args, **kwargs): pass
def MColor_set(*args, **kwargs): pass
def MURI_removeQueryItem(*args, **kwargs): pass
def delete_MUint64Array(*args, **kwargs): pass
def MFnTransform_getRotation(*args, **kwargs): pass
def MFileObject_name(*args, **kwargs): pass
def delete_MFcurveEdit(*args, **kwargs): pass
def MScriptUtil_createFromList(*args, **kwargs): pass
def MURI_asString(*args, **kwargs): pass
def MPlug_setFloat(*args, **kwargs): pass
def MFnAttribute_isWritable(*args, **kwargs): pass
def MFnCamera_setVerticalPan(*args, **kwargs): pass
def MScriptUtil_asInt(*args, **kwargs): pass
def MAddRemoveAttrEdit_isAttributeAdded(*args, **kwargs): pass
def MFnTransform_set(*args, **kwargs): pass
def MFnUInt64ArrayData_type(*args, **kwargs): pass
def MFileIO_fileCurrentlyLoading(*args, **kwargs): pass
def delete_MEdit(*args, **kwargs): pass
def delete_MPlug(*args, **kwargs): pass
def MAttributePattern_swigregister(*args, **kwargs): pass
def delete_MFnExpression(*args, **kwargs): pass
def delete_MVector(*args, **kwargs): pass
def MUintArray_setSizeIncrement(*args, **kwargs): pass
def MMeshSmoothOptions_setOpenSubdivSmoothTriangles(*args, **kwargs): pass
def MRampAttribute_swigregister(*args, **kwargs): pass
def MEulerRotation_incrementalRotateBy(*args, **kwargs): pass
def doublePtr_frompointer(*args, **kwargs): pass
def MArrayDataBuilder_addLast(*args, **kwargs): pass
def MFnCamera_type(*args, **kwargs): pass
def MRampAttribute_setValueAtIndex(*args, **kwargs): pass
def MItMeshPolygon_geomChanged(*args, **kwargs): pass
def MUint64Array_length(*args, **kwargs): pass
def shortPtr_assign(*args, **kwargs): pass
def MPlugArray_set(*args, **kwargs): pass
def delete_MItInstancer(*args, **kwargs): pass
def MFnExpression_create(*args, **kwargs): pass
def MTrimBoundaryArray_clear(*args, **kwargs): pass
def MUintArray_insert(*args, **kwargs): pass
def MDataHandle_asInt(*args, **kwargs): pass
def MFnAnisotropyShader_create(*args, **kwargs): pass
def delete_MMessageNode(*args, **kwargs): pass
def MTransformationMatrix_setRotation(*args, **kwargs): pass
def MFnMesh_getNormalIds(*args, **kwargs): pass
def MItMeshPolygon_getConnectedVertices(*args, **kwargs): pass
def MFnNurbsSurface_getParamAtPoint(*args, **kwargs): pass
def MTransformationMatrix_addTranslation(*args, **kwargs): pass
def MFnNumericAttribute_unitType(*args, **kwargs): pass
def MFnNurbsSurface_assignUVs(*args, **kwargs): pass
def MFnMesh_getBoolBlindData(*args, **kwargs): pass
def uCharPtr_frompointer(*args, **kwargs): pass
def MTransformationMatrix_asRotateMatrix(*args, **kwargs): pass
def MMessage_removeCallbacks(*args, **kwargs): pass
def new_MFnVectorArrayData(*args, **kwargs): pass
def MFnAttribute_setUsesArrayDataBuilder(*args, **kwargs): pass
def MDataHandle_datablock(*args, **kwargs): pass
def MScriptUtil_getUcharArrayItem(*args, **kwargs): pass
def MPlug_swigregister(*args, **kwargs): pass
def MItGeometry_setPosition(*args, **kwargs): pass
def MMessage_currentCallbackId(*args, **kwargs): pass
def MItMeshPolygon_numConnectedFaces(*args, **kwargs): pass
def MAttributeSpec___eq__(*args, **kwargs): pass
def new_MIteratorType(*args, **kwargs): pass
def MFnNurbsSurface_setKnotsInU(*args, **kwargs): pass
def MDAGDrawOverrideInfo_fDisplayType_set(*args, **kwargs): pass
def MFnEnumAttribute_getDefault(*args, **kwargs): pass
def MFnAnisotropyShader_tangentUCamera(*args, **kwargs): pass
def MFnDependencyNode_name(*args, **kwargs): pass
def MFnMesh_getBinaryBlindData(*args, **kwargs): pass
def MNamespace_setCurrentNamespace(*args, **kwargs): pass
def MFnUint64SingleIndexedComponent_className(*args, **kwargs): pass
def new_MEvaluationNode(*args, **kwargs): pass
def MFnExpression_setUnitConversion(*args, **kwargs): pass
def MFloatVector_z_set(*args, **kwargs): pass
def new_MTime(*args, **kwargs): pass
def MPointOnMesh_faceIndex(*args, **kwargs): pass
def MMatrixArray_setSizeIncrement(*args, **kwargs): pass
def MFnTransform_shearBy(*args, **kwargs): pass
def MEulerRotation_setToClosestCut(*args, **kwargs): pass
def MScriptUtil_asBoolPtr(*args, **kwargs): pass
def MItDependencyGraph_thisPlug(*args, **kwargs): pass
def MFnAttribute_isKeyable(*args, **kwargs): pass
def MFnNurbsSurface_type(*args, **kwargs): pass
def MScriptUtil_asInt3Ptr(*args, **kwargs): pass
def MFnCamera_verticalFieldOfView(*args, **kwargs): pass
def MFnTripleIndexedComponent_type(*args, **kwargs): pass
def new_MScriptUtil(*args, **kwargs): pass
def MTimer_assign(*args, **kwargs): pass
def MItDependencyGraph_currentDirection(*args, **kwargs): pass
def MFnUint64SingleIndexedComponent_addElements(*args, **kwargs): pass
def MTesselationParams_setMinScreenSize(*args, **kwargs): pass
def MFnNonExtendedLight_depthMapBias(*args, **kwargs): pass
def MDataHandle_data(*args, **kwargs): pass
def MFnFloatArrayData_className(*args, **kwargs): pass
def MDGMessage_addNodeRemovedCallback(*args, **kwargs): pass
def new_MArrayDataBuilder(*args, **kwargs): pass
def MFnCompoundAttribute_swigregister(*args, **kwargs): pass
def MDataHandle_setDouble(*args, **kwargs): pass
def MFloatPoint_z_get(*args, **kwargs): pass
def MSyntax_swigregister(*args, **kwargs): pass
def MFnNurbsSurface_isBezier(*args, **kwargs): pass
def MItSurfaceCV_hasHistoryOnCreate(*args, **kwargs): pass
def MEulerRotation_y_set(*args, **kwargs): pass
def MFnNonAmbientLight_decayRate(*args, **kwargs): pass
def MVector_z_get(*args, **kwargs): pass
def MDGContext_fsNormal_set(*args, **kwargs): pass
def MProfiler_getEventCategory(*args, **kwargs): pass
def MArgList_asMatrix(*args, **kwargs): pass
def new_MItDag(*args, **kwargs): pass
def MFnNurbsCurve_type(*args, **kwargs): pass
def MUintArray___add__(*args, **kwargs): pass
def MFnComponentListData_has(*args, **kwargs): pass
def MFloatPoint___iadd__(*args, **kwargs): pass
def MFnVolumeLight_colorRamp(*args, **kwargs): pass
def MConditionMessage_addConditionCallback(*args, **kwargs): pass
def MFnSubd_polygonVertexCount(*args, **kwargs): pass
def MDoubleArray___eq__(*args, **kwargs): pass
def MFnAnisotropyShader_setCorrelationX(*args, **kwargs): pass
def MFnUint64SingleIndexedComponent_getCompleteData(*args, **kwargs): pass
def MDagPath_className(*args, **kwargs): pass
def MPoint_w_get(*args, **kwargs): pass
def MArgDatabase_getFlagArgument(*args, **kwargs): pass
def MInt64Array___iadd__(*args, **kwargs): pass
def MFnNumericData_getData4Double(*args, **kwargs): pass
def MFloatPointArray_append(*args, **kwargs): pass
def MSetAttrEdit_swigregister(*args, **kwargs): pass
def MItMeshPolygon_point(*args, **kwargs): pass
def MCommandResult_stringResult(*args, **kwargs): pass
def MFnFloatArrayData_copyTo(*args, **kwargs): pass
def MFnSubd_vertexChildren(*args, **kwargs): pass
def MFnAmbientLight_ambientShade(*args, **kwargs): pass
def MFnDagNode_drawOverrideIsReference(*args, **kwargs): pass
def MDagPath_exclusiveMatrix(*args, **kwargs): pass
def MArgParser_flagArgumentMAngle(*args, **kwargs): pass
def MInt64Array_append(*args, **kwargs): pass
def MTimer___eq__(*args, **kwargs): pass
def MFnLight_setColor(*args, **kwargs): pass
def MPlug_asMDataHandle(*args, **kwargs): pass
def MFloatMatrix_homogenize(*args, **kwargs): pass
def MSelectionMask_registerSelectionType(*args, **kwargs): pass
def MMessage_setRegisteringCallableScriptNewAPI(*args, **kwargs): pass
def new_MItSubdEdge(*args, **kwargs): pass
def MFnSubd_vertexPositionGetNoEdit(*args, **kwargs): pass
def MFnLight_numShadowSamples(*args, **kwargs): pass
def MUuid_swigregister(*args, **kwargs): pass
def delete_MDagPath(*args, **kwargs): pass
def MCommandMessage_addCommandOutputFilterCallback(*args, **kwargs): pass
def MAngle_internalToUI(*args, **kwargs): pass
def MIntArray___getitem__(*args, **kwargs): pass
def MFnCamera_setFStop(*args, **kwargs): pass
def MStreamUtils_readCharBuffer(*args, **kwargs): pass
def MFloatMatrix___call__(*args, **kwargs): pass
def MSelectionList_hasItem(*args, **kwargs): pass
def MMessageNode_fNextNode_set(*args, **kwargs): pass
def MItMeshVertex_className(*args, **kwargs): pass
def MFnAnisotropyShader_className(*args, **kwargs): pass
def MFnSubd_collapse(*args, **kwargs): pass
def MItMeshPolygon_className(*args, **kwargs): pass
def MUserEventMessage_addUserEventCallback(*args, **kwargs): pass
def MDAGDrawOverrideInfo_fOverrideEnabled_set(*args, **kwargs): pass
def MPlane_setPlane(*args, **kwargs): pass
def MObject_kNullObj_set(*args, **kwargs): pass
def new_MIntArray(*args, **kwargs): pass
def MFnMesh_createColorSetWithNameDataMesh(*args, **kwargs): pass
def MFnCamera_horizontalFieldOfView(*args, **kwargs): pass
def MDataHandle_asString(*args, **kwargs): pass
def MFnMesh_copyInPlace(*args, **kwargs): pass
def MFloatArray_setSizeIncrement(*args, **kwargs): pass
def MSceneMessage_addConnectionFailedCallback(*args, **kwargs): pass
def MColor_r_set(*args, **kwargs): pass
def MItMeshVertex_getUVIndices(*args, **kwargs): pass
def MFnStringData_string(*args, **kwargs): pass
def MFnMesh_freeCachedIntersectionAccelerator(*args, **kwargs): pass
def MFnTransform_setRotation(*args, **kwargs): pass
def MURI_removeAllQueryItems(*args, **kwargs): pass
def MProfiler_addCategory(*args, **kwargs): pass
def MPlug_className(*args, **kwargs): pass
def MFnLight_setUseRayTraceShadows(*args, **kwargs): pass
def MFn_nodeType_set(*args, **kwargs): pass
def MImage_getDepthMapRange(*args, **kwargs): pass
def MFnMesh_setIntBlindData(*args, **kwargs): pass
def MFnCamera_setFilmRollValue(*args, **kwargs): pass
def MFileObject_path(*args, **kwargs): pass
def MFcurveEdit_swigregister(*args, **kwargs): pass
def new_MColor(*args, **kwargs): pass
def MItMeshVertex_next(*args, **kwargs): pass
def MFnSpotLight_setEndDistance(*args, **kwargs): pass
def MURI___eq__(*args, **kwargs): pass
def MFnMesh_numColors(*args, **kwargs): pass
def MFnTransform_getRotationQuaternion(*args, **kwargs): pass
def MURI_getScheme(*args, **kwargs): pass
def MDGModifier_removeMultiInstance(*args, **kwargs): pass
def MPlug_setInt64(*args, **kwargs): pass
def MFnNumericData_getData2Short(*args, **kwargs): pass
def MImageFileInfo_hasMipMaps(*args, **kwargs): pass
def MFnMesh_isBlindDataTypeUsed(*args, **kwargs): pass
def MMatrix_transpose(*args, **kwargs): pass
def MFnCamera_zoom(*args, **kwargs): pass
def MItMeshVertex_isDone(*args, **kwargs): pass
def MFileObject_rawFullName(*args, **kwargs): pass
def MAddRemoveAttrEdit_editType(*args, **kwargs): pass
def new_MColorArray(*args, **kwargs): pass
def MItMeshPolygon_numConnectedEdges(*args, **kwargs): pass
def new_MFnSpotLight(*args, **kwargs): pass
def MFnMesh_deleteEdge(*args, **kwargs): pass
def MFnTransform_getTranslation(*args, **kwargs): pass
def MURI___ne__(*args, **kwargs): pass
def MDGModifier_removeExtensionAttribute(*args, **kwargs): pass
def MFnSubdNames_swigregister(*args, **kwargs): pass
def MFnMesh_createColorSetDataMesh(*args, **kwargs): pass
def MIffFile_iffGetInt(*args, **kwargs): pass
def MFnMesh_removeFaceVertexColors(*args, **kwargs): pass
def MFnCamera_setShakeEnabled(*args, **kwargs): pass
def MFileIO_isImportingFile(*args, **kwargs): pass
def MEdit_editType(*args, **kwargs): pass
def MItMeshPolygon_getColorIndex(*args, **kwargs): pass
def MFnVolumeLight_setArc(*args, **kwargs): pass
def MColorArray___getitem__(*args, **kwargs): pass
def MFnGenericAttribute_create(*args, **kwargs): pass
def MFnAssembly_importFile(*args, **kwargs): pass
def MMeshSmoothOptions_openSubdivSmoothTriangles(*args, **kwargs): pass
def MPlug_child(*args, **kwargs): pass
def MFnCamera_getViewingFrustum(*args, **kwargs): pass
def MFileIO_beforeImportUserFileTranslator(*args, **kwargs): pass
def MEvaluationManager_graphConstructionActive(*args, **kwargs): pass
def MCacheFormatDescription_setTimePerFrame(*args, **kwargs): pass
def MItMeshPolygon_getNormal(*args, **kwargs): pass
def MFnSet_removeMember(*args, **kwargs): pass
def delete_MFnMatrixAttribute(*args, **kwargs): pass
def MUint64Array___radd__(*args, **kwargs): pass
def doublePtr_swigregister(*args, **kwargs): pass
def MPlug_partialName(*args, **kwargs): pass
def MGlobal_setDisableStow(*args, **kwargs): pass
def MScriptUtil_setDouble(*args, **kwargs): pass
def MFnMesh_getUVs(*args, **kwargs): pass
def delete_MFnCamera(*args, **kwargs): pass
def MFileIO_reference(*args, **kwargs): pass
def MRampAttribute_setPositionAtIndex(*args, **kwargs): pass
def MBoundingBox_contains(*args, **kwargs): pass
def MItMeshPolygon_isDone(*args, **kwargs): pass
def MFnPointLight_type(*args, **kwargs): pass
def new_MFnLightDataAttribute(*args, **kwargs): pass
def MFnUnitAttribute_getMax(*args, **kwargs): pass
def MFnDagNode_drawOverrideEnabled(*args, **kwargs): pass
def MUint64Array_remove(*args, **kwargs): pass
def MURI_setUserInfo(*args, **kwargs): pass
def shortPtr_value(*args, **kwargs): pass
def MPlugArray_setLength(*args, **kwargs): pass
def MGlobal_sourceFile(*args, **kwargs): pass
def MFnMesh_createUVSetWithName(*args, **kwargs): pass
def MGlobal_isUndoing(*args, **kwargs): pass
def MQuaternion_x_get(*args, **kwargs): pass
def MURI_setFileName(*args, **kwargs): pass
def MAttributePatternArray_set(*args, **kwargs): pass
def MItMeshFaceVertex_normalId(*args, **kwargs): pass
def MFnPluginData_className(*args, **kwargs): pass
def MFnLayeredShader_create(*args, **kwargs): pass
def MFnDagNode_fullPathName(*args, **kwargs): pass
def MTrimBoundaryArray_getMergedBoundary(*args, **kwargs): pass
def MObjectHandle_isValid(*args, **kwargs): pass
def MGlobal_setSelectionMode(*args, **kwargs): pass
def MEvaluationManager_swigregister(*args, **kwargs): pass
def MFnMesh_getBinormals(*args, **kwargs): pass
def MFnReflectShader_setReflectivity(*args, **kwargs): pass
def MQuaternion___sub__(*args, **kwargs): pass
def MItMeshEdge_onBoundary(*args, **kwargs): pass
def MFnPhongEShader_setRoughness(*args, **kwargs): pass
def MFnNumericAttribute_setDefault(*args, **kwargs): pass
def MFnIntArrayData_copyTo(*args, **kwargs): pass
def MScriptUtil_setUchar(*args, **kwargs): pass
def MFnDagNode_childCount(*args, **kwargs): pass
def MTransformationMatrix_getRotationQuaternion(*args, **kwargs): pass
def MObjectArray_set(*args, **kwargs): pass
def MGlobal_getSelectionListByName(*args, **kwargs): pass
def MFnMesh_getFaceNormalIds(*args, **kwargs): pass
def MFnLambertShader_setIncandescence(*args, **kwargs): pass
def MEvaluationManager_evaluationManagerActive(*args, **kwargs): pass
def MScriptUtil_setUint4ArrayItem(*args, **kwargs): pass
def MScriptUtil_getInt(*args, **kwargs): pass
def MItMeshEdge_point(*args, **kwargs): pass
def MFnNurbsSurface_tesselate(*args, **kwargs): pass
def MFnGeometryData_removeObjectGroup(*args, **kwargs): pass
def MFnDependencyNode_dgTimer(*args, **kwargs): pass
def MTransformationMatrix_setShear(*args, **kwargs): pass
def MNurbsIntersector_isCreated(*args, **kwargs): pass
def MFnDoubleIndexedComponent_addElements(*args, **kwargs): pass
def MFnVolumeLight_coneEndRadius(*args, **kwargs): pass
def MFnGeometryData_type(*args, **kwargs): pass
def new_MFnLambertShader(*args, **kwargs): pass
def MEulerRotation_decompose(*args, **kwargs): pass
def MScriptUtil_getFloat2ArrayItem(*args, **kwargs): pass
def MFnSubd_vertexCount(*args, **kwargs): pass
def uCharPtr_swigregister(*args, **kwargs): pass
def MItInstancer_isDone(*args, **kwargs): pass
def MFnNurbsSurface_numPatches(*args, **kwargs): pass
def MFnGenericAttribute_addDataAccept(*args, **kwargs): pass
def MFnDependencyNode_setAlias(*args, **kwargs): pass
def MFnLight_lightAmbient(*args, **kwargs): pass
def MNodeMessage_addAttributeChangedCallback(*args, **kwargs): pass
def MFnVectorArrayData_length(*args, **kwargs): pass
def MDataHandle_acceptedTypeIds(*args, **kwargs): pass
def MFnAttribute_setInternal(*args, **kwargs): pass
def MDataHandle_assign(*args, **kwargs): pass
def MEulerRotation___ne__(*args, **kwargs): pass
def new_MFnComponent(*args, **kwargs): pass
def MScriptUtil_createMatrixFromList(*args, **kwargs): pass
def boolPtr_value(*args, **kwargs): pass
def MItGeometry_weight(*args, **kwargs): pass
def MURI_setHost(*args, **kwargs): pass
def MFnNurbsSurface_getPointAtParam(*args, **kwargs): pass
def MFnExpression_swigregister(*args, **kwargs): pass
def MFnDependencyNode_isTrackingEdits(*args, **kwargs): pass
def MTimer___ne__(*args, **kwargs): pass
def MFnUnitAttribute_hasSoftMin(*args, **kwargs): pass
def new_MFnGeometryData(*args, **kwargs): pass
def MFnAttribute_setStorable(*args, **kwargs): pass
def MDataHandle_setMPxData(*args, **kwargs): pass
def MDoubleArray_swigregister(*args, **kwargs): pass
def MScriptUtil_setShortArray(*args, **kwargs): pass
def MAttributeSpec_className(*args, **kwargs): pass
def delete_MIteratorType(*args, **kwargs): pass
def MFnNurbsSurface_setKnotsInV(*args, **kwargs): pass
def MFnEnumAttribute_defaultValue(*args, **kwargs): pass
def MTesselationParams_setFormatType(*args, **kwargs): pass
def MPointArray_assign(*args, **kwargs): pass
def MTime___iadd__(*args, **kwargs): pass
def delete_MFnNumericAttribute(*args, **kwargs): pass
def MNamespace_getNamespaces(*args, **kwargs): pass
def new_MFnUint64SingleIndexedComponent(*args, **kwargs): pass
def MFloatArray___ne__(*args, **kwargs): pass
def MFnAttribute_isHidden(*args, **kwargs): pass
def MDataHandle_setMFloatMatrix(*args, **kwargs): pass
def MDoubleArray_append(*args, **kwargs): pass
def MScriptUtil_setInt(*args, **kwargs): pass
def MAttributeSpecArray_insert(*args, **kwargs): pass
def delete_MItEdits(*args, **kwargs): pass
def MFnGeometryData_getMatrix(*args, **kwargs): pass
def MFnNurbsSurface_isKnotU(*args, **kwargs): pass
def MFnDoubleIndexedComponent_getElement(*args, **kwargs): pass
def MFloatVector_z_get(*args, **kwargs): pass
def delete_MTime(*args, **kwargs): pass
def MPointOnMesh_triangleIndex(*args, **kwargs): pass
def MMatrixArray_sizeIncrement(*args, **kwargs): pass
def MFnTypedAttribute_getDefault(*args, **kwargs): pass
def MDoubleArray___iadd__(*args, **kwargs): pass
def MComputation_setProgress(*args, **kwargs): pass
def MFnArrayAttrsData_getDoubleData(*args, **kwargs): pass
def MDataHandle_asNurbsSurface(*args, **kwargs): pass
def MDistance_asMeters(*args, **kwargs): pass
def MScriptUtil_asCharPtr(*args, **kwargs): pass
def MAttributeIndex_setType(*args, **kwargs): pass
def MFnCamera_setHorizontalFilmAperture(*args, **kwargs): pass
def delete_MFnNurbsSurface(*args, **kwargs): pass
def delete_MFnDoubleArrayData(*args, **kwargs): pass
def MDataHandle_setMTime(*args, **kwargs): pass
def MFloatVector___isub__(*args, **kwargs): pass
def new_MTimeArray(*args, **kwargs): pass
def MScriptUtil_setIntArray(*args, **kwargs): pass
def MMatrix_matrix_set(*args, **kwargs): pass
def delete_MFnTripleIndexedComponent(*args, **kwargs): pass
def MDataHandle_asLong2(*args, **kwargs): pass
def MCameraMessage_swigregister(*args, **kwargs): pass
def MScriptUtil_createFromInt(*args, **kwargs): pass
def MBoundingBox_expand(*args, **kwargs): pass
def new_MArrayDataHandle(*args, **kwargs): pass
def MItDependencyGraph_toggleDirection(*args, **kwargs): pass
def MFnNumericAttribute_createPoint(*args, **kwargs): pass
def MFnCameraSet_insertLayer(*args, **kwargs): pass
def MFloatVectorArray_get(*args, **kwargs): pass
def MTesselationParams_setWorldspaceToScreenTransform(*args, **kwargs): pass
def MDagMessage_addParentAddedDagPathCallback(*args, **kwargs): pass
def MMatrix_setToIdentity(*args, **kwargs): pass
def MFnSubdNames_baseFaceIndex(*args, **kwargs): pass
def MFnNonExtendedLight_setDepthMapBias(*args, **kwargs): pass
def MFnGeometryData_addObjectGroup(*args, **kwargs): pass
def MDGMessage_addConnectionCallback(*args, **kwargs): pass
def MProfiler_getAllCategories(*args, **kwargs): pass
def MFnNurbsCurveData_swigregister(*args, **kwargs): pass
def MArrayDataBuilder_assign(*args, **kwargs): pass
def delete_MItDag(*args, **kwargs): pass
def MFnNurbsCurve_getKnots(*args, **kwargs): pass
def MFnDirectionalLight_type(*args, **kwargs): pass
def MFloatPoint_w_set(*args, **kwargs): pass
def new_MTesselationParams(*args, **kwargs): pass
def MCurveAttribute_getEntries(*args, **kwargs): pass
def MItSurfaceCV_updateSurface(*args, **kwargs): pass
def MEvaluationNode_className(*args, **kwargs): pass
def MFnSubd_getConnectedShaders(*args, **kwargs): pass
def MFnNonAmbientLight_setDecayRate(*args, **kwargs): pass
def MDGContext_isNormal(*args, **kwargs): pass
def MProfiler_getThreadId(*args, **kwargs): pass
def MFnUInt64ArrayData_className(*args, **kwargs): pass
def MItCurveCV_cv(*args, **kwargs): pass
def MArgList_asIntArray(*args, **kwargs): pass
def MItDag_reset(*args, **kwargs): pass
def delete_MFnNurbsCurve(*args, **kwargs): pass
def MScriptUtil_setUintArray(*args, **kwargs): pass
def MFnComponentListData___getitem__(*args, **kwargs): pass
def MSyntax_assign(*args, **kwargs): pass
def MConditionMessage_getConditionNames(*args, **kwargs): pass
def MItSubdVertex_swigregister(*args, **kwargs): pass
def MFnSubd_polygonVertices(*args, **kwargs): pass
def MColor___iadd__(*args, **kwargs): pass
def MVector___eq__(*args, **kwargs): pass
def MFnVectorArrayData_array(*args, **kwargs): pass
def MDagPath_getAPathTo(*args, **kwargs): pass
def MPoint_className(*args, **kwargs): pass
def MArgDatabase_getCommandArgument(*args, **kwargs): pass
def MInt64Array_swigregister(*args, **kwargs): pass
def MFnNumericData_setData2Short(*args, **kwargs): pass
def MFnComponent_elementCount(*args, **kwargs): pass
def MFloatPointArray_copy(*args, **kwargs): pass
def MCommandResult_getResult(*args, **kwargs): pass
def MItSubdFace_isDone(*args, **kwargs): pass
def new_MEvaluationNodeIterator(*args, **kwargs): pass
def MFnSubd_creasesGetAll(*args, **kwargs): pass
def MDagPath_getDisplayStatus(*args, **kwargs): pass
def MFnAmbientLight_setAmbientShade(*args, **kwargs): pass
def new_MVector(*args, **kwargs): pass
def MDagPath_inclusiveMatrixInverse(*args, **kwargs): pass
def MPoint___imul__(*args, **kwargs): pass
def MArgParser_flagArgumentMTime(*args, **kwargs): pass
def MInt64Array_copy(*args, **kwargs): pass
def delete_MPlane(*args, **kwargs): pass
def MEvaluationNodeIterator_assign(*args, **kwargs): pass
def MFnCamera_setOrthoWidth(*args, **kwargs): pass
def MFloatMatrix_det4x4(*args, **kwargs): pass
def MSelectionMask_deregisterSelectionType(*args, **kwargs): pass
def MMessage_registeringCallableScriptNewAPI(*args, **kwargs): pass
def MFnSubd_vertexPositionSet(*args, **kwargs): pass
def MFloatVector_get(*args, **kwargs): pass
def MFnLight_setNumShadowSamples(*args, **kwargs): pass
def MRichSelection_className(*args, **kwargs): pass
def new_MVectorArray(*args, **kwargs): pass
def new_MConditionMessage(*args, **kwargs): pass
def MPointArray_get(*args, **kwargs): pass
def MAngle_uiToInternal(*args, **kwargs): pass
def MIntArray___delitem__(*args, **kwargs): pass
def MFnNumericAttribute_create(*args, **kwargs): pass
def MFnCamera_fStop(*args, **kwargs): pass
def MFloatMatrix___getitem__(*args, **kwargs): pass
def MSelectionList_hasItemPartly(*args, **kwargs): pass
def MItSelectionList_next(*args, **kwargs): pass
def MMessageNode_fNextNode_get(*args, **kwargs): pass
def MItMeshVertex_swigregister(*args, **kwargs): pass
def MFnAttribute_getCategories(*args, **kwargs): pass
def delete_MFnVolumeLight(*args, **kwargs): pass
def MFnContainerNode_getCurrentAsMObject(*args, **kwargs): pass
def MUserEventMessage_postUserEvent(*args, **kwargs): pass
def MDAGDrawOverrideInfo_fOverrideEnabled_get(*args, **kwargs): pass
def MPlane_distance(*args, **kwargs): pass
def MObject_swigregister(*args, **kwargs): pass
def delete_MIntArray(*args, **kwargs): pass
def MFnMesh_swigregister(*args, **kwargs): pass
def MFnCamera_setVerticalFieldOfView(*args, **kwargs): pass
def MFnNumericAttribute_getMin(*args, **kwargs): pass
def MFloatArray_sizeIncrement(*args, **kwargs): pass
def MColor_r_get(*args, **kwargs): pass
def MItMeshVertex_updateSurface(*args, **kwargs): pass
def MFnLightDataAttribute_getDefault(*args, **kwargs): pass
def MFnStringData_set(*args, **kwargs): pass
def MFnMesh_cachedIntersectionAcceleratorInfo(*args, **kwargs): pass
def MFnTransform_translation(*args, **kwargs): pass
def MIntArray___ne__(*args, **kwargs): pass
def delete_MDagPathArray(*args, **kwargs): pass
def MPlug_asMObject(*args, **kwargs): pass
def delete_MFnAnisotropyShader(*args, **kwargs): pass
def MFn_nodeType_get(*args, **kwargs): pass
def MImage_setDepthMap(*args, **kwargs): pass
def MFnMesh_setFloatBlindData(*args, **kwargs): pass
def MFnCamera_filmRollValue(*args, **kwargs): pass
def MFileObject_fullName(*args, **kwargs): pass
def new_MRichSelection(*args, **kwargs): pass
def MFnMesh_getIntBlindData(*args, **kwargs): pass
def MItMeshVertex_reset(*args, **kwargs): pass
def MFnSpotLight_swigregister(*args, **kwargs): pass
def MURI_getQueryItemValue(*args, **kwargs): pass
def MFnMesh_numNormals(*args, **kwargs): pass
def MFnTransform_setRotationQuaternion(*args, **kwargs): pass
def MURI_getPath(*args, **kwargs): pass
def MDGModifier_setMetadata(*args, **kwargs): pass
def MPlug_setInt(*args, **kwargs): pass
def delete_MImageFileInfo(*args, **kwargs): pass
def MFnMesh_createBlindDataType(*args, **kwargs): pass
def MPlane_swigregister(*args, **kwargs): pass
def MItMeshVertex_onBoundary(*args, **kwargs): pass
def MAddRemoveAttrEdit_className(*args, **kwargs): pass
def MFnSubd_vertexSetCrease(*args, **kwargs): pass
def delete_MColorArray(*args, **kwargs): pass
def MItMeshPolygon_onBoundary(*args, **kwargs): pass
def MFnSpotLight_create(*args, **kwargs): pass
def MFnMesh_deleteVertex(*args, **kwargs): pass
def MFnTransform_setTranslation(*args, **kwargs): pass
def MURI_copy(*args, **kwargs): pass
def MDGModifier_removeExtensionAttributeIfUnset(*args, **kwargs): pass
def MPlug_isCachingFlagSet(*args, **kwargs): pass
def MFnNumericAttribute_setMin(*args, **kwargs): pass
def MIffFile_iffGetFloat(*args, **kwargs): pass
def MFnMesh_getVertexColors(*args, **kwargs): pass
def MFnCamera_horizontalShake(*args, **kwargs): pass
def MFileIO_isReferencingFile(*args, **kwargs): pass
def MEdit_getString(*args, **kwargs): pass
def MItDependencyGraph_atNodeLevel(*args, **kwargs): pass
def delete_MCallbackIdArray(*args, **kwargs): pass
def MItMeshPolygon_getColorIndices(*args, **kwargs): pass
def delete_MFnNumericData(*args, **kwargs): pass
def MFnSingleIndexedComponent_getElements(*args, **kwargs): pass
def delete_MContainerMessage(*args, **kwargs): pass
def MFnMeshData_type(*args, **kwargs): pass
def MFnAssembly_getAbsoluteRepNamespace(*args, **kwargs): pass
def MUintArray___len__(*args, **kwargs): pass
def MMeshSmoothOptions_setOpenSubdivCreaseMethod(*args, **kwargs): pass
def MPlug_parent(*args, **kwargs): pass
def MGlobal_isRedoing(*args, **kwargs): pass
def MDGModifier_newPlugValueFloat(*args, **kwargs): pass
def MFnCamera_getRenderingFrustum(*args, **kwargs): pass
def MNodeClass_attribute(*args, **kwargs): pass
def MScriptUtil_getCharArrayItem(*args, **kwargs): pass
def MRenderPassDef_getImplementation(*args, **kwargs): pass
def MCacheFormatDescription_addDescriptionInfo(*args, **kwargs): pass
def MItMeshPolygon_getNormals(*args, **kwargs): pass
def MFnSet_removeMembers(*args, **kwargs): pass
def MFnMatrixAttribute_className(*args, **kwargs): pass
def MFnAssembly_activate(*args, **kwargs): pass
def MUint64Array___iadd__(*args, **kwargs): pass
def MFnMesh_setColors(*args, **kwargs): pass
def new_boolPtr(*args, **kwargs): pass
def MPlug_getSetAttrCmds(*args, **kwargs): pass
def MItMeshVertex_getColorIndices(*args, **kwargs): pass
def MFnMesh_setUV(*args, **kwargs): pass
def MFnCamera_className(*args, **kwargs): pass
def MQuaternion_y_get(*args, **kwargs): pass
def MFileIO_removeReference(*args, **kwargs): pass
def MRampAttribute_setInterpolationAtIndex(*args, **kwargs): pass
def MBoundingBox_intersects(*args, **kwargs): pass
def MItMeshPolygon_next(*args, **kwargs): pass
def MFnDagNode_transformationMatrix(*args, **kwargs): pass
def delete_MFnPointLight(*args, **kwargs): pass
def MFnLightDataAttribute_create(*args, **kwargs): pass
def MURI_isEmpty(*args, **kwargs): pass
def MUint64Array_insert(*args, **kwargs): pass
def shortPtr_cast(*args, **kwargs): pass
def MPlugArray_length(*args, **kwargs): pass
def MGlobal_executeCommandOnIdle(*args, **kwargs): pass
def MFnMesh_createUVSetDataMeshWithName(*args, **kwargs): pass
def MFnReference_fileName(*args, **kwargs): pass
def new_MAngle(*args, **kwargs): pass
def MFileIO_open(*args, **kwargs): pass
def MQuaternion_y_set(*args, **kwargs): pass
def MFnIntArrayData___getitem__(*args, **kwargs): pass
def MAttributePatternArray_setLength(*args, **kwargs): pass
def MItMeshFaceVertex_tangentId(*args, **kwargs): pass
def MFnCamera_panZoomEnabled(*args, **kwargs): pass
def new_MFnPluginData(*args, **kwargs): pass
def MFnLayeredShader_compositingFlag(*args, **kwargs): pass
def MFnDagNode_partialPathName(*args, **kwargs): pass
def MObjectHandle_isAlive(*args, **kwargs): pass
def MGlobal_objectSelectionMask(*args, **kwargs): pass
def MItSelectionList_isDone(*args, **kwargs): pass
def MFnMesh_getFaceVertexBinormal(*args, **kwargs): pass
def MFnReflectShader_reflectedColor(*args, **kwargs): pass
def delete_MEvaluationNodeIterator(*args, **kwargs): pass
def MQuaternion___neg__(*args, **kwargs): pass
def array2dDouble_getptr(*args, **kwargs): pass
def MItMeshEdge_getLength(*args, **kwargs): pass
def MURI_swigregister(*args, **kwargs): pass
def MFnDagNode_child(*args, **kwargs): pass
def MTransformationMatrix_setRotationQuaternion(*args, **kwargs): pass
def MObjectArray_setLength(*args, **kwargs): pass
def MGlobal_getActiveSelectionList(*args, **kwargs): pass
def MFnMesh_setFaceVertexNormal(*args, **kwargs): pass
def MFnLambertShader_translucenceCoeff(*args, **kwargs): pass
def MScriptUtil_swigregister(*args, **kwargs): pass
def MFnVolumeLight_emitAmbient(*args, **kwargs): pass
def MFnNurbsCurve_setCVs(*args, **kwargs): pass
def array2dFloat_swigregister(*args, **kwargs): pass
def MItMeshEdge_setPoint(*args, **kwargs): pass
def MFnNurbsSurface_swigregister(*args, **kwargs): pass
def MFnGeometryData_changeObjectGroupId(*args, **kwargs): pass
def MFnDependencyNode_dgCallbacks(*args, **kwargs): pass
def MTransformationMatrix_getShear(*args, **kwargs): pass
def MNurbsIntersector_getClosestPoint(*args, **kwargs): pass
def MFnVolumeLight_setConeEndRadius(*args, **kwargs): pass
def MFnIntArrayData_array(*args, **kwargs): pass
def MFnMesh_syncObject(*args, **kwargs): pass
def MFnLambertShader_create(*args, **kwargs): pass
def MEulerRotation_x_set(*args, **kwargs): pass
def MScriptUtil_setFloat2ArrayItem(*args, **kwargs): pass
def new_array3dInt(*args, **kwargs): pass
def MItInstancer_instancer(*args, **kwargs): pass
def MFnNurbsSurface_numPatchesInU(*args, **kwargs): pass
def MFnGenericAttribute_addNumericDataAccept(*args, **kwargs): pass
def MCurveAttribute_deleteEntries(*args, **kwargs): pass
def MTransformationMatrix_setScale(*args, **kwargs): pass
def MNodeMessage_addAttributeAddedOrRemovedCallback(*args, **kwargs): pass
def MFnVectorArrayData_copyTo(*args, **kwargs): pass
def MMessageNode_fId_get(*args, **kwargs): pass
def MFnAttribute_setNiceNameOverride(*args, **kwargs): pass
def new_MDataHandle(*args, **kwargs): pass
def MDGContext_className(*args, **kwargs): pass
def MEulerRotation_isEquivalent(*args, **kwargs): pass
def MScriptUtil_createFloatMatrixFromList(*args, **kwargs): pass
def boolPtr_cast(*args, **kwargs): pass
def MScriptUtil_getInt3ArrayItem(*args, **kwargs): pass
def MFnNurbsSurface_distanceToPoint(*args, **kwargs): pass
def MFnFloatArrayData_type(*args, **kwargs): pass
def MFnDependencyNode_hasUniqueName(*args, **kwargs): pass
def MTimer_clear(*args, **kwargs): pass
def MNodeClass_typeId(*args, **kwargs): pass
def MFnUnitAttribute_hasSoftMax(*args, **kwargs): pass
def MItSelectionList_getPlug(*args, **kwargs): pass
def MFnAttribute_setCached(*args, **kwargs): pass
def MDataHandle_asGenericBool(*args, **kwargs): pass
def MPlug_destinations(*args, **kwargs): pass
def new_MEulerRotation(*args, **kwargs): pass
def MScriptUtil_setFloatArray(*args, **kwargs): pass
def MAttributeSpec_swigregister(*args, **kwargs): pass
def MIteratorType_setFilterType(*args, **kwargs): pass
def MFnNurbsSurface_knotInU(*args, **kwargs): pass
def MFnEnumAttribute_swigregister(*args, **kwargs): pass
def MCurveAttribute_setValueAtIndex(*args, **kwargs): pass
def MFnDependencyNode_absoluteName(*args, **kwargs): pass
def MTime___sub__(*args, **kwargs): pass
def MFnNumericData_numericType(*args, **kwargs): pass
def MNamespace_namespaceExists(*args, **kwargs): pass
def MFnUint64SingleIndexedComponent_create(*args, **kwargs): pass
def MFnAttribute_isUsedAsColor(*args, **kwargs): pass
def MDoubleArray_copy(*args, **kwargs): pass
def MScriptUtil_setShort(*args, **kwargs): pass
def MAttributeSpecArray_append(*args, **kwargs): pass
def MItEdits_reset(*args, **kwargs): pass
def MScriptUtil_setInt4ArrayItem(*args, **kwargs): pass
def MFnNurbsSurface_isKnotV(*args, **kwargs): pass
def MFnDoubleIndexedComponent_getElements(*args, **kwargs): pass
def MFloatVector_swigregister(*args, **kwargs): pass
def MTime_unit(*args, **kwargs): pass
def delete_MPointOnMesh(*args, **kwargs): pass
def MMatrixArray_className(*args, **kwargs): pass
def MFnTypedAttribute_setDefault(*args, **kwargs): pass
def MItMeshPolygon_getUVs(*args, **kwargs): pass
def MCurveAttribute_sampleValueCurve(*args, **kwargs): pass
def MFnArrayAttrsData_getIntData(*args, **kwargs): pass
def MDataHandle_asMesh(*args, **kwargs): pass
def MDistance_uiUnit(*args, **kwargs): pass
def MScriptUtil_asUcharPtr(*args, **kwargs): pass
def MAttributeIndex_setValue(*args, **kwargs): pass
def MItDependencyGraph_getNodesVisited(*args, **kwargs): pass
def MFnNurbsSurface_className(*args, **kwargs): pass
def MFnDoubleArrayData_className(*args, **kwargs): pass
def MFloatVector___imul__(*args, **kwargs): pass
def delete_MTimeArray(*args, **kwargs): pass
def MItSelectionList_hasComponents(*args, **kwargs): pass
def MDagMessage_className(*args, **kwargs): pass
def MMatrix_matrix_get(*args, **kwargs): pass
def MFnTripleIndexedComponent_className(*args, **kwargs): pass
def MFnData_swigregister(*args, **kwargs): pass
def MDataHandle_asInt2(*args, **kwargs): pass
def new_MDistance(*args, **kwargs): pass
def MScriptUtil_createFromDouble(*args, **kwargs): pass
def MWeight_className(*args, **kwargs): pass
def MArrayDataHandle_assign(*args, **kwargs): pass
def MFnNumericData_getData2Double(*args, **kwargs): pass
def MFnNurbsCurve_distanceToPoint(*args, **kwargs): pass
def MFnCameraSet_deleteLayer(*args, **kwargs): pass
def MFloatVectorArray_setSizeIncrement(*args, **kwargs): pass
def MTesselationParams_setMaxUVRectangleSize(*args, **kwargs): pass
def MDagMessage_addParentRemovedCallback(*args, **kwargs): pass
def MMatrix_setToProduct(*args, **kwargs): pass
def MFnSubdNames_baseFaceIndexFromId(*args, **kwargs): pass
def MFnAnisotropyShader_swigregister(*args, **kwargs): pass
def MDGMessage_addPreConnectionCallback(*args, **kwargs): pass
def MProfiler_swigregister(*args, **kwargs): pass
def delete_MArrayDataBuilder(*args, **kwargs): pass
def MItDag_className(*args, **kwargs): pass
def MFnNurbsCurve_setKnots(*args, **kwargs): pass
def delete_MFnDirectionalLight(*args, **kwargs): pass
def MPlug_isProcedural(*args, **kwargs): pass
def MFloatPoint_w_get(*args, **kwargs): pass
def delete_MTesselationParams(*args, **kwargs): pass
def MCurveAttribute_addEntries(*args, **kwargs): pass
def MUserEventMessage_deregisterUserEvent(*args, **kwargs): pass
def MFnSubd_tesselate(*args, **kwargs): pass
def MFnNonAmbientLight_swigregister(*args, **kwargs): pass
def MDGContext_getTime(*args, **kwargs): pass
def MGlobal_resetToDefaultErrorLogPathName(*args, **kwargs): pass
def MArgList_asDoubleArray(*args, **kwargs): pass
def MItDag_item(*args, **kwargs): pass
def MFnNurbsCurve_className(*args, **kwargs): pass
def MScriptUtil_setShort4ArrayItem(*args, **kwargs): pass
def MFnComponentListData_add(*args, **kwargs): pass
def MFloatPoint___truediv__(*args, **kwargs): pass
def MSyntax_addFlag(*args, **kwargs): pass
def MConditionMessage_getConditionState(*args, **kwargs): pass
def new_MItSurfaceCV(*args, **kwargs): pass
def MItMeshPolygon_getPointAtUV(*args, **kwargs): pass
def MFnAnisotropyShader_correlationY(*args, **kwargs): pass
def MVector_rotateBy(*args, **kwargs): pass
def MItMeshVertex_getUVs(*args, **kwargs): pass
def MDagPath_swigregister(*args, **kwargs): pass
def MPoint_swigregister(*args, **kwargs): pass
def MArgDatabase_getObjects(*args, **kwargs): pass
def new_MItCurveCV(*args, **kwargs): pass
def MFnNumericData_setData2Int(*args, **kwargs): pass
def MFnComponent_componentType(*args, **kwargs): pass
def MCommandResult_className(*args, **kwargs): pass
def MItSubdFace_isValid(*args, **kwargs): pass
def new_MFnLayeredShader(*args, **kwargs): pass
def MFnSubd_creasesSetAll(*args, **kwargs): pass
def MFnAmbientLight_castSoftShadows(*args, **kwargs): pass
def MProfiler_getCategoryInfo(*args, **kwargs): pass
def MDagPath_exclusiveMatrixInverse(*args, **kwargs): pass
def MPoint___eq__(*args, **kwargs): pass
def MInt64Array_clear(*args, **kwargs): pass
def MFnSubd_vertexNormal(*args, **kwargs): pass
def MFileIO_getReferenceConnectionsBroken(*args, **kwargs): pass
def MFnCamera_orthoWidth(*args, **kwargs): pass
def MFloatMatrix_det3x3(*args, **kwargs): pass
def MMessage_className(*args, **kwargs): pass
def MItSubdEdge_reset(*args, **kwargs): pass
def MFnSubd_vertexEditSet(*args, **kwargs): pass
def MFnLight_rayDepthLimit(*args, **kwargs): pass
def MDagMessage_addParentAddedCallback(*args, **kwargs): pass
def MDagPath_getAllPathsBelow(*args, **kwargs): pass
def MPointArray_setSizeIncrement(*args, **kwargs): pass
def MItCurveCV_translateBy(*args, **kwargs): pass
def MAngle_className(*args, **kwargs): pass
def MIntArray___repr__(*args, **kwargs): pass
def MFnCamera_setFocusDistance(*args, **kwargs): pass
def MFloatMatrix_get(*args, **kwargs): pass
def MSelectionList_toggle(*args, **kwargs): pass
def MFnVolumeLight_setShadowAngle(*args, **kwargs): pass
def MMessageNode_fHeadNode_set(*args, **kwargs): pass
def MGlobal_getLiveList(*args, **kwargs): pass
def MFnSubd_polygonBaseMeshAdd(*args, **kwargs): pass
def MFnContainerNode_swigregister(*args, **kwargs): pass
def MUserEventMessage_className(*args, **kwargs): pass
def MPlane_directedDistance(*args, **kwargs): pass
def MIntArray_assign(*args, **kwargs): pass
def new_MMeshIsectAccelParams(*args, **kwargs): pass
def MFnLayeredShader_color(*args, **kwargs): pass
def MFloatArray_className(*args, **kwargs): pass
def MSceneMessage_className(*args, **kwargs): pass
def MColor_g_set(*args, **kwargs): pass
def MItMeshVertex_geomChanged(*args, **kwargs): pass
def MFnStringData_create(*args, **kwargs): pass
def MFnMesh_globalIntersectionAcceleratorsInfo(*args, **kwargs): pass
def MUint64Array___setitem__(*args, **kwargs): pass
def MFnTransform_swigregister(*args, **kwargs): pass
def MURI_isValid(*args, **kwargs): pass
def MDagPathArray___getitem__(*args, **kwargs): pass
def delete_MFn(*args, **kwargs): pass
def MImage_depthMap(*args, **kwargs): pass
def MFnMesh_setDoubleBlindData(*args, **kwargs): pass
def MFnCamera_setFilmRollOrder(*args, **kwargs): pass
def MFileObject_isAbsolutePath(*args, **kwargs): pass
def MVectorArray_get(*args, **kwargs): pass
def delete_MRichSelection(*args, **kwargs): pass
def MColor_assign(*args, **kwargs): pass
def MItMeshVertex_count(*args, **kwargs): pass
def MFnStringArrayData_type(*args, **kwargs): pass
def MDagMessage_addChildAddedCallback(*args, **kwargs): pass
def MFnTransform_rotateByQuaternion(*args, **kwargs): pass
def MURI_getFragment(*args, **kwargs): pass
def MDGModifier_deleteMetadata(*args, **kwargs): pass
def MPlug_setShort(*args, **kwargs): pass
def MImageFileInfo_swigregister(*args, **kwargs): pass
def MFnMesh_hasBlindDataComponentId(*args, **kwargs): pass
def MFnMesh_extractFaces(*args, **kwargs): pass
def MFnCamera_setZoom(*args, **kwargs): pass
def MItSubdEdge_index(*args, **kwargs): pass
def MFileObject_expandedPath(*args, **kwargs): pass
def MAddRemoveAttrEdit_swigregister(*args, **kwargs): pass
def MItMeshPolygon_getArea(*args, **kwargs): pass
def MFnSpotLight_coneAngle(*args, **kwargs): pass
def boolPtr_frompointer(*args, **kwargs): pass
def MFnMesh_split(*args, **kwargs): pass
def MFnTransform_translateBy(*args, **kwargs): pass
def MURI_setURI(*args, **kwargs): pass
def MDGModifier_linkExtensionAttributeToPlugin(*args, **kwargs): pass
def MPlug_setCaching(*args, **kwargs): pass
def MFnNumericData_setData3Double(*args, **kwargs): pass
def MIffFile_className(*args, **kwargs): pass
def MFnMesh_getFaceVertexColors(*args, **kwargs): pass
def MCommandMessage_addCommandCallback(*args, **kwargs): pass
def MFnCamera_setHorizontalShake(*args, **kwargs): pass
def MFileIO_currentlyReadingFileVersion(*args, **kwargs): pass
def MEdit_isApplied(*args, **kwargs): pass
def MCallbackIdArray___getitem__(*args, **kwargs): pass
def MItMeshPolygon_hasValidTriangulation(*args, **kwargs): pass
def MFnCamera_filmFit(*args, **kwargs): pass
def intPtr_assign(*args, **kwargs): pass
def MFnNonExtendedLight_setShadowRadius(*args, **kwargs): pass
def delete_MFnMeshData(*args, **kwargs): pass
def MFnAssembly_isTopLevel(*args, **kwargs): pass
def MUintArray___setitem__(*args, **kwargs): pass
def MMeshSmoothOptions_openSubdivCreaseMethod(*args, **kwargs): pass
def MPlug_array(*args, **kwargs): pass
def MGlobal_className(*args, **kwargs): pass
def MFnMesh_setCurrentColorSetName(*args, **kwargs): pass
def MUuid_asString(*args, **kwargs): pass
def MFileIO_beforeExportUserFileTranslator(*args, **kwargs): pass
def MRenderPassDef_getID(*args, **kwargs): pass
def MCacheFormatDescription_addChannel(*args, **kwargs): pass
def MItMeshPolygon_tangentIndex(*args, **kwargs): pass
def MFnSet_isMember(*args, **kwargs): pass
def new_MFnMatrixAttribute(*args, **kwargs): pass
def MFnAssembly_getActive(*args, **kwargs): pass
def MUint64Array_swigregister(*args, **kwargs): pass
def MEulerRotation_asVector(*args, **kwargs): pass
def delete_boolPtr(*args, **kwargs): pass
def MPlug_isNetworked(*args, **kwargs): pass
def MItSubdEdge_className(*args, **kwargs): pass
def MGlobal_optionVarIntValue(*args, **kwargs): pass
def MFnMesh_getUV(*args, **kwargs): pass
def new_MFnCamera(*args, **kwargs): pass
def MParentingEdit_parent(*args, **kwargs): pass
def MFileIO_isReadingFile(*args, **kwargs): pass
def MRampAttribute_isColorRamp(*args, **kwargs): pass
def MBoundingBox_width(*args, **kwargs): pass
def MItMeshPolygon_reset(*args, **kwargs): pass
def MFnLight_lightIntensity(*args, **kwargs): pass
def MFnPointLight_className(*args, **kwargs): pass
def MGlobal_select(*args, **kwargs): pass
def MTypeId_className(*args, **kwargs): pass
def MFnDagNode_drawOverrideIsTemplate(*args, **kwargs): pass
def MUint64Array_append(*args, **kwargs): pass
def shortPtr_frompointer(*args, **kwargs): pass
def MPlugArray_remove(*args, **kwargs): pass
def MGlobal_executeCommand(*args, **kwargs): pass
def MFnMesh_copyUVSetWithName(*args, **kwargs): pass
def MFnDagNode_objectColorType(*args, **kwargs): pass
def MFnReference_associatedNamespace(*args, **kwargs): pass
def MFileIO_save(*args, **kwargs): pass
def MFnNonExtendedLight_setUseDepthMapShadows(*args, **kwargs): pass
def MAttributePatternArray_length(*args, **kwargs): pass
def MItMeshFaceVertex_getTangent(*args, **kwargs): pass
def delete_MFnCameraSet(*args, **kwargs): pass
def MFnPluginData_typeId(*args, **kwargs): pass
def MFnLayeredShader_setCompositingFlag(*args, **kwargs): pass
def MTrimBoundaryArray_swigregister(*args, **kwargs): pass
def charPtr_assign(*args, **kwargs): pass
def MObjectHandle___eq__(*args, **kwargs): pass
def MGlobal_setObjectSelectionMask(*args, **kwargs): pass
def MFileIO_beforeImportFilename(*args, **kwargs): pass
def MFnMesh_getFaceVertexBinormals(*args, **kwargs): pass
def MFnReflectShader_setReflectedColor(*args, **kwargs): pass
def MQuaternion_negateIt(*args, **kwargs): pass
def array2dDouble_swigregister(*args, **kwargs): pass
def MItMeshEdge_className(*args, **kwargs): pass
def MFnPhongEShader_setHighlightSize(*args, **kwargs): pass
def MFnIntArrayData_set(*args, **kwargs): pass
def MScriptUtil_getUint4ArrayItem(*args, **kwargs): pass
def MFnDagNode_dagRoot(*args, **kwargs): pass
def MTransformationMatrix_translation(*args, **kwargs): pass
def MObjectArray_length(*args, **kwargs): pass
def MFnNumericAttribute_hasSoftMin(*args, **kwargs): pass
def MGlobal_getRichSelection(*args, **kwargs): pass
def MFnMesh_setVertexNormal(*args, **kwargs): pass
def MFnLambertShader_setTranslucenceCoeff(*args, **kwargs): pass
def MEvaluationManager_className(*args, **kwargs): pass
def new_MQuaternion(*args, **kwargs): pass
def MGlobal_selectionMode(*args, **kwargs): pass
def MFnPhongShader_className(*args, **kwargs): pass
def new_array3dFloat(*args, **kwargs): pass
def MItMeshEdge_isSmooth(*args, **kwargs): pass
def MFnPartition_type(*args, **kwargs): pass
def MFnGeometryData_objectGroupCount(*args, **kwargs): pass
def MFnDependencyNode_dgCallbackIds(*args, **kwargs): pass
def MNurbsIntersector_getIntersects(*args, **kwargs): pass
def MDataHandle_setGenericShort(*args, **kwargs): pass
def MFnLightDataAttribute_className(*args, **kwargs): pass
def MFnMesh_getRawPoints(*args, **kwargs): pass
def MFnLambertShader_refractedRayDepthLimit(*args, **kwargs): pass
def MEulerRotation_x_get(*args, **kwargs): pass
def MScriptUtil_getFloat3ArrayItem(*args, **kwargs): pass
def MIffFile_iffGetShort(*args, **kwargs): pass
def MItInstancer_instancerPath(*args, **kwargs): pass
def MFnNurbsSurface_numPatchesInV(*args, **kwargs): pass
def MFnGenericAttribute_addAccept(*args, **kwargs): pass
def MFileIO_beforeOpenUserFileTranslator(*args, **kwargs): pass
def MFnDependencyNode_getAliasList(*args, **kwargs): pass
def MTransformationMatrix_addScale(*args, **kwargs): pass
def MNodeMessage_addNodeDirtyCallback(*args, **kwargs): pass
def MFnVectorArrayData_set(*args, **kwargs): pass
def MFnAttribute_acceptsAttribute(*args, **kwargs): pass
def MDataHandle_className(*args, **kwargs): pass
def MAngle_setValue(*args, **kwargs): pass
def MItSelectionList_getDependNode(*args, **kwargs): pass
def MEulerRotation_isZero(*args, **kwargs): pass
def MScriptUtil_createIntArrayFromList(*args, **kwargs): pass
def MDagMessage_addInstanceRemovedDagPathCallback(*args, **kwargs): pass
def MItGeometry_component(*args, **kwargs): pass
def MFnNurbsSurface_intersect(*args, **kwargs): pass
def delete_MFnFloatArrayData(*args, **kwargs): pass
def MFnDependencyNode_parentNamespace(*args, **kwargs): pass
def MTimer_swigregister(*args, **kwargs): pass
def MNodeClass_typeName(*args, **kwargs): pass
def MFnUnitAttribute_getMin(*args, **kwargs): pass
def MQuaternion_assign(*args, **kwargs): pass
def MDataHandle_numericType(*args, **kwargs): pass
def MFnAttribute_setArray(*args, **kwargs): pass
def MDataHandle_asGenericChar(*args, **kwargs): pass
def MProfiler_loadRecording(*args, **kwargs): pass
def delete_MEulerRotation(*args, **kwargs): pass
def MScriptUtil_setDoubleArray(*args, **kwargs): pass
def new_MAttributePattern(*args, **kwargs): pass
def MIteratorType_setFilterList(*args, **kwargs): pass
def MFnNurbsSurface_knotInV(*args, **kwargs): pass
def MScriptUtil_setShort2ArrayItem(*args, **kwargs): pass
def MFnExpression_type(*args, **kwargs): pass
def MFnDependencyNode_pluginName(*args, **kwargs): pass
def MFnLightDataAttribute_setDefault(*args, **kwargs): pass
def MNamespace_parentNamespace(*args, **kwargs): pass
def MFnUint64SingleIndexedComponent_addElement(*args, **kwargs): pass
def MTime___isub__(*args, **kwargs): pass
def MDataHandle_setMFloatVector(*args, **kwargs): pass
def MDoubleArray_clear(*args, **kwargs): pass
def MScriptUtil_setFloat(*args, **kwargs): pass
def MAttributeSpecArray_copy(*args, **kwargs): pass
def MItEdits_next(*args, **kwargs): pass
def MFnNonExtendedLight_depthMapWidthFocus(*args, **kwargs): pass
def MFnAttribute_isIndeterminant(*args, **kwargs): pass
def MFnNurbsSurface_isParamOnSurface(*args, **kwargs): pass
def MFnDoubleIndexedComponent_setCompleteData(*args, **kwargs): pass
def delete_MFnBase(*args, **kwargs): pass
def MTime_value(*args, **kwargs): pass
def MPointOnMesh_swigregister(*args, **kwargs): pass
def MFnTypedAttribute_swigregister(*args, **kwargs): pass
def MSelectionList_getPlug(*args, **kwargs): pass
def MVectorArray_remove(*args, **kwargs): pass
def MFnArrayAttrsData_getStringData(*args, **kwargs): pass
def MDistance_setUIUnit(*args, **kwargs): pass
def MScriptUtil_asInt2Ptr(*args, **kwargs): pass
def MAttributeIndex_setLower(*args, **kwargs): pass
def MItDependencyGraph_getPlugsVisited(*args, **kwargs): pass
def new_MFnNurbsSurface(*args, **kwargs): pass
def MFloatVector___mul__(*args, **kwargs): pass
def MTimeArray___getitem__(*args, **kwargs): pass
def MFileIO_getLastTempFile(*args, **kwargs): pass
def MMatrix_className(*args, **kwargs): pass
def MFnArrayAttrsData_type(*args, **kwargs): pass
def MDataHandle_asFloat2(*args, **kwargs): pass
def delete_MDistance(*args, **kwargs): pass
def MFnSubd_vertexIsBoundary(*args, **kwargs): pass
def MFnNurbsCurve_makeMultipleEndKnots(*args, **kwargs): pass
def MFnNurbsCurve_area(*args, **kwargs): pass
def MFnCameraSet_clear(*args, **kwargs): pass
def MTesselationParams_setRelativeFitTolerance(*args, **kwargs): pass
def MDagMessage_addParentRemovedDagPathCallback(*args, **kwargs): pass
def MMatrix___iadd__(*args, **kwargs): pass
def MFnSubdNames_levelOneFaceId(*args, **kwargs): pass
def MFnNonExtendedLight_swigregister(*args, **kwargs): pass
def MFnNonExtendedLight_setUseDepthMapAutoFocus(*args, **kwargs): pass
def MDataHandle_setClean(*args, **kwargs): pass
def MDGMessage_addNodeChangeUuidCheckCallback(*args, **kwargs): pass
def new_MProfilingScope(*args, **kwargs): pass
def MArrayDataBuilder_className(*args, **kwargs): pass
def MFnNurbsCurve_setKnot(*args, **kwargs): pass
def MSpace_swigregister(*args, **kwargs): pass
def MFnDirectionalLight_className(*args, **kwargs): pass
def MGlobal_customVersion(*args, **kwargs): pass
def MFloatPoint_className(*args, **kwargs): pass
def MFnVolumeLight_swigregister(*args, **kwargs): pass
def MFileIO_setError(*args, **kwargs): pass
def MItSurfaceCV_swigregister(*args, **kwargs): pass
def MFnSubd_tessellateViaNurbs(*args, **kwargs): pass
def delete_MWeight(*args, **kwargs): pass
def MDGContext_assign(*args, **kwargs): pass
def MProfiler_isSignalEvent(*args, **kwargs): pass
def MArgList_asStringArray(*args, **kwargs): pass
def MItDag_currentItem(*args, **kwargs): pass
def new_MFnNurbsCurve(*args, **kwargs): pass
def MFnComponentListData_remove(*args, **kwargs): pass
def MFloatPoint___mul__(*args, **kwargs): pass
def MConditionMessage_className(*args, **kwargs): pass
def MFnSubd_polygonEdges(*args, **kwargs): pass
def delete_MFnPhongEShader(*args, **kwargs): pass
def MFnAnisotropyShader_setCorrelationY(*args, **kwargs): pass
def MFnNurbsCurve_form(*args, **kwargs): pass
def MMatrixArray_swigregister(*args, **kwargs): pass
def MProfiler_removeCategory(*args, **kwargs): pass
def MArgDatabase_className(*args, **kwargs): pass
def delete_MItCurveCV(*args, **kwargs): pass
def MFnNumericData_setData2Float(*args, **kwargs): pass
def MFnComponent_isEmpty(*args, **kwargs): pass
def MFloatPointArray_get(*args, **kwargs): pass
def MStreamUtils_writeChar(*args, **kwargs): pass
def MCommandResult_swigregister(*args, **kwargs): pass
def MItSubdFace_level(*args, **kwargs): pass
def new_MFnAreaLight(*args, **kwargs): pass
def MFnSubd_creasesClearAll(*args, **kwargs): pass
def MFnAmbientLight_setCastSoftShadows(*args, **kwargs): pass
def MVector_assign(*args, **kwargs): pass
def MDagPath_assign(*args, **kwargs): pass
def MPoint___ne__(*args, **kwargs): pass
def MArgParser_getFlagArgumentList(*args, **kwargs): pass
def MInt64Array_get(*args, **kwargs): pass
def MFnMesh_unlockFaceVertexNormals(*args, **kwargs): pass
def MFnNumericData_type(*args, **kwargs): pass
def MFileIO_unloadReferenceByNode(*args, **kwargs): pass
def MFnCamera_setCameraScale(*args, **kwargs): pass
def MFloatMatrix_isEquivalent(*args, **kwargs): pass
def MSelectionMask_swigregister(*args, **kwargs): pass
def new_MMessage(*args, **kwargs): pass
def MItSubdEdge_next(*args, **kwargs): pass
def MFnSubd_vertexBaseMeshGet(*args, **kwargs): pass
def MUint64Array___add__(*args, **kwargs): pass
def MFnLight_setRayDepthLimit(*args, **kwargs): pass
def MVectorArray___getitem__(*args, **kwargs): pass
def MVectorArray_swigregister(*args, **kwargs): pass
def MDagPath_hasFn(*args, **kwargs): pass
def MPointArray_sizeIncrement(*args, **kwargs): pass
def MAngle_setInternalUnit(*args, **kwargs): pass
def MIntArray___eq__(*args, **kwargs): pass
def MFnNumericAttribute_child(*args, **kwargs): pass
def MFnMesh_hasColorChannels(*args, **kwargs): pass
def MFnCamera_focusDistance(*args, **kwargs): pass
def MDataHandle_asSubdSurface(*args, **kwargs): pass
def MFloatMatrix_transpose(*args, **kwargs): pass
def MSelectionList_assign(*args, **kwargs): pass
def MItDependencyGraph_thisNode(*args, **kwargs): pass
def new_MFnDoubleArrayData(*args, **kwargs): pass
def MGlobal_viewFrame(*args, **kwargs): pass
def MFnSubd_polygonBaseMeshAddWithUVs(*args, **kwargs): pass
def MFnLight_type(*args, **kwargs): pass
def new_MUserEventMessage(*args, **kwargs): pass
def MDAGDrawOverrideInfo_fDisplayType_get(*args, **kwargs): pass
def delete_MAngle(*args, **kwargs): pass
def MIntArray_set(*args, **kwargs): pass
def delete_MMeshIsectAccelParams(*args, **kwargs): pass
def MFnMatrixAttribute_type(*args, **kwargs): pass
def MFnCamera_setFocalLength(*args, **kwargs): pass
def MFloatArray___len__(*args, **kwargs): pass
def new_MSceneMessage(*args, **kwargs): pass
def MColor_g_get(*args, **kwargs): pass
def MItMeshVertex_setIndex(*args, **kwargs): pass
def MFnStringData_swigregister(*args, **kwargs): pass
def MFnMesh_clearGlobalIntersectionAcceleratorInfo(*args, **kwargs): pass
def MFnBlinnShader_setSpecularRollOff(*args, **kwargs): pass
def MFnContainerNode_type(*args, **kwargs): pass
def MURI_clear(*args, **kwargs): pass
def MPlug_asDouble(*args, **kwargs): pass
def MFn_swigregister(*args, **kwargs): pass
def MImage_readDepthMap(*args, **kwargs): pass
def MFnMesh_setBoolBlindData(*args, **kwargs): pass
def MFileObject_getResolvedFullName(*args, **kwargs): pass
def MRichSelection_getSelection(*args, **kwargs): pass
def MColor___call__(*args, **kwargs): pass
def MItMeshVertex_index(*args, **kwargs): pass
def delete_MItSurfaceCV(*args, **kwargs): pass
def MFnMesh_hasAlphaChannels(*args, **kwargs): pass
def MFnTransform_rotateBy(*args, **kwargs): pass
def MURI_getFileName(*args, **kwargs): pass
def MDGModifier_doIt(*args, **kwargs): pass
def MPlug_setBool(*args, **kwargs): pass
def new_MImage(*args, **kwargs): pass
def MFnDagNode_objectColorIndex(*args, **kwargs): pass
def MFnMesh_hasBlindData(*args, **kwargs): pass
def MArrayDataHandle_className(*args, **kwargs): pass
def MFnCamera_stereoHITEnabled(*args, **kwargs): pass
def MGlobal_executeCommandStringResult(*args, **kwargs): pass
def MFileObject_expandedFullName(*args, **kwargs): pass
def delete_MConnectDisconnectAttrEdit(*args, **kwargs): pass
def MImage_readFromFile(*args, **kwargs): pass
def MColorArray_assign(*args, **kwargs): pass
def MItMeshPolygon_zeroArea(*args, **kwargs): pass
def MFnUnitAttribute_setMax(*args, **kwargs): pass
def MFnSpotLight_setConeAngle(*args, **kwargs): pass
def MColorArray_length(*args, **kwargs): pass
def MFnMesh_subdivideFaces(*args, **kwargs): pass
def MFnTransform_getScale(*args, **kwargs): pass
def MURI_setScheme(*args, **kwargs): pass
def MDGModifier_unlinkExtensionAttributeFromPlugin(*args, **kwargs): pass
def MPlug_isNull(*args, **kwargs): pass
def MFnMatrixAttribute_create(*args, **kwargs): pass
def MIffFile_swigregister(*args, **kwargs): pass
def MFnMesh_getFaceVertexColorIndex(*args, **kwargs): pass
def MFnCamera_verticalShake(*args, **kwargs): pass
def MFileIO_latestMayaFileVersion(*args, **kwargs): pass
def MEdit_isFailed(*args, **kwargs): pass
def MCallbackIdArray_assign(*args, **kwargs): pass
def MItMeshPolygon_numTriangles(*args, **kwargs): pass
def MFileIO_getReferences(*args, **kwargs): pass
def MFnSingleIndexedComponent_setCompleteData(*args, **kwargs): pass
def delete_MFnArrayAttrsData(*args, **kwargs): pass
def MFnMeshData_className(*args, **kwargs): pass
def MUintArray___getitem__(*args, **kwargs): pass
def MMeshSmoothOptions_setSubdivisionType(*args, **kwargs): pass
def MPlug_elementByLogicalIndex(*args, **kwargs): pass
def new_MGlobal(*args, **kwargs): pass
def MFileIO_newFile(*args, **kwargs): pass
def MFnMesh_currentColorSetName(*args, **kwargs): pass
def MVector___truediv__(*args, **kwargs): pass
def MFileIO_beforeReferenceUserFileTranslator(*args, **kwargs): pass
def MRenderPassDef_getName(*args, **kwargs): pass
def MCacheFormatDescription_getDistribution(*args, **kwargs): pass
def MFloatVectorArray_sizeIncrement(*args, **kwargs): pass
def boolPtr_assign(*args, **kwargs): pass
def MItSurfaceCV_reset(*args, **kwargs): pass
def MFnTransform_scalePivot(*args, **kwargs): pass
def MFileIO_isWritingFile(*args, **kwargs): pass
def MRampAttribute_isCurveRamp(*args, **kwargs): pass
def MBoundingBox_height(*args, **kwargs): pass
def MFnNurbsCurve_removeKnot(*args, **kwargs): pass
def shortPtr_swigregister(*args, **kwargs): pass
def MAngle_asAngMinutes(*args, **kwargs): pass
def MFnArrayAttrsData_count(*args, **kwargs): pass
def delete_MTypeId(*args, **kwargs): pass
def charPtr_value(*args, **kwargs): pass
def MMeshSmoothOptions_setSmoothness(*args, **kwargs): pass
def new_array3dDouble(*args, **kwargs): pass
def MCurveAttribute_createCurveAttr(*args, **kwargs): pass
def MItSurfaceCV_index(*args, **kwargs): pass
def MTransformationMatrix_className(*args, **kwargs): pass
def delete_MQuaternion(*args, **kwargs): pass
def MFnNurbsCurve_isParamOnCurve(*args, **kwargs): pass
def delete_array3dFloat(*args, **kwargs): pass
def MItMeshEdge_setSmoothing(*args, **kwargs): pass
def MAngle_asAngSeconds(*args, **kwargs): pass
def MTransformationMatrix_scalePivot(*args, **kwargs): pass
def MNurbsIntersector_create(*args, **kwargs): pass
def MFnArrayAttrsData_doubleArray(*args, **kwargs): pass
def SWIG_PyInstanceMethod_New(*args, **kwargs): pass
def array3dInt_get(*args, **kwargs): pass
def MFileObject_setRawURI(*args, **kwargs): pass
def MTransformationMatrix_rotation(*args, **kwargs): pass
def MItMeshPolygon_updateSurface(*args, **kwargs): pass
def delete_MDataHandle(*args, **kwargs): pass
def delete_MRenderPassDef(*args, **kwargs): pass
def boolPtr_swigregister(*args, **kwargs): pass
def MItGeometry_currentItem(*args, **kwargs): pass
def MTimerMessage_addTimerCallback(*args, **kwargs): pass
def MGlobal_displayError(*args, **kwargs): pass
def MQuaternion___imul__(*args, **kwargs): pass
def MGlobal_getAssociatedSets(*args, **kwargs): pass
def MFnMatrixData_create(*args, **kwargs): pass
def MTime___mul__(*args, **kwargs): pass
def MNamespace_removeNamespace(*args, **kwargs): pass
def MFnNonExtendedLight_type(*args, **kwargs): pass
def MFnMatrixData_swigregister(*args, **kwargs): pass
def new_MMeshSmoothOptions(*args, **kwargs): pass
def MFnTypedAttribute_attrType(*args, **kwargs): pass
def MQuaternion_z_set(*args, **kwargs): pass
def MGlobal_optionVarDoubleValue(*args, **kwargs): pass
def MFnNurbsSurface_isUniform(*args, **kwargs): pass
def MQuaternion_w_set(*args, **kwargs): pass
def MFnSet_annotation(*args, **kwargs): pass
def MFnSubdNames_levelOneFaceAsLong(*args, **kwargs): pass
def MFnArrayAttrsData_swigregister(*args, **kwargs): pass
def delete_MProfilingScope(*args, **kwargs): pass
def MFnUInt64ArrayData_copyTo(*args, **kwargs): pass
def new_MItDependencyGraph(*args, **kwargs): pass
def new_MFnDirectionalLight(*args, **kwargs): pass
def delete_MItSubdEdge(*args, **kwargs): pass
def MFloatPoint_swigregister(*args, **kwargs): pass
def MQuaternion_swigregister(*args, **kwargs): pass
def MLockMessage_setNodeLockQueryCallback(*args, **kwargs): pass
def delete_MFnNonExtendedLight(*args, **kwargs): pass
def MWeight_assign(*args, **kwargs): pass
def MFileObject_resolvedPath(*args, **kwargs): pass
def MFloatPoint___imul__(*args, **kwargs): pass
def MSyntax_makeFlagQueryWithFullArgs(*args, **kwargs): pass
def MItSurfaceCV_isDone(*args, **kwargs): pass
def delete_MDataBlock(*args, **kwargs): pass
def MFnNurbsCurve_updateCurve(*args, **kwargs): pass
def MVector_get(*args, **kwargs): pass
def MPlug_isCompound(*args, **kwargs): pass
def MDataBlock_inputValue(*args, **kwargs): pass
def MFileIO_isSavingReference(*args, **kwargs): pass
def MFnComponent_isEqual(*args, **kwargs): pass
def MFloatPointArray_setSizeIncrement(*args, **kwargs): pass
def MStreamUtils_writeCharBuffer(*args, **kwargs): pass
def new_MComputation(*args, **kwargs): pass
def new_MFnAttribute(*args, **kwargs): pass
def MSceneMessage_addCheckFileCallback(*args, **kwargs): pass
def MVector___call__(*args, **kwargs): pass
def MDagPath___eq__(*args, **kwargs): pass
def MPoint_cartesianize(*args, **kwargs): pass
def MArgParser_commandArgumentBool(*args, **kwargs): pass
def MFnAttribute_setConnectable(*args, **kwargs): pass
def MInt64Array_setSizeIncrement(*args, **kwargs): pass
def MFileObject_ithPath(*args, **kwargs): pass
def MFnCamera_cameraScale(*args, **kwargs): pass
def delete_MParentingEdit(*args, **kwargs): pass
def delete_MMessage(*args, **kwargs): pass
def MFnSubd_vertexBaseMeshSet(*args, **kwargs): pass
def MVector_rotateTo(*args, **kwargs): pass
def MVectorArray_assign(*args, **kwargs): pass
def delete_MMatrix(*args, **kwargs): pass
def MDagPath_apiType(*args, **kwargs): pass
def MFnNumericAttribute_hasMin(*args, **kwargs): pass
def MSelectionList_merge(*args, **kwargs): pass
def MFnDependencyNode_isShared(*args, **kwargs): pass
def MGlobal_startErrorLogging(*args, **kwargs): pass
def MFnSubd_editsPending(*args, **kwargs): pass
def MAngle_assign(*args, **kwargs): pass
def MIntArray_setLength(*args, **kwargs): pass
def MMeshIsectAccelParams_swigregister(*args, **kwargs): pass
def MFnMesh_getSmoothMeshDisplayOptions(*args, **kwargs): pass
def MFnCamera_focalLength(*args, **kwargs): pass
def MColor_b_set(*args, **kwargs): pass
def MFnMesh_intersect(*args, **kwargs): pass
def MEulerRotation___eq__(*args, **kwargs): pass
def delete_MFnContainerNode(*args, **kwargs): pass
def MFileObject_setResolveMethod(*args, **kwargs): pass
def MDagPathArray_set(*args, **kwargs): pass
def new_MSpace(*args, **kwargs): pass
def MImage_resize(*args, **kwargs): pass
def MFnMesh_setStringBlindData(*args, **kwargs): pass
def MFnCamera_setPreScale(*args, **kwargs): pass
def MFileObject_swigregister(*args, **kwargs): pass
def MRichSelection_getSymmetry(*args, **kwargs): pass
def MFloatVectorArray_copy(*args, **kwargs): pass
def MColor___getitem__(*args, **kwargs): pass
def MItMeshVertex_vertex(*args, **kwargs): pass
def MObject_apiTypeStr(*args, **kwargs): pass
def MFnMesh_getColorRepresentation(*args, **kwargs): pass
def MFnTransform_rotateOrientation(*args, **kwargs): pass
def MURI_getDirectory(*args, **kwargs): pass
def MDGModifier_undoIt(*args, **kwargs): pass
def MPlug_setMDistance(*args, **kwargs): pass
def delete_MImage(*args, **kwargs): pass
def MDataHandle_asBool(*args, **kwargs): pass
def MFnMesh_getBlindDataTypes(*args, **kwargs): pass
def MGlobal_doErrorLogEntry(*args, **kwargs): pass
def MFileObject_resolvedName(*args, **kwargs): pass
def MColorArray_set(*args, **kwargs): pass
def MItMeshPolygon_getUVArea(*args, **kwargs): pass
def MDagMessage_addDagCallback(*args, **kwargs): pass
def MFnMesh_subdivideEdges(*args, **kwargs): pass
def MFnTransform_setScale(*args, **kwargs): pass
def MURI_setPath(*args, **kwargs): pass
def MDGModifier_commandToExecute(*args, **kwargs): pass
def MFnMesh_deleteFace(*args, **kwargs): pass
def new_MIffTag(*args, **kwargs): pass
def MFnCamera_setVerticalShake(*args, **kwargs): pass
def MFileIO_className(*args, **kwargs): pass
def MEdit_isTopLevel(*args, **kwargs): pass
def MCallbackIdArray_set(*args, **kwargs): pass
def delete_MUserEventMessage(*args, **kwargs): pass
def MItMeshPolygon_getTriangle(*args, **kwargs): pass
def MFnAttribute_isChannelBoxFlagSet(*args, **kwargs): pass
def new_MFnMeshData(*args, **kwargs): pass
def MFnAssembly_supportsMemberChanges(*args, **kwargs): pass
def MUintArray___delitem__(*args, **kwargs): pass
def MMeshSmoothOptions_subdivisionType(*args, **kwargs): pass
def MPlug_elementByPhysicalIndex(*args, **kwargs): pass
def MFnCamera_setVerticalFilmAperture(*args, **kwargs): pass
def MObject_kNullObj_get(*args, **kwargs): pass
def MQuaternion_w_get(*args, **kwargs): pass
def MFileIO_exportType(*args, **kwargs): pass
def MRenderPassDef_getGroup(*args, **kwargs): pass
def MCacheFormatDescription_getTimePerFrame(*args, **kwargs): pass
def MItMeshPolygon_setUV(*args, **kwargs): pass
def MFnDagNode_usingObjectColor(*args, **kwargs): pass
def MFnSet_hasRestrictions(*args, **kwargs): pass
def MFnMatrixAttribute_getDefault(*args, **kwargs): pass
def MFnAssembly_canActivate(*args, **kwargs): pass
def delete_MUintArray(*args, **kwargs): pass
def MArrayDataHandle_set(*args, **kwargs): pass
def MPlug_isArray(*args, **kwargs): pass
def MMatrix___add__(*args, **kwargs): pass
def MGlobal_optionVarStringValue(*args, **kwargs): pass
def MFnMesh_getPointsAtUV(*args, **kwargs): pass
def MFnCamera_eyePoint(*args, **kwargs): pass
def MFileIO_isOpeningFile(*args, **kwargs): pass
def MRampAttribute_hasIndex(*args, **kwargs): pass
def MItMeshPolygon_polygonVertexCount(*args, **kwargs): pass
def MFnPointLight_create(*args, **kwargs): pass
def MFnNurbsSurface_create(*args, **kwargs): pass
def MFnLightDataAttribute_child(*args, **kwargs): pass
def MFnDagNode_getConnectedSetsAndMembers(*args, **kwargs): pass
def new_floatPtr(*args, **kwargs): pass
def MPlugArray_append(*args, **kwargs): pass
def MGlobal_addToModel(*args, **kwargs): pass
def MFnMesh_deleteUVSet(*args, **kwargs): pass
def MPointArray_className(*args, **kwargs): pass
def MFnReference_parentReference(*args, **kwargs): pass
def MFnAttribute_isRenderSource(*args, **kwargs): pass
def MFileIO_importFile(*args, **kwargs): pass
def MQuaternion_z_get(*args, **kwargs): pass
def MAttributePatternArray_insert(*args, **kwargs): pass
def MItMeshFaceVertex_hasUVs(*args, **kwargs): pass
def MFnPluginData_constData(*args, **kwargs): pass
def MFnLayeredShader_setColor(*args, **kwargs): pass
def MFnDagNode_setIntermediateObject(*args, **kwargs): pass
def new_MTypeId(*args, **kwargs): pass
def charPtr_cast(*args, **kwargs): pass
def MObjectHandle_assign(*args, **kwargs): pass
def MWeight_setSeam(*args, **kwargs): pass
def MGlobal_setComponentSelectionMask(*args, **kwargs): pass
def MFnMesh_isPolygonConvex(*args, **kwargs): pass
def MFnBlinnShader_type(*args, **kwargs): pass
def MEvaluationNodeIterator_plug(*args, **kwargs): pass
def MQuaternion___ne__(*args, **kwargs): pass
def delete_array3dDouble(*args, **kwargs): pass
def new_MItMeshFaceVertex(*args, **kwargs): pass
def MItSubdEdge_isDone(*args, **kwargs): pass
def MFnPhongEShader_setWhiteness(*args, **kwargs): pass
def MMatrix___mul__(*args, **kwargs): pass
def MFnDagNode_hasChild(*args, **kwargs): pass
def MTransformationMatrix_swigregister(*args, **kwargs): pass
def MObjectArray_insert(*args, **kwargs): pass
def MGlobal_getHiliteList(*args, **kwargs): pass
def MFnMesh_setVertexNormals(*args, **kwargs): pass
def MFnLambertShader_setGlowIntensity(*args, **kwargs): pass
def delete_MEvaluationNode(*args, **kwargs): pass
def MFnNurbsSurface_cvsInU(*args, **kwargs): pass
def array3dFloat_get(*args, **kwargs): pass
def MItMeshEdge_cleanupSmoothing(*args, **kwargs): pass
def MFnPartition_className(*args, **kwargs): pass
def MFnGeometryData_objectGroupType(*args, **kwargs): pass
def MFnDependencyNode_removeAttribute(*args, **kwargs): pass
def MTransformationMatrix_setScalePivot(*args, **kwargs): pass
def MNurbsIntersector_className(*args, **kwargs): pass
def MFnVolumeLight_setEmitAmbient(*args, **kwargs): pass
def MFnAttribute_isAffectsWorldSpace(*args, **kwargs): pass
def MFnMesh_getRawNormals(*args, **kwargs): pass
def MMessageNode_fHeadNode_get(*args, **kwargs): pass
def MFnLambertShader_refractiveIndex(*args, **kwargs): pass
def MEulerRotation_y_get(*args, **kwargs): pass
def MScriptUtil_getFloat4ArrayItem(*args, **kwargs): pass
def MItInstancer_matrix(*args, **kwargs): pass
def MFnNurbsSurface_setUVs(*args, **kwargs): pass
def MFnGenericAttribute_removeNumericDataAccept(*args, **kwargs): pass
def MFnAttribute_isUsedAsFilename(*args, **kwargs): pass
def MFnDependencyNode_setIcon(*args, **kwargs): pass
def MLockMessage_swigregister(*args, **kwargs): pass
def MNodeMessage_addNameChangedCallback(*args, **kwargs): pass
def MFnVectorArrayData_create(*args, **kwargs): pass
def MFnAttribute_parent(*args, **kwargs): pass
def MDataHandle_swigregister(*args, **kwargs): pass
def MFnSubd_updateAllEditsAndCreases(*args, **kwargs): pass
def MScriptUtil_createFloatArrayFromList(*args, **kwargs): pass
def MMatrix_adjoint(*args, **kwargs): pass
def new_uIntPtr(*args, **kwargs): pass
def MItGeometry_count(*args, **kwargs): pass
def MFnNurbsSurface_updateSurface(*args, **kwargs): pass
def new_MFnFloatArrayData(*args, **kwargs): pass
def MFnDependencyNode_setLocked(*args, **kwargs): pass
def MTimerMessage_className(*args, **kwargs): pass
def MNodeClass_addToClassification(*args, **kwargs): pass
def MFnUnitAttribute_getSoftMin(*args, **kwargs): pass
def MMatrix_homogenize(*args, **kwargs): pass
def MFnAttribute_setKeyable(*args, **kwargs): pass
def MDataHandle_asGenericFloat(*args, **kwargs): pass
def MEulerRotation_setValue(*args, **kwargs): pass
def MScriptUtil_setUshortArray(*args, **kwargs): pass
def MAttributePattern___eq__(*args, **kwargs): pass
def MIteratorType_getFilterType(*args, **kwargs): pass
def MFnNurbsSurface_setKnotInV(*args, **kwargs): pass
def MFnNumericData_setData2Double(*args, **kwargs): pass
def MFnExpression_className(*args, **kwargs): pass
def MFnMesh_numEdges(*args, **kwargs): pass
def MFnDependencyNode_uuid(*args, **kwargs): pass
def MTime___imul__(*args, **kwargs): pass
def MNamespace_renameNamespace(*args, **kwargs): pass
def MFnUint64SingleIndexedComponent_element(*args, **kwargs): pass
def MFnAttribute_isDynamic(*args, **kwargs): pass
def MDataHandle_setMAngle(*args, **kwargs): pass
def MDoubleArray_setSizeIncrement(*args, **kwargs): pass
def MFloatArray_insert(*args, **kwargs): pass
def MItEdits_isReverse(*args, **kwargs): pass
def MFnNurbsSurface_degreeU(*args, **kwargs): pass
def MFnDoubleIndexedComponent_swigregister(*args, **kwargs): pass
def MFnBase_hasObj(*args, **kwargs): pass
def MTime_setValue(*args, **kwargs): pass
def delete_MMeshSmoothOptions(*args, **kwargs): pass
def MModelMessage_addBeforeDuplicateCallback(*args, **kwargs): pass
def MUintArray_set(*args, **kwargs): pass
def delete_MFnUInt64ArrayData(*args, **kwargs): pass
def MFnAttribute_internal(*args, **kwargs): pass
def MFnAttribute_type(*args, **kwargs): pass
def MDataHandle_asNurbsSurfaceTransformed(*args, **kwargs): pass
def MDistance_internalToUI(*args, **kwargs): pass
def MScriptUtil_asInt4Ptr(*args, **kwargs): pass
def MAttributeIndex_assign(*args, **kwargs): pass
def MItDependencyGraph_getPlugPath(*args, **kwargs): pass
def MFnNurbsSurface_copy(*args, **kwargs): pass
def MFnDoubleArrayData___getitem__(*args, **kwargs): pass
def MFloatVector___eq__(*args, **kwargs): pass
def MFloatArray_copy(*args, **kwargs): pass
def MDagMessage_swigregister(*args, **kwargs): pass
def new_MMatrixArray(*args, **kwargs): pass
def MFnTripleIndexedComponent_addElement(*args, **kwargs): pass
def MFnArrayAttrsData_className(*args, **kwargs): pass
def MDataHandle_asShort3(*args, **kwargs): pass
def MDistance_unit(*args, **kwargs): pass
def MFnComponentListData_clear(*args, **kwargs): pass
def MScriptUtil_asShort(*args, **kwargs): pass
def MFnPartition_create(*args, **kwargs): pass
def delete_MArrayDataHandle(*args, **kwargs): pass
def MItDependencyGraph_toggleTraversal(*args, **kwargs): pass
def MFnMesh_numUVs(*args, **kwargs): pass
def MFnNurbsCurve_findParamFromLength(*args, **kwargs): pass
def MFnCameraSet_setLayerCamera(*args, **kwargs): pass
def MFloatVectorArray_swigregister(*args, **kwargs): pass
def MTesselationParams_set3DDelta(*args, **kwargs): pass
def MDagMessage_addChildAddedDagPathCallback(*args, **kwargs): pass
def MMatrix___isub__(*args, **kwargs): pass
def MFnSubdNames_levelOneFaceIndexFromId(*args, **kwargs): pass
def MFloatArray_get(*args, **kwargs): pass
def MFnNonExtendedLight_setDepthMapWidthFocus(*args, **kwargs): pass
def MDataHandle_asChar(*args, **kwargs): pass
def delete_MDGMessage(*args, **kwargs): pass
def MProfilingScope_className(*args, **kwargs): pass
def MArrayDataHandle_inputValue(*args, **kwargs): pass
def delete_MItDependencyGraph(*args, **kwargs): pass
def MFnNurbsCurve_getCVs(*args, **kwargs): pass
def MCacheConfigRuleRegistry_setRegisteringCallableScript(*args, **kwargs): pass
def MFnDirectionalLight_create(*args, **kwargs): pass
def delete_array3dInt(*args, **kwargs): pass
def MTesselationParams_setOutputType(*args, **kwargs): pass
def new_MItEdits(*args, **kwargs): pass
def MAngle_internalUnit(*args, **kwargs): pass
def MCurveAttribute_setPositionAtIndex(*args, **kwargs): pass
def MLockMessage_setNodeLockDAGQueryCallback(*args, **kwargs): pass
def MFnNonExtendedLight_className(*args, **kwargs): pass
def MWeight_influence(*args, **kwargs): pass
def MDGContext_current(*args, **kwargs): pass
def MProfiler_getThreadDuration(*args, **kwargs): pass
def MArgList_flagIndex(*args, **kwargs): pass
def MItDag_prune(*args, **kwargs): pass
def MMatrix_swigregister(*args, **kwargs): pass
def MFnNurbsCurve_create(*args, **kwargs): pass
def MDagPathArray_assign(*args, **kwargs): pass
def MFnComponentListData_create(*args, **kwargs): pass
def MSyntax_addArg(*args, **kwargs): pass
def delete_MConditionMessage(*args, **kwargs): pass
def MItSurfaceCV_isRowDone(*args, **kwargs): pass
def MFnSubd_polygonHasChildren(*args, **kwargs): pass
def MScriptUtil_asDouble(*args, **kwargs): pass
def MFnNurbsSurface_getKnotDomain(*args, **kwargs): pass
def MFnAnisotropyShader_setRoughness(*args, **kwargs): pass
def MVector_length(*args, **kwargs): pass
def MDataBlock_outputValue(*args, **kwargs): pass
def MProfiler_getCategoryName(*args, **kwargs): pass
def new_MArgList(*args, **kwargs): pass
def MItCurveCV_next(*args, **kwargs): pass
def MFloatPoint_get(*args, **kwargs): pass
def MFnNumericData_setData3Short(*args, **kwargs): pass
def MFnComponent_isComplete(*args, **kwargs): pass
def MFloatPointArray_sizeIncrement(*args, **kwargs): pass
def MStreamUtils_writeInt(*args, **kwargs): pass
def MFnAttribute_setIndexMatters(*args, **kwargs): pass
def MItSubdFace_index(*args, **kwargs): pass
def MFnSubd_edgeCount(*args, **kwargs): pass
def MFnAmbientLight_setShadowRadius(*args, **kwargs): pass
def MDagPath_set(*args, **kwargs): pass
def MPoint_rationalize(*args, **kwargs): pass
def MFloatArray___setitem__(*args, **kwargs): pass
def MArgParser_commandArgumentInt(*args, **kwargs): pass
def MInt64Array_sizeIncrement(*args, **kwargs): pass
def MFnArrayAttrsData_getVectorData(*args, **kwargs): pass
def MDataHandle_asLong(*args, **kwargs): pass
def MFnCamera_setTumblePivot(*args, **kwargs): pass
def MFloatMatrix_matrix_get(*args, **kwargs): pass
def MParentingEdit_parentedObject(*args, **kwargs): pass
def MMessage_swigregister(*args, **kwargs): pass
def MItSubdEdge_isValid(*args, **kwargs): pass
def MFnCamera_filmRollOrder(*args, **kwargs): pass
def MFnSubd_vertexBaseMeshGetWithId(*args, **kwargs): pass
def MFnLight_setOpticalFXvisibility(*args, **kwargs): pass
def MMatrixArray_assign(*args, **kwargs): pass
def MPointArray_swigregister(*args, **kwargs): pass
def new_MArgParser(*args, **kwargs): pass
def MFnGenericAttribute_swigregister(*args, **kwargs): pass
def MIntArray___add__(*args, **kwargs): pass
def MFnNumericAttribute_hasMax(*args, **kwargs): pass
def MFnCamera_nearFocusDistance(*args, **kwargs): pass
def MFloatMatrix_setToProduct(*args, **kwargs): pass
def MDAGDrawOverrideInfo_fLOD_set(*args, **kwargs): pass
def MSelectionList_intersect(*args, **kwargs): pass
def MMessageNode_isValid_set(*args, **kwargs): pass
def MItSelectionList_reset(*args, **kwargs): pass
def MFnNurbsSurface_numSpansInV(*args, **kwargs): pass
def MFnSubd_editsUpdateAll(*args, **kwargs): pass
def MFnLight_className(*args, **kwargs): pass
def MUserEventMessage_swigregister(*args, **kwargs): pass
def MDAGDrawOverrideInfo_fLOD_get(*args, **kwargs): pass
def MFnMesh_getAssociatedUVSetTextures(*args, **kwargs): pass
def MAngle_unit(*args, **kwargs): pass
def MIntArray_length(*args, **kwargs): pass
def MFnMessageAttribute_type(*args, **kwargs): pass
def delete_MArgParser(*args, **kwargs): pass
def MFnCamera_getFocalLengthLimits(*args, **kwargs): pass
def MFloatArray___getitem__(*args, **kwargs): pass
def MSceneMessage_swigregister(*args, **kwargs): pass
def MColor_b_get(*args, **kwargs): pass
def MItMeshVertex_getConnectedEdges(*args, **kwargs): pass
def delete_MFnSubdData(*args, **kwargs): pass
def MFnMesh_getClosestPointAndNormal(*args, **kwargs): pass
def MURI_isValidURI(*args, **kwargs): pass
def MFloatArray___eq__(*args, **kwargs): pass
def MDagPathArray_setLength(*args, **kwargs): pass
def MPlug_asInt64(*args, **kwargs): pass
def delete_MFnStringArrayData(*args, **kwargs): pass
def delete_MSpace(*args, **kwargs): pass
def MImage_filterExists(*args, **kwargs): pass
def MFnMesh_setBinaryBlindData(*args, **kwargs): pass
def MFnCamera_preScale(*args, **kwargs): pass
def new_MFloatArray(*args, **kwargs): pass
def MRichSelection_getSymmetryMatrix(*args, **kwargs): pass
def MItMeshVertex_currentItem(*args, **kwargs): pass
def MArgParser_isEdit(*args, **kwargs): pass
def new_MFnStringArrayData(*args, **kwargs): pass
def MFnMesh_isColorClamped(*args, **kwargs): pass
def MFnTransform_setRotateOrientation(*args, **kwargs): pass
def MURI_getAuthority(*args, **kwargs): pass
def MDGModifier_className(*args, **kwargs): pass
def MPlug_setMAngle(*args, **kwargs): pass
def MImage_create(*args, **kwargs): pass
def MAngle_swigregister(*args, **kwargs): pass
def MFnMesh_getBlindDataAttrNames(*args, **kwargs): pass
def MImageFileInfo_numberOfImages(*args, **kwargs): pass
def MFnCamera_stereoHIT(*args, **kwargs): pass
def MConnectDisconnectAttrEdit_dstPlug(*args, **kwargs): pass
def MColorArray_setLength(*args, **kwargs): pass
def MFnSpotLight_setPenumbraAngle(*args, **kwargs): pass
def MFnMesh_extrudeFaces(*args, **kwargs): pass
def MFnTransform_scaleBy(*args, **kwargs): pass
def MURI_setFragment(*args, **kwargs): pass
def MMatrix_isSingular(*args, **kwargs): pass
def MFnMesh_autoUniformGridParams(*args, **kwargs): pass
def MPlug_isFromReferencedFile(*args, **kwargs): pass
def delete_MIffTag(*args, **kwargs): pass
def MFnMesh_setSomeColors(*args, **kwargs): pass
def MFileIO_swigregister(*args, **kwargs): pass
def MEdit_setApplied(*args, **kwargs): pass
def MPlug_source(*args, **kwargs): pass
def MCallbackIdArray_setLength(*args, **kwargs): pass
def MItMeshPolygon_getTriangles(*args, **kwargs): pass
def MFloatArray___iadd__(*args, **kwargs): pass
def MFnMeshData_create(*args, **kwargs): pass
def MFnAssembly_canRepApplyEdits(*args, **kwargs): pass
def MScriptUtil_setInt2ArrayItem(*args, **kwargs): pass
def MUintArray___repr__(*args, **kwargs): pass
def MMeshSmoothOptions_className(*args, **kwargs): pass
def MPlug_connectionByPhysicalIndex(*args, **kwargs): pass
def new_MIffFile(*args, **kwargs): pass
def MFnMesh_getColorSetFamilyNames(*args, **kwargs): pass
def MFnCamera_verticalFilmAperture(*args, **kwargs): pass
def MArgParser_flagArgumentBool(*args, **kwargs): pass
def MRenderPassDef_getDescription(*args, **kwargs): pass
def MCacheFormatDescription_getStartAndEndTimes(*args, **kwargs): pass
def MItMeshPolygon_getUV(*args, **kwargs): pass
def MFnSet_restriction(*args, **kwargs): pass
def MFnMatrixAttribute_setDefault(*args, **kwargs): pass
def MUint64Array_assign(*args, **kwargs): pass
def MFnAssembly_isActive(*args, **kwargs): pass
def MPointOnNurbs_assign(*args, **kwargs): pass
def MUintArray_assign(*args, **kwargs): pass
def MMeshSmoothOptions_propEdgeHardness(*args, **kwargs): pass
def MPlug_isElement(*args, **kwargs): pass
def MImageFileInfo_hasAlpha(*args, **kwargs): pass
def MFnMesh_getUVAtPoint(*args, **kwargs): pass
def MFnCamera_viewDirection(*args, **kwargs): pass
def MFileIO_isNewingFile(*args, **kwargs): pass
def MRampAttribute_sort(*args, **kwargs): pass
def MBoundingBox_center(*args, **kwargs): pass
def MItMeshPolygon_center(*args, **kwargs): pass
def MFnPointLight_swigregister(*args, **kwargs): pass
def MFnMesh_sortIntersectionFaceTriIds(*args, **kwargs): pass
def MFnLightDataAttribute_swigregister(*args, **kwargs): pass
def MFnDagNode_boundingBox(*args, **kwargs): pass
def MUint64Array_get(*args, **kwargs): pass
def delete_floatPtr(*args, **kwargs): pass
def MPlugArray_copy(*args, **kwargs): pass
def MGlobal_addToModelAt(*args, **kwargs): pass
def MFnMesh_setCurrentUVSetName(*args, **kwargs): pass
def MItMeshEdge_updateSurface(*args, **kwargs): pass
def MFloatMatrix_assign(*args, **kwargs): pass
def MFileIO_exportSelected(*args, **kwargs): pass
def MAttributePatternArray_append(*args, **kwargs): pass
def MItMeshFaceVertex_getUV(*args, **kwargs): pass
def MFnPluginData_create(*args, **kwargs): pass
def MFnLayeredShader_transparency(*args, **kwargs): pass
def MFnDagNode_objectColor(*args, **kwargs): pass
def MTypeId_assign(*args, **kwargs): pass
def MObjectHandle_objectHashCode(*args, **kwargs): pass
def MDataHandle_asDouble2(*args, **kwargs): pass
def MGlobal_animSelectionMask(*args, **kwargs): pass
def MFnMesh_getEdgeVertices(*args, **kwargs): pass
def delete_MFnBlinnShader(*args, **kwargs): pass
def MEvaluationNodeIterator_isDone(*args, **kwargs): pass
def MQuaternion_isEquivalent(*args, **kwargs): pass
def delete_MItMeshFaceVertex(*args, **kwargs): pass
def array3dInt_getptr(*args, **kwargs): pass
def MFnPhongEShader_swigregister(*args, **kwargs): pass
def MModelMessage_addCallback(*args, **kwargs): pass
def MFnIntArrayData_swigregister(*args, **kwargs): pass
def MFnDagNode_isChildOf(*args, **kwargs): pass
def new_MTrimBoundaryArray(*args, **kwargs): pass
def MObjectArray_append(*args, **kwargs): pass
def MGlobal_setHiliteList(*args, **kwargs): pass
def MFnMesh_getVertexNormal(*args, **kwargs): pass
def MFnLambertShader_hideSource(*args, **kwargs): pass
def MFnNurbsSurface_setKnotInU(*args, **kwargs): pass
def MQuaternion_asMatrix(*args, **kwargs): pass
def array3dFloat_set(*args, **kwargs): pass
def MItMeshEdge_index(*args, **kwargs): pass
def new_MFnPartition(*args, **kwargs): pass
def MFnGeometryData_objectGroupComponent(*args, **kwargs): pass
def MFnDependencyNode_swigregister(*args, **kwargs): pass
def MTransformationMatrix_scalePivotTranslation(*args, **kwargs): pass
def MEulerRotation_invertIt(*args, **kwargs): pass
def MNurbsIntersector_swigregister(*args, **kwargs): pass
def MArgParser_getFlagArgumentPosition(*args, **kwargs): pass
def MFnMesh_getPoints(*args, **kwargs): pass
def MFnLambertShader_setRefractiveIndex(*args, **kwargs): pass
def MEulerRotation_z_set(*args, **kwargs): pass
def MScriptUtil_setFloat4ArrayItem(*args, **kwargs): pass
def MItInstancer_instancerId(*args, **kwargs): pass
def MFnNurbsSurface_getUVs(*args, **kwargs): pass
def MFnGenericAttribute_removeAccept(*args, **kwargs): pass
def MDataHandle_asFloat3(*args, **kwargs): pass
def MFnDependencyNode_icon(*args, **kwargs): pass
def MTransformationMatrix_rotateTo(*args, **kwargs): pass
def MNodeMessage_addUuidChangedCallback(*args, **kwargs): pass
def MFnVectorArrayData_swigregister(*args, **kwargs): pass
def MFnAttribute_name(*args, **kwargs): pass
def MFnAttribute_setUsedAsColor(*args, **kwargs): pass
def MEulerRotation_inverse(*args, **kwargs): pass
def MScriptUtil_getInt2ArrayItem(*args, **kwargs): pass
def MModelMessage_addNodeRemovedFromModelCallback(*args, **kwargs): pass
def delete_uIntPtr(*args, **kwargs): pass
def MFnNurbsSurface_isTrimmedSurface(*args, **kwargs): pass
def MFnFloatArrayData_length(*args, **kwargs): pass
def MFnDependencyNode_classification(*args, **kwargs): pass
def MTimerMessage_setSleepCallback(*args, **kwargs): pass
def MNodeClass_removeFromClassification(*args, **kwargs): pass
def MFnUnitAttribute_getSoftMax(*args, **kwargs): pass
def MFnAssembly_supportsEdits(*args, **kwargs): pass
def MFnNurbsSurface_removeOneKnotInU(*args, **kwargs): pass
def MFnAttribute_setChannelBox(*args, **kwargs): pass
def MDataHandle_asGenericShort(*args, **kwargs): pass
def MEulerRotation_asQuaternion(*args, **kwargs): pass
def MScriptUtil_setBoolArray(*args, **kwargs): pass
def delete_MAttributePattern(*args, **kwargs): pass
def MIteratorType_getFilterList(*args, **kwargs): pass
def MFnNurbsSurface_removeKnotInU(*args, **kwargs): pass
def MFnLayeredShader_setGlowColor(*args, **kwargs): pass
def MFnAttribute_getAddAttrCmd(*args, **kwargs): pass
def MFnDependencyNode_setUuid(*args, **kwargs): pass
def MTime___truediv__(*args, **kwargs): pass
def MNamespace_getNamespaceObjects(*args, **kwargs): pass
def MFnUint64SingleIndexedComponent_getElements(*args, **kwargs): pass
def MFnAttribute_isExtension(*args, **kwargs): pass
def MDoubleArray_sizeIncrement(*args, **kwargs): pass
def MScriptUtil_setBool(*args, **kwargs): pass
def MFloatMatrix___isub__(*args, **kwargs): pass
def MAttributeSpecArray_sizeIncrement(*args, **kwargs): pass
def MItEdits_currentEditString(*args, **kwargs): pass
def MFnNurbsSurface_degreeV(*args, **kwargs): pass
def MFnEnumAttribute_type(*args, **kwargs): pass
def MFnBase_object(*args, **kwargs): pass
def MTime_asUnits(*args, **kwargs): pass
def MMeshSmoothOptions_setDivisions(*args, **kwargs): pass
def MModelMessage_addAfterDuplicateCallback(*args, **kwargs): pass
def MPointOnNurbs_getUV(*args, **kwargs): pass
def delete_MFnAttribute(*args, **kwargs): pass
def MDataHandle_asMeshTransformed(*args, **kwargs): pass
def MDistance_uiToInternal(*args, **kwargs): pass
def MScriptUtil_asShort2Ptr(*args, **kwargs): pass
def MAttributeIndex___eq__(*args, **kwargs): pass
def MItDependencyGraph_className(*args, **kwargs): pass
def MFnNurbsSurface_getDataObject(*args, **kwargs): pass
def MFnDoubleArrayData_copyTo(*args, **kwargs): pass
def MImage_floatPixels(*args, **kwargs): pass
def MTimeArray_length(*args, **kwargs): pass
def new_MMeshIntersector(*args, **kwargs): pass
def delete_MMatrixArray(*args, **kwargs): pass
def MFnTripleIndexedComponent_addElements(*args, **kwargs): pass
def new_MFnArrayAttrsData(*args, **kwargs): pass
def MDataHandle_asLong3(*args, **kwargs): pass
def MTransformationMatrix_setToRotationAxis(*args, **kwargs): pass
def MDistance_value(*args, **kwargs): pass
def MScriptUtil_asFloat(*args, **kwargs): pass
def MArrayDataHandle_swigregister(*args, **kwargs): pass
def MFnNurbsSurface_getDerivativesAtParm(*args, **kwargs): pass
def MFnNurbsCurve_findLengthFromParam(*args, **kwargs): pass
def MFnCameraSet_getLayerCamera(*args, **kwargs): pass
def new_MFloatVector(*args, **kwargs): pass
def MTesselationParams_setUIsoparmType(*args, **kwargs): pass
def MDagMessage_addChildRemovedCallback(*args, **kwargs): pass
def MMatrix___sub__(*args, **kwargs): pass
def MFnSubdNames_levelOneFaceIdFromLong(*args, **kwargs): pass
def MImage_setFloatPixels(*args, **kwargs): pass
def MFnNonExtendedLight_depthMapFocus(*args, **kwargs): pass
def MDataHandle_asUChar(*args, **kwargs): pass
def MDGMessage_swigregister(*args, **kwargs): pass
def MProfilingScope_swigregister(*args, **kwargs): pass
def MArrayDataHandle_outputValue(*args, **kwargs): pass
def MItDependencyGraph_reset(*args, **kwargs): pass
def MFnDirectionalLight_shadowAngle(*args, **kwargs): pass
def MScriptUtil_setDouble4ArrayItem(*args, **kwargs): pass
def new_MFloatVectorArray(*args, **kwargs): pass
def MTesselationParams_setTriangleCount(*args, **kwargs): pass
def MArgParser_getObjects(*args, **kwargs): pass
def MCurveAttribute_getValuesAtPositions(*args, **kwargs): pass
def MLockMessage_setPlugLockQueryCallback(*args, **kwargs): pass
def MFnSubd_vertexBaseMeshAddWithIndex(*args, **kwargs): pass
def MWeight_seam(*args, **kwargs): pass
def MDGContext_isCurrent(*args, **kwargs): pass
def MProfiler_getBufferSize(*args, **kwargs): pass
def MArgList_addArg(*args, **kwargs): pass
def MItDag_isDone(*args, **kwargs): pass
def MImage_getDepthMapSize(*args, **kwargs): pass
def MFnNurbsCurve_copy(*args, **kwargs): pass
def MFnComponentListData_swigregister(*args, **kwargs): pass
def MFloatPoint___ne__(*args, **kwargs): pass
def MConditionMessage_swigregister(*args, **kwargs): pass
def MItSurfaceCV_next(*args, **kwargs): pass
def MFnSubd_polygonChildren(*args, **kwargs): pass
def MUintArray_append(*args, **kwargs): pass
def MFnNurbsSurface_isPointOnSurface(*args, **kwargs): pass
def MFnAnisotropyShader_rotateAngle(*args, **kwargs): pass
def MVector_normal(*args, **kwargs): pass
def MDataBlock_inputArrayValue(*args, **kwargs): pass
def MItCurveCV_reset(*args, **kwargs): pass
def MFnNumericData_setData3Int(*args, **kwargs): pass
def MFnComponent_setComplete(*args, **kwargs): pass
def MFloatPointArray_className(*args, **kwargs): pass
def MStreamUtils_writeFloat(*args, **kwargs): pass
def MFnLambertShader_className(*args, **kwargs): pass
def MComputation_beginComputation(*args, **kwargs): pass
def MItSubdFace_className(*args, **kwargs): pass
def MFnSubd_edgeBetween(*args, **kwargs): pass
def new_MUintArray(*args, **kwargs): pass
def MFnAmbientLight_swigregister(*args, **kwargs): pass
def MVector___xor__(*args, **kwargs): pass
def MDagPath_pathCount(*args, **kwargs): pass
def MPoint_homogenize(*args, **kwargs): pass
def MCameraSetMessage_className(*args, **kwargs): pass
def MArgParser_commandArgumentDouble(*args, **kwargs): pass
def MInt64Array_className(*args, **kwargs): pass
def MDataHandle_asNurbsCurveTransformed(*args, **kwargs): pass
def new_MFnNumericData(*args, **kwargs): pass
def MFnCamera_tumblePivot(*args, **kwargs): pass
def MFloatMatrix_className(*args, **kwargs): pass
def MItSubdEdge_level(*args, **kwargs): pass
def MFnDoubleArrayData_set(*args, **kwargs): pass
def MFnSubd_vertexBaseMeshSetWithId(*args, **kwargs): pass
def MConnectDisconnectAttrEdit_srcPlug(*args, **kwargs): pass
def MVectorArray_setLength(*args, **kwargs): pass
def MDagPath_node(*args, **kwargs): pass
def new_MPoint(*args, **kwargs): pass
def MIntArray___radd__(*args, **kwargs): pass
def MFnCamera_setFarFocusDistance(*args, **kwargs): pass
def MScriptUtil_getUint2ArrayItem(*args, **kwargs): pass
def MFloatMatrix___iadd__(*args, **kwargs): pass
def MSelectionList_getSelectionStrings(*args, **kwargs): pass
def MMessageNode_isValid_get(*args, **kwargs): pass
def MFnNurbsSurface_hasHistoryOnCreate(*args, **kwargs): pass
def MFnSubd_levelMaxCurrent(*args, **kwargs): pass
def new_MFnLight(*args, **kwargs): pass
def new_MUuid(*args, **kwargs): pass
def MDAGDrawOverrideInfo_fEnableShading_set(*args, **kwargs): pass
def new_MPointArray(*args, **kwargs): pass
def MAngle_value(*args, **kwargs): pass
def MIntArray_remove(*args, **kwargs): pass
def delete_MFnMessageAttribute(*args, **kwargs): pass
def MFnLambertShader_setRefractedRayDepthLimit(*args, **kwargs): pass
def MFnCamera_setLensSqueezeRatio(*args, **kwargs): pass
def MFloatArray___delitem__(*args, **kwargs): pass
def new_MSelectionList(*args, **kwargs): pass
def new_MFnPointLight(*args, **kwargs): pass
def MColor_a_set(*args, **kwargs): pass
def MItMeshVertex_getConnectedVertices(*args, **kwargs): pass
def MFnSubdData_className(*args, **kwargs): pass
def MFnMesh_getClosestPoint(*args, **kwargs): pass
def MSelectionMask_addMask(*args, **kwargs): pass
def MFnContainerNode_className(*args, **kwargs): pass
def MURI_className(*args, **kwargs): pass
def MFloatMatrix_matrix_set(*args, **kwargs): pass
def MDagPathArray_length(*args, **kwargs): pass
def MPlug_asInt(*args, **kwargs): pass
def MImage_filter(*args, **kwargs): pass
def MFnMesh_clearBlindData(*args, **kwargs): pass
def delete_MAttributeIndex(*args, **kwargs): pass
def MFnCamera_setPostScale(*args, **kwargs): pass
def delete_MFloatArray(*args, **kwargs): pass
def MRichSelection_getSymmetryPlane(*args, **kwargs): pass
def MColor___mul__(*args, **kwargs): pass
def MItMeshVertex_position(*args, **kwargs): pass
def MNamespace_rootNamespace(*args, **kwargs): pass
def MFnStringArrayData_length(*args, **kwargs): pass
def MFnTransform_rotationOrder(*args, **kwargs): pass
def MURI_getUserInfo(*args, **kwargs): pass
def MDGModifier_addAttribute(*args, **kwargs): pass
def MPlug_setMTime(*args, **kwargs): pass
def MItMeshEdge_getConnectedEdges(*args, **kwargs): pass
def MFnNurbsSurface_isFlipNorm(*args, **kwargs): pass
def MFnCamera_setStereoHIT(*args, **kwargs): pass
def MFileObject_resolvedFullName(*args, **kwargs): pass
def MConnectDisconnectAttrEdit_srcPlugName(*args, **kwargs): pass
def MItMeshPolygon_isConvex(*args, **kwargs): pass
def MFnSpotLight_dropOff(*args, **kwargs): pass
def MDagPath_isValid(*args, **kwargs): pass
def MFnMesh_extrudeEdges(*args, **kwargs): pass
def delete_MArgList(*args, **kwargs): pass
def MDGModifier_newPlugValueBool(*args, **kwargs): pass
def MPlug_isDynamic(*args, **kwargs): pass
def MIffTag___eq__(*args, **kwargs): pass
def MFileIO_saveAs(*args, **kwargs): pass
def MFnMesh_getColors(*args, **kwargs): pass
def MFnCamera_setShakeOverscanEnabled(*args, **kwargs): pass
def new_MFileObject(*args, **kwargs): pass
def MEdit_setFailed(*args, **kwargs): pass
def array4dInt_get(*args, **kwargs): pass
def MCallbackIdArray_length(*args, **kwargs): pass
def MFnSphereData_type(*args, **kwargs): pass
def MFnMeshData_swigregister(*args, **kwargs): pass
def MFnAssembly_handlesAddEdits(*args, **kwargs): pass
def MMeshSmoothOptions_swigregister(*args, **kwargs): pass
def MPlug_connectedTo(*args, **kwargs): pass
def delete_MIffFile(*args, **kwargs): pass
def MFnTransform_getShear(*args, **kwargs): pass
def MFnMesh_getColorSetsInFamily(*args, **kwargs): pass
def MFcurveEdit_fcurve(*args, **kwargs): pass
def MFileIO_getErrorStatus(*args, **kwargs): pass
def MRenderPassDef_getAttributeType(*args, **kwargs): pass
def MCacheFormatDescription_getDescriptionInfo(*args, **kwargs): pass
def MItMeshPolygon_setUVs(*args, **kwargs): pass
def MFnMatrixAttribute_swigregister(*args, **kwargs): pass
def MFnPhongShader_cosPower(*args, **kwargs): pass
def MFnAssembly_getInitialRep(*args, **kwargs): pass
def MMeshSmoothOptions_setKeepBorderEdge(*args, **kwargs): pass
def MImage_isRGBA(*args, **kwargs): pass
def MFnCamera_isOrtho(*args, **kwargs): pass
def MGlobal_removeOptionVar(*args, **kwargs): pass
def MFnMesh_getAxisAtPoint(*args, **kwargs): pass
def MFnCamera_upDirection(*args, **kwargs): pass
def MRampAttribute_pack(*args, **kwargs): pass
def MBoundingBox_min(*args, **kwargs): pass
def MItMeshPolygon_polygon(*args, **kwargs): pass
def MFnSet_type(*args, **kwargs): pass
def MFnNurbsSurface_isPointInTrimmedRegion(*args, **kwargs): pass
def MFnMatrixArrayData_type(*args, **kwargs): pass
def MFnDagNode_dagPath(*args, **kwargs): pass
def MUint64Array_setSizeIncrement(*args, **kwargs): pass
def floatPtr_assign(*args, **kwargs): pass
def MPlugArray_clear(*args, **kwargs): pass
def MGlobal_removeFromModel(*args, **kwargs): pass
def MFnMesh_currentUVSetName(*args, **kwargs): pass
def MRenderPassRegistry_className(*args, **kwargs): pass
def MFnReference_parentAssembly(*args, **kwargs): pass
def MFloatPointArray_set(*args, **kwargs): pass
def MFileIO_exportAll(*args, **kwargs): pass
def MAttributePatternArray_copy(*args, **kwargs): pass
def MItMeshFaceVertex_getUVIndex(*args, **kwargs): pass
def MFnPluginData_swigregister(*args, **kwargs): pass
def MFnLayeredShader_setTransparency(*args, **kwargs): pass
def MTypeId___eq__(*args, **kwargs): pass
def new_charPtr(*args, **kwargs): pass
def charPtr_swigregister(*args, **kwargs): pass
def MObjectHandle_swigregister(*args, **kwargs): pass
def MFnNurbsSurface_isFoldedOnBispan(*args, **kwargs): pass
def MDataHandle_setMMatrix(*args, **kwargs): pass
def MGlobal_setAnimSelectionMask(*args, **kwargs): pass
def MFnMesh_isEdgeSmooth(*args, **kwargs): pass
def MFnBlinnShader_className(*args, **kwargs): pass
def MEvaluationNodeIterator_next(*args, **kwargs): pass
def MQuaternion_scaleIt(*args, **kwargs): pass
def array3dDouble_set(*args, **kwargs): pass
def MItMeshFaceVertex_isDone(*args, **kwargs): pass
def MFnCamera_setDisplayGateMask(*args, **kwargs): pass
def MImage_swigregister(*args, **kwargs): pass
def MFnLatticeData_type(*args, **kwargs): pass
def MFnDagNode_isParentOf(*args, **kwargs): pass
def delete_MTrimBoundaryArray(*args, **kwargs): pass
def MGlobal_componentSelectionMask(*args, **kwargs): pass
def MObjectArray_copy(*args, **kwargs): pass
def MGlobal_setActiveSelectionList(*args, **kwargs): pass
def MFnMesh_getVertexNormals(*args, **kwargs): pass
def MFnLambertShader_setHideSource(*args, **kwargs): pass
def MFnNurbsSurface_trim(*args, **kwargs): pass
def MEvaluationNode_parentCount(*args, **kwargs): pass
def MQuaternion_asEulerRotation(*args, **kwargs): pass
def array3dFloat_getptr(*args, **kwargs): pass
def MItMeshEdge_edge(*args, **kwargs): pass
def MFnGeometryData_setObjectGroupComponent(*args, **kwargs): pass
def MFnDagNode_type(*args, **kwargs): pass
def MTransformationMatrix_setScalePivotTranslation(*args, **kwargs): pass
def MItMeshPolygon_getConnectedFaces(*args, **kwargs): pass
def MFnContainerNode_getParentContainer(*args, **kwargs): pass
def new_MPointOnNurbs(*args, **kwargs): pass
def MFnLambertShader_incandescence(*args, **kwargs): pass
def MFnVolumeLight_penumbraRamp(*args, **kwargs): pass
def MFnMesh_setPoints(*args, **kwargs): pass
def MFnLambertShader_rtRefractedColor(*args, **kwargs): pass
def MEulerRotation_z_get(*args, **kwargs): pass
def MScriptUtil_getDouble2ArrayItem(*args, **kwargs): pass
def array3dInt_swigregister(*args, **kwargs): pass
def MItInstancer_particleId(*args, **kwargs): pass
def MFnNurbsSurface_setUV(*args, **kwargs): pass
def MDataHandle_setMDistance(*args, **kwargs): pass
def MNodeClass_swigregister(*args, **kwargs): pass
def MFnDependencyNode_getExternalContent(*args, **kwargs): pass
def MPointArray_clear(*args, **kwargs): pass
def MTransformationMatrix_rotateBy(*args, **kwargs): pass
def MNodeMessage_addNodeAboutToDeleteCallback(*args, **kwargs): pass
def MFnVolumeLight_type(*args, **kwargs): pass
def MFnAttribute_setUsedAsFilename(*args, **kwargs): pass
def MFnAttribute_shortName(*args, **kwargs): pass
def MQuaternion___eq__(*args, **kwargs): pass
def MNodeClass_classification(*args, **kwargs): pass
def uIntPtr_assign(*args, **kwargs): pass
def MItGeometry_reset(*args, **kwargs): pass
def MFnNurbsSurface_numRegions(*args, **kwargs): pass
def MFnFloatArrayData___getitem__(*args, **kwargs): pass
def MTesselationParams_setStdChordHeightRatio(*args, **kwargs): pass
def MFnDependencyNode_isNewAttribute(*args, **kwargs): pass
def MTimerMessage_sleepCallback(*args, **kwargs): pass
def MNodeClass_pluginName(*args, **kwargs): pass
def MFnUnitAttribute_setMin(*args, **kwargs): pass
def delete_charPtr(*args, **kwargs): pass
def MFnAttribute_setHidden(*args, **kwargs): pass
def MDataHandle_asGenericInt(*args, **kwargs): pass
def MEulerRotation_asMatrix(*args, **kwargs): pass
def MScriptUtil_setCharArray(*args, **kwargs): pass
def MAttributePattern_findPattern(*args, **kwargs): pass
def MIteratorType_getObjectType(*args, **kwargs): pass
def MFnNurbsSurface_removeKnotInV(*args, **kwargs): pass
def MFnDependencyNode_isDefaultNode(*args, **kwargs): pass
def new_MFnExpression(*args, **kwargs): pass
def MDataHandle_set3Double(*args, **kwargs): pass
def MFnLambertShader_glowIntensity(*args, **kwargs): pass
def MFnDependencyNode_getConnections(*args, **kwargs): pass
def MTime___itruediv__(*args, **kwargs): pass
def MNamespace_moveNamespace(*args, **kwargs): pass
def MFnUint64SingleIndexedComponent_setCompleteData(*args, **kwargs): pass
def MFnAttribute_isWorldSpace(*args, **kwargs): pass
def MDataHandle_set2Short(*args, **kwargs): pass
def MDoubleArray_className(*args, **kwargs): pass
def MScriptUtil_setChar(*args, **kwargs): pass
def MAttributeSpecArray_className(*args, **kwargs): pass
def MItEdits_currentEditType(*args, **kwargs): pass
def MFnNurbsSurface_numSpansInU(*args, **kwargs): pass
def delete_MFnEnumAttribute(*args, **kwargs): pass
def MFnBase_setObject(*args, **kwargs): pass
def MTime_uiUnit(*args, **kwargs): pass
def MMeshSmoothOptions_divisions(*args, **kwargs): pass
def MModelMessage_addNodeAddedToModelCallback(*args, **kwargs): pass
def MEulerRotation_setToAlternateSolution(*args, **kwargs): pass
def MNodeClass_addExtensionAttribute(*args, **kwargs): pass
def MFnAttribute_className(*args, **kwargs): pass
def MDataHandle_asSubdSurfaceTransformed(*args, **kwargs): pass
def MScriptUtil_asShort3Ptr(*args, **kwargs): pass
def MAttributeIndex___ne__(*args, **kwargs): pass
def MItDependencyGraph_swigregister(*args, **kwargs): pass
def MFnNurbsSurface_cv(*args, **kwargs): pass
def charPtr_frompointer(*args, **kwargs): pass
def MFloatVector_length(*args, **kwargs): pass
def MTimeArray_remove(*args, **kwargs): pass
def delete_MMeshIntersector(*args, **kwargs): pass
def MMatrixArray___getitem__(*args, **kwargs): pass
def MFnTripleIndexedComponent_getElement(*args, **kwargs): pass
def MFnArrayAttrsData_clear(*args, **kwargs): pass
def MDataHandle_asInt3(*args, **kwargs): pass
def MDataHandle_asShort2(*args, **kwargs): pass
def MDistance_setUnit(*args, **kwargs): pass
def MFnNurbsSurface_getPatchUV(*args, **kwargs): pass
def MItDependencyGraph_currentLevel(*args, **kwargs): pass
def MFnNurbsCurve_hasHistoryOnCreate(*args, **kwargs): pass
def MFnCameraSet_setLayerSceneData(*args, **kwargs): pass
def delete_MFloatVector(*args, **kwargs): pass
def delete_MUuid(*args, **kwargs): pass
def MTesselationParams_setVIsoparmType(*args, **kwargs): pass
def MDagMessage_addChildRemovedDagPathCallback(*args, **kwargs): pass
def MMatrix___imul__(*args, **kwargs): pass
def MFnSubdNames_levelOneFaceIdFromIndex(*args, **kwargs): pass
def new_MFloatPoint(*args, **kwargs): pass
def MFnNonExtendedLight_setDepthMapFocus(*args, **kwargs): pass
def MDataHandle_asShort(*args, **kwargs): pass
def MCameraSetMessage_addCameraLayerCallback(*args, **kwargs): pass
def MPolyMessage_addPolyComponentIdChangedCallback(*args, **kwargs): pass
def MArrayDataHandle_inputArrayValue(*args, **kwargs): pass
def MItDependencyGraph_resetTo(*args, **kwargs): pass
def MFnNurbsCurve_knot(*args, **kwargs): pass
def MTesselationParams_swigregister(*args, **kwargs): pass
def MFnDirectionalLight_setShadowAngle(*args, **kwargs): pass
def MFnMessageAttribute_className(*args, **kwargs): pass
def delete_MFloatVectorArray(*args, **kwargs): pass
def MArgList_swigregister(*args, **kwargs): pass
def MCurveAttribute_getValueAtPosition(*args, **kwargs): pass
def MLockMessage_className(*args, **kwargs): pass
def MFnSubd_swigregister(*args, **kwargs): pass
def MFnNonExtendedLight_shadowRadius(*args, **kwargs): pass
def MWeight_setInfluence(*args, **kwargs): pass
def MDGContext_makeCurrent(*args, **kwargs): pass
def MProfiler_setBufferSize(*args, **kwargs): pass
def MArgList_className(*args, **kwargs): pass
def MItDag_root(*args, **kwargs): pass
def MFnReflectShader_className(*args, **kwargs): pass
def MFnNurbsCurve_reverse(*args, **kwargs): pass
def MFnCompoundAttribute_type(*args, **kwargs): pass
def MFloatPoint_cartesianize(*args, **kwargs): pass
def MSyntax_setObjectType(*args, **kwargs): pass
def MContainerMessage_addPublishAttrCallback(*args, **kwargs): pass
def MItSurfaceCV_nextRow(*args, **kwargs): pass
def MFnSubd_polygonSubdivide(*args, **kwargs): pass
def MUintArray_sizeIncrement(*args, **kwargs): pass
def MIntArray_sizeIncrement(*args, **kwargs): pass
def MFnAnisotropyShader_setRotateAngle(*args, **kwargs): pass
def MVector_normalize(*args, **kwargs): pass
def MDataBlock_outputArrayValue(*args, **kwargs): pass
def MProfiler_categoryRecording(*args, **kwargs): pass
def MArgList_length(*args, **kwargs): pass
def MFnNumericData_setData3Float(*args, **kwargs): pass
def MFnComponent_hasWeights(*args, **kwargs): pass
def MFloatPointArray_swigregister(*args, **kwargs): pass
def MStreamUtils_writeDouble(*args, **kwargs): pass
def MFloatPoint_assign(*args, **kwargs): pass
def MComputation_isInterruptRequested(*args, **kwargs): pass
def MItSubdFace_swigregister(*args, **kwargs): pass
def MFnSubd_edgeVertices(*args, **kwargs): pass
def MFnAnisotropyShader_type(*args, **kwargs): pass
def MVector___itruediv__(*args, **kwargs): pass
def MDagPath_getPath(*args, **kwargs): pass
def MPoint_distanceTo(*args, **kwargs): pass
def MPoint___mul__(*args, **kwargs): pass
def MArgParser_commandArgumentString(*args, **kwargs): pass
def MDataHandle_setMObject(*args, **kwargs): pass
def MFnNumericData_create(*args, **kwargs): pass
def MFnCamera_unnormalizedNearClippingPlane(*args, **kwargs): pass
def MFloatMatrix_swigregister(*args, **kwargs): pass
def MParentingEdit_parentedObjectName(*args, **kwargs): pass
def MCommandMessage_addCommandOutputCallback(*args, **kwargs): pass
def MItSubdEdge_setLevel(*args, **kwargs): pass
def MFnSubd_vertexValence(*args, **kwargs): pass
def MArrayDataBuilder_removeElement(*args, **kwargs): pass
def MFnLight_lightDirection(*args, **kwargs): pass
def MDagPath_transform(*args, **kwargs): pass
def delete_MPoint(*args, **kwargs): pass
def MArgParser_isFlagSet(*args, **kwargs): pass
def MIntArray___iadd__(*args, **kwargs): pass
def MFnNumericAttribute_hasSoftMax(*args, **kwargs): pass
def MItSubdFace_next(*args, **kwargs): pass
def MFloatMatrix___add__(*args, **kwargs): pass
def MSceneMessage_addNamespaceRenamedCallback(*args, **kwargs): pass
def MItSelectionList_getDagPath(*args, **kwargs): pass
def MFnSubd_levelMaxAllowed(*args, **kwargs): pass
def MFnLight_color(*args, **kwargs): pass
def MScriptUtil_setFloat3ArrayItem(*args, **kwargs): pass
def MDAGDrawOverrideInfo_fEnableShading_get(*args, **kwargs): pass
def MAngle_setUnit(*args, **kwargs): pass
def MIntArray_insert(*args, **kwargs): pass
def MFnReflectShader_reflectivity(*args, **kwargs): pass
def MFnCamera_lensSqueezeRatio(*args, **kwargs): pass
def MFloatArray___repr__(*args, **kwargs): pass
def MColor_a_get(*args, **kwargs): pass
def MItMeshVertex_numConnectedFaces(*args, **kwargs): pass
def MFnContainerNode_clear(*args, **kwargs): pass
def MFnMesh_getClosestNormal(*args, **kwargs): pass
def new_MFnContainerNode(*args, **kwargs): pass
def MDataHandle_asGenericDouble(*args, **kwargs): pass
def MDagPathArray_remove(*args, **kwargs): pass
def MPlug_asShort(*args, **kwargs): pass
def new_MObject(*args, **kwargs): pass
def MImage_writeToFile(*args, **kwargs): pass
def MFnMesh_componentTypeName(*args, **kwargs): pass
def MFloatArray_assign(*args, **kwargs): pass
def MColor___itruediv__(*args, **kwargs): pass
def MItMeshVertex_setPosition(*args, **kwargs): pass
def delete_MSceneMessage(*args, **kwargs): pass
def MFnStringArrayData_copyTo(*args, **kwargs): pass
def MFnMesh_getTriangles(*args, **kwargs): pass
def MFnTransform_setRotationOrder(*args, **kwargs): pass
def MURI_getUserName(*args, **kwargs): pass
def MDGModifier_removeAttribute(*args, **kwargs): pass
def MImage_readFromTextureNode(*args, **kwargs): pass
def delete_MFloatMatrix(*args, **kwargs): pass
def MFnMesh_getFaceVertexBlindDataIndex(*args, **kwargs): pass
def delete_MFnPartition(*args, **kwargs): pass
def MFnCamera_setFilmFit(*args, **kwargs): pass
def MNodeMessage_addNodeDirtyPlugCallback(*args, **kwargs): pass
def MConnectDisconnectAttrEdit_dstPlugName(*args, **kwargs): pass
def MColorArray_remove(*args, **kwargs): pass
def MItMeshPolygon_isStarlike(*args, **kwargs): pass
def MFnSpotLight_setDropOff(*args, **kwargs): pass
def MFnMesh_duplicateFaces(*args, **kwargs): pass
def MFnTransform_setScalePivot(*args, **kwargs): pass
def MURI_setDirectory(*args, **kwargs): pass
def MFnReflectShader_swigregister(*args, **kwargs): pass
def MDGModifier_newPlugValueChar(*args, **kwargs): pass
def MPlug_isIgnoredWhenRendering(*args, **kwargs): pass
def MIffTag_swigregister(*args, **kwargs): pass
def MFnMesh_getColorIndex(*args, **kwargs): pass
def MFnCamera_shakeOverscan(*args, **kwargs): pass
def delete_MFileObject(*args, **kwargs): pass
def MEdit_hasEditData(*args, **kwargs): pass
def delete_MVectorArray(*args, **kwargs): pass
def delete_MSelectionList(*args, **kwargs): pass
def delete_MFnSphereData(*args, **kwargs): pass
def MFnMesh_type(*args, **kwargs): pass
def MTesselationParams_className(*args, **kwargs): pass
def MUintArray___ne__(*args, **kwargs): pass
def new_MDGModifier(*args, **kwargs): pass
def MPlug_isConnected(*args, **kwargs): pass
def MIffFile_open(*args, **kwargs): pass
def MFnMesh_isColorSetPerInstance(*args, **kwargs): pass
def MArrayDataBuilder_swigregister(*args, **kwargs): pass
def MFileIO_resetError(*args, **kwargs): pass
def MRenderPassDef_addFloatParameter(*args, **kwargs): pass
def MCacheFormatDescription_getNumChannels(*args, **kwargs): pass
def MFnSet_setAnnotation(*args, **kwargs): pass
def MFnMatrixData_type(*args, **kwargs): pass
def MFnContainerNode_makeCurrent(*args, **kwargs): pass
def MFnAssembly_getRepresentations(*args, **kwargs): pass
def MUintArray_setLength(*args, **kwargs): pass
def MIntArray_swigregister(*args, **kwargs): pass
def MUint64Array_clear(*args, **kwargs): pass
def MPlug_isChild(*args, **kwargs): pass
def MGlobal_optionVarExists(*args, **kwargs): pass
def MFnMesh_getPolygonUV(*args, **kwargs): pass
def MFnCamera_rightDirection(*args, **kwargs): pass
def MFileIO_mustRenameToSave(*args, **kwargs): pass
def MRampAttribute_setRamp(*args, **kwargs): pass
def MBoundingBox_max(*args, **kwargs): pass
def MItMeshPolygon_currentItem(*args, **kwargs): pass
def MSelectionList_length(*args, **kwargs): pass
def delete_MFnMatrixArrayData(*args, **kwargs): pass
def MFnDagNode_setObject(*args, **kwargs): pass
def MUint64Array_sizeIncrement(*args, **kwargs): pass
def floatPtr_value(*args, **kwargs): pass
def MPlugArray_setSizeIncrement(*args, **kwargs): pass
def MGlobal_deleteNode(*args, **kwargs): pass
def MFnAssembly_createRepresentation(*args, **kwargs): pass
def MFnMesh_getUVSetNames(*args, **kwargs): pass
def MDataHandle_asDistance(*args, **kwargs): pass
def MFloatPoint_rationalize(*args, **kwargs): pass
def MAttributePatternArray_clear(*args, **kwargs): pass
def MItMeshFaceVertex_hasColor(*args, **kwargs): pass
def MFnPointArrayData_type(*args, **kwargs): pass
def MFnLayeredShader_glowColor(*args, **kwargs): pass
def MFnDagNode_setUseObjectColor(*args, **kwargs): pass
def MTypeId___ne__(*args, **kwargs): pass
def new_intPtr(*args, **kwargs): pass
def MObjectSetMessage_addSetMembersModifiedCallback(*args, **kwargs): pass
def MArrayDataHandle_outputArrayValue(*args, **kwargs): pass
def MGlobal_miscSelectionMask(*args, **kwargs): pass
def MFnMesh_setEdgeSmoothing(*args, **kwargs): pass
def new_MFnBlinnShader(*args, **kwargs): pass
def MEvaluationNodeIterator_reset(*args, **kwargs): pass
def array3dDouble_getptr(*args, **kwargs): pass
def MItMeshFaceVertex_next(*args, **kwargs): pass
def MFnDependencyNode_getAliasAttr(*args, **kwargs): pass
def MFnPhongShader_type(*args, **kwargs): pass
def MInt64Array_set(*args, **kwargs): pass
def delete_MFnLatticeData(*args, **kwargs): pass
def MVectorArray_length(*args, **kwargs): pass
def MFnDagNode_inUnderWorld(*args, **kwargs): pass
def MObjectArray_clear(*args, **kwargs): pass
def MGlobal_setRichSelection(*args, **kwargs): pass
def new_MMessageNode(*args, **kwargs): pass
def MFnLambertShader_swigregister(*args, **kwargs): pass
def MSelectionList_add(*args, **kwargs): pass
def MEvaluationNode_parent(*args, **kwargs): pass
def MQuaternion_setAxisAngle(*args, **kwargs): pass
def array3dFloat_swigregister(*args, **kwargs): pass
def MItMeshEdge_currentItem(*args, **kwargs): pass
def MFnPartition_isRenderPartition(*args, **kwargs): pass
def MFnGeometryData_addObjectGroupComponent(*args, **kwargs): pass
def delete_MFnDagNode(*args, **kwargs): pass
def MTransformationMatrix_rotatePivot(*args, **kwargs): pass
def MFnContainerNode_isCurrent(*args, **kwargs): pass
def MFloatPoint_x_set(*args, **kwargs): pass
def MFnVolumeLight_shadowAngle(*args, **kwargs): pass
def MDGMessage_addDelayedTimeChangeRunupCallback(*args, **kwargs): pass
def MFnMesh_getVertices(*args, **kwargs): pass
def MFnLambertShader_setRtRefractedColor(*args, **kwargs): pass
def MPlug_setChannelBox(*args, **kwargs): pass
def MEulerRotation_order_set(*args, **kwargs): pass
def MScriptUtil_setDouble2ArrayItem(*args, **kwargs): pass
def new_array4dInt(*args, **kwargs): pass
def MItInstancer_pathId(*args, **kwargs): pass
def MFnNurbsSurface_getUV(*args, **kwargs): pass
def MArrayDataHandle_jumpToElement(*args, **kwargs): pass
def MTransformationMatrix_addRotationQuaternion(*args, **kwargs): pass
def MNodeMessage_addNodePreRemovalCallback(*args, **kwargs): pass
def delete_MCameraMessage(*args, **kwargs): pass
def MFloatPoint_y_set(*args, **kwargs): pass
def uIntPtr_value(*args, **kwargs): pass
def new_MTimerMessage(*args, **kwargs): pass
def MFnPhongEShader_roughness(*args, **kwargs): pass
def MDataHandle_asGenericInt64(*args, **kwargs): pass
def MScriptUtil_setUcharArray(*args, **kwargs): pass
def array2dFloat_set(*args, **kwargs): pass
def MFnReference_className(*args, **kwargs): pass
def MTime_className(*args, **kwargs): pass
def MDataHandle_set2Int(*args, **kwargs): pass
def MDoubleArray___len__(*args, **kwargs): pass
def new_MFnReference(*args, **kwargs): pass
def MTime_setUIUnit(*args, **kwargs): pass
def MAttributeIndex_getValue(*args, **kwargs): pass
def new_MFnUInt64ArrayData(*args, **kwargs): pass
def MNurbsIntersector_getIntersect(*args, **kwargs): pass
def MDataHandle_geometryTransformMatrix(*args, **kwargs): pass
def MScriptUtil_asShort4Ptr(*args, **kwargs): pass
def new_MItDependencyNodes(*args, **kwargs): pass
def MFnPhongEShader_whiteness(*args, **kwargs): pass
def MMeshIntersector_create(*args, **kwargs): pass
def MItMeshEdge_swigregister(*args, **kwargs): pass
def MFnReference_parentFileName(*args, **kwargs): pass
def new_MAttributeIndex(*args, **kwargs): pass
def MDagMessage_addChildReorderedCallback(*args, **kwargs): pass
def MSelectionList_className(*args, **kwargs): pass
def array2dFloat_getptr(*args, **kwargs): pass
def new_MLockMessage(*args, **kwargs): pass
def new_MFnSubdNames(*args, **kwargs): pass
def MInt64Array___len__(*args, **kwargs): pass
def MItCurveCV_isDone(*args, **kwargs): pass
def MFnAssembly_postLoad(*args, **kwargs): pass
def delete_MFnPhongShader(*args, **kwargs): pass
def MFnAnisotropyShader_refractiveIndex(*args, **kwargs): pass
def MStreamUtils_readChar(*args, **kwargs): pass
def new_MItSubdVertex(*args, **kwargs): pass
def MFnCamera_postScale(*args, **kwargs): pass
def MFnSubd_polygonIsValid(*args, **kwargs): pass
def MSelectionMask_setMask(*args, **kwargs): pass
def new_MFloatPointArray(*args, **kwargs): pass
def MParentingEdit_parentName(*args, **kwargs): pass
def MInt64Array___repr__(*args, **kwargs): pass
def MPoint_get(*args, **kwargs): pass
def MFnNurbsCurve_createWithEditPoints(*args, **kwargs): pass
def MAttributeIndex_hasRange(*args, **kwargs): pass
def MFnSubd_levelFullySubdivideTo(*args, **kwargs): pass
def MUuid_assign(*args, **kwargs): pass
def MPointArray___getitem__(*args, **kwargs): pass
def MFloatVectorArray_length(*args, **kwargs): pass
def MFnCamera_setClippingPlanes(*args, **kwargs): pass
def MSelectionList_clear(*args, **kwargs): pass
def MItMeshVertex_numConnectedEdges(*args, **kwargs): pass
def MFnSubdData_create(*args, **kwargs): pass
def MUintArray___eq__(*args, **kwargs): pass
def MFnMesh_getClosestUVs(*args, **kwargs): pass
def MMeshSmoothOptions_setOpenSubdivVertexBoundary(*args, **kwargs): pass
def new_MUserData(*args, **kwargs): pass
def MDagPathArray_insert(*args, **kwargs): pass
def MPlug_asBool(*args, **kwargs): pass
def delete_MObject(*args, **kwargs): pass
def MImage_writeToFileWithDepth(*args, **kwargs): pass
def new_MCommandResult(*args, **kwargs): pass
def MFnCamera_setFilmTranslateH(*args, **kwargs): pass
def MFloatArray_set(*args, **kwargs): pass
def MRichSelection_setSelection(*args, **kwargs): pass
def MColor___truediv__(*args, **kwargs): pass
def MObjectArray___getitem__(*args, **kwargs): pass
def MFnMesh_getTriangleOffsets(*args, **kwargs): pass
def MFnTransform_restPosition(*args, **kwargs): pass
def MDGModifier_pythonCommandToExecute(*args, **kwargs): pass
def MPlug_setString(*args, **kwargs): pass
def MFnAttribute_accepts(*args, **kwargs): pass
def MFnMesh_getBlindDataFaceVertexIndices(*args, **kwargs): pass
def delete_MFnPluginData(*args, **kwargs): pass
def MConnectDisconnectAttrEdit_isConnection(*args, **kwargs): pass
def MColorArray_insert(*args, **kwargs): pass
def MFileObject_pathCount(*args, **kwargs): pass
def MURI_setAuthority(*args, **kwargs): pass
def MSelectionMask_getSelectionTypePriority(*args, **kwargs): pass
def MDGModifier_newPlugValueDouble(*args, **kwargs): pass
def new_MImageFileInfo(*args, **kwargs): pass
def MFnMesh_setColor(*args, **kwargs): pass
def MFileObject_assign(*args, **kwargs): pass
def new_MDagMessage(*args, **kwargs): pass
def MFloatVectorArray_clear(*args, **kwargs): pass
def delete_MFnMesh(*args, **kwargs): pass
def delete_MDGModifier(*args, **kwargs): pass
def MIffFile_close(*args, **kwargs): pass
def MObjectArray_remove(*args, **kwargs): pass
def MRenderPassDef_addDoubleParameter(*args, **kwargs): pass
def MCacheFormatDescription_getChannelName(*args, **kwargs): pass
def delete_MFnLight(*args, **kwargs): pass
def MFnAssembly_getRepType(*args, **kwargs): pass
def MFnPluginData_data(*args, **kwargs): pass
def MMeshSmoothOptions_setKeepHardEdge(*args, **kwargs): pass
def MFnMesh_getPolygonUVid(*args, **kwargs): pass
def MFnCamera_centerOfInterestPoint(*args, **kwargs): pass
def MFileIO_setMustRenameToSave(*args, **kwargs): pass
def MRampAttribute_createCurveRamp(*args, **kwargs): pass
def MBoundingBox_assign(*args, **kwargs): pass
def MItMeshPolygon_index(*args, **kwargs): pass
def MFnCamera_create(*args, **kwargs): pass
def MFnSet_className(*args, **kwargs): pass
def MFnMatrixArrayData_className(*args, **kwargs): pass
def MFnDagNode_model(*args, **kwargs): pass
def MUint64Array_className(*args, **kwargs): pass
def floatPtr_cast(*args, **kwargs): pass
def MPlugArray_sizeIncrement(*args, **kwargs): pass
def MGlobal_setYAxisUp(*args, **kwargs): pass
def MFloatMatrix_setToIdentity(*args, **kwargs): pass
def MFnMesh_getUVSetFamilyNames(*args, **kwargs): pass
def MFloatVectorArray_className(*args, **kwargs): pass
def MFileIO_exportSelectedAnimFromReference(*args, **kwargs): pass
def new_MRampAttribute(*args, **kwargs): pass
def MAttributePatternArray_setSizeIncrement(*args, **kwargs): pass
def MItMeshFaceVertex_getColor(*args, **kwargs): pass
def MTypeId_id(*args, **kwargs): pass
def delete_intPtr(*args, **kwargs): pass
def MAttributeIndex_setUpper(*args, **kwargs): pass
def MFnMesh_setEdgeSmoothings(*args, **kwargs): pass
def MFnBlinnShader_create(*args, **kwargs): pass
def MEvaluationNodeIterator_className(*args, **kwargs): pass
def MQuaternion_normalizeIt(*args, **kwargs): pass
def array3dDouble_swigregister(*args, **kwargs): pass
def delete_MDagMessage(*args, **kwargs): pass
def MItMeshFaceVertex_reset(*args, **kwargs): pass
def MItCurveCV_setPosition(*args, **kwargs): pass
def MFnLatticeData_className(*args, **kwargs): pass
def MFnDagNode_inModel(*args, **kwargs): pass
def MTrimBoundaryArray_length(*args, **kwargs): pass
def MObjectArray_setSizeIncrement(*args, **kwargs): pass
def MGlobal_setDisplayCVs(*args, **kwargs): pass
def MFnMesh_isNormalLocked(*args, **kwargs): pass
def delete_MFnPointArrayData(*args, **kwargs): pass
def MEvaluationNode_childCount(*args, **kwargs): pass
def new_array4dFloat(*args, **kwargs): pass
def MFnPartition_addMember(*args, **kwargs): pass
def MFnGeometryData_removeObjectGroupComponent(*args, **kwargs): pass
def MFnDagNode_className(*args, **kwargs): pass
def MTransformationMatrix_setRotatePivot(*args, **kwargs): pass
def MItCurveCV_position(*args, **kwargs): pass
def MObjectArray_className(*args, **kwargs): pass
def MEvaluationNode_swigregister(*args, **kwargs): pass
def MFnLambertShader_diffuseCoeff(*args, **kwargs): pass
def MEulerRotation_order_get(*args, **kwargs): pass
def MScriptUtil_getDouble3ArrayItem(*args, **kwargs): pass
def delete_array4dInt(*args, **kwargs): pass
def MItInstancer_className(*args, **kwargs): pass
def MAttributeIndex_className(*args, **kwargs): pass
def delete_MFnGeometryData(*args, **kwargs): pass
def MNodeMessage_addNodeDestroyedCallback(*args, **kwargs): pass
def MFnAssembly_getParentAssembly(*args, **kwargs): pass
def MEdit_matches(*args, **kwargs): pass
def MFnAttribute_addToCategory(*args, **kwargs): pass
def MItCurveCV_currentItem(*args, **kwargs): pass
def MEulerRotation_reorderIt(*args, **kwargs): pass
def MScriptUtil_setInt3ArrayItem(*args, **kwargs): pass
def uIntPtr_cast(*args, **kwargs): pass
def MItGeometry_setAllPositions(*args, **kwargs): pass
def MFnNurbsSurface_numBoundaries(*args, **kwargs): pass
def MFnFloatArrayData_set(*args, **kwargs): pass
def MFnDependencyNode_deallocateFlag(*args, **kwargs): pass
def delete_MTimerMessage(*args, **kwargs): pass
def MNodeClass_removeExtensionAttribute(*args, **kwargs): pass
def new_MAttributeSpecArray(*args, **kwargs): pass
def MFnUnitAttribute_setSoftMin(*args, **kwargs): pass
def MFnMesh_setIsColorClamped(*args, **kwargs): pass
def MFnAttribute_setIndeterminant(*args, **kwargs): pass
def MDataHandle_setGenericBool(*args, **kwargs): pass
def MEulerRotation___getitem__(*args, **kwargs): pass
def MScriptUtil_getIntArrayItem(*args, **kwargs): pass
def MAttributePattern_attrPattern(*args, **kwargs): pass
def MIteratorType_swigregister(*args, **kwargs): pass
def MPlug_isDefaultValue(*args, **kwargs): pass
def MFnNurbsSurface_removeOneKnotInV(*args, **kwargs): pass
def MFnCamera_hasSamePerspective(*args, **kwargs): pass
def MFnDependencyNode_reorderedAttribute(*args, **kwargs): pass
def MNamespace_relativeNames(*args, **kwargs): pass
def MFnUint64SingleIndexedComponent_swigregister(*args, **kwargs): pass
def MDataHandle_set2Float(*args, **kwargs): pass
def MDoubleArray___setitem__(*args, **kwargs): pass
def MDGModifier_setNodeLockState(*args, **kwargs): pass
def MItEdits_edit(*args, **kwargs): pass
def MFnNurbsSurface_numNonZeroSpansInU(*args, **kwargs): pass
def new_MFnEnumAttribute(*args, **kwargs): pass
def MFnBase_swigregister(*args, **kwargs): pass
def MTime_assign(*args, **kwargs): pass
def MMeshSmoothOptions_smoothness(*args, **kwargs): pass
def MItMeshPolygon_isLamina(*args, **kwargs): pass
def MModelMessage_className(*args, **kwargs): pass
def MFnUInt64ArrayData_length(*args, **kwargs): pass
def MObjectHandle_hashCode(*args, **kwargs): pass
def MDataHandle_asPluginData(*args, **kwargs): pass
def MDistance_swigregister(*args, **kwargs): pass
def MScriptUtil_asFloat2Ptr(*args, **kwargs): pass
def MAttributeIndex_swigregister(*args, **kwargs): pass
def MFnNurbsSurface_cvsInV(*args, **kwargs): pass
def MFnDoubleArrayData_create(*args, **kwargs): pass
def MFnPointArrayData_swigregister(*args, **kwargs): pass
def MFloatVector_normalize(*args, **kwargs): pass
def MTimeArray_append(*args, **kwargs): pass
def MMeshIntersector_isCreated(*args, **kwargs): pass
def MMatrixArray_set(*args, **kwargs): pass
def MFnTripleIndexedComponent_setCompleteData(*args, **kwargs): pass
def MFnArrayAttrsData_list(*args, **kwargs): pass
def MDataHandle_asDouble3(*args, **kwargs): pass
def MImage_getSize(*args, **kwargs): pass
def MScriptUtil_asUint(*args, **kwargs): pass
def MStreamUtils_stdOutStream(*args, **kwargs): pass
def MAttributeIndex_type(*args, **kwargs): pass
def MItDependencyGraph_isTraversingOverWorldSpaceDependents(*args, **kwargs): pass
def MFnNurbsCurve_rebuild(*args, **kwargs): pass
def MFnCameraSet_setLayerActive(*args, **kwargs): pass
def MFloatVector___call__(*args, **kwargs): pass
def MTesselationParams_setVNumber(*args, **kwargs): pass
def MDagMessage_addChildReorderedDagPathCallback(*args, **kwargs): pass
def MMatrix___eq__(*args, **kwargs): pass
def MFnSubdNames_baseFaceIdFromIndex(*args, **kwargs): pass
def MDGModifier_addExtensionAttribute(*args, **kwargs): pass
def MMeshSmoothOptions_keepBorderEdge(*args, **kwargs): pass
def MFnAreaLight_type(*args, **kwargs): pass
def MPolyMessage_addUVSetChangedCallback(*args, **kwargs): pass
def MArrayDataHandle_next(*args, **kwargs): pass
def MItDependencyGraph_rootPlug(*args, **kwargs): pass
def MFnNurbsCurve_isPointOnCurve(*args, **kwargs): pass
def MGlobal_setMiscSelectionMask(*args, **kwargs): pass
def MFnDirectionalLight_setUseLightPosition(*args, **kwargs): pass
def MObjectHandle___ne__(*args, **kwargs): pass
def MFloatVectorArray_assign(*args, **kwargs): pass
def MTesselationParams_setStdMinEdgeLength(*args, **kwargs): pass
def MCurveAttribute_hasIndex(*args, **kwargs): pass
def delete_MLockMessage(*args, **kwargs): pass
def delete_MFnSubdNames(*args, **kwargs): pass
def MFnNonExtendedLight_castSoftShadows(*args, **kwargs): pass
def delete_MDGContextGuard(*args, **kwargs): pass
def MProfiler_eventDataAvailable(*args, **kwargs): pass
def MItDag_next(*args, **kwargs): pass
def MItDag_getType(*args, **kwargs): pass
def MFnNurbsCurve_cv(*args, **kwargs): pass
def MFnCompoundAttribute_className(*args, **kwargs): pass
def MFloatPoint_homogenize(*args, **kwargs): pass
def MContainerMessage_className(*args, **kwargs): pass
def MItSurfaceCV_position(*args, **kwargs): pass
def MFnMesh_componentTypeFromName(*args, **kwargs): pass
def MFnAnisotropyShader_roughness(*args, **kwargs): pass
def MFnSubd_polygonHasVertexUVs(*args, **kwargs): pass
def MFnCamera_horizontalFilmAperture(*args, **kwargs): pass
def MFnAnisotropyShader_setRefractiveIndex(*args, **kwargs): pass
def MVector_isEquivalent(*args, **kwargs): pass
def MDataBlock_isClean(*args, **kwargs): pass
def MProfiler_signalEvent(*args, **kwargs): pass
def MArgList_asInt(*args, **kwargs): pass
def MFnNumericData_setData4Double(*args, **kwargs): pass
def MFnComponent_setWeight(*args, **kwargs): pass
def delete_MFloatPoint(*args, **kwargs): pass
def MFloatVector___ne__(*args, **kwargs): pass
def MComputation_setProgressRange(*args, **kwargs): pass
def delete_MItSubdVertex(*args, **kwargs): pass
def MFnDoubleIndexedComponent_type(*args, **kwargs): pass
def MFnSubd_edgeIsBoundary(*args, **kwargs): pass
def MVector___add__(*args, **kwargs): pass
def MDagPath_partialPathName(*args, **kwargs): pass
def MTransformationMatrix_setRotatePivotTranslation(*args, **kwargs): pass
def MPoint_x_set(*args, **kwargs): pass
def MArgParser_commandArgumentMDistance(*args, **kwargs): pass
def MInt64Array___setitem__(*args, **kwargs): pass
def MAttributeSpecArray_clear(*args, **kwargs): pass
def MFnCamera_setUsePivotAsLocalSpace(*args, **kwargs): pass
def delete_MFloatPointArray(*args, **kwargs): pass
def MParentingEdit_editType(*args, **kwargs): pass
def MCommandMessage_className(*args, **kwargs): pass
def MItSubdEdge_isSharp(*args, **kwargs): pass
def MFnMesh_updateSurface(*args, **kwargs): pass
def MFnSubd_vertexAdjacentVertices(*args, **kwargs): pass
def MFnCamera_getFilmApertureLimits(*args, **kwargs): pass
def MFnLight_lightDiffuse(*args, **kwargs): pass
def MVectorArray_insert(*args, **kwargs): pass
def MDagPath_extendToShape(*args, **kwargs): pass
def MPoint___getitem__(*args, **kwargs): pass
def MArgParser_isQuery(*args, **kwargs): pass
def new_MInt64Array(*args, **kwargs): pass
def MFnNumericAttribute_getMax(*args, **kwargs): pass
def MPlug_constructHandle(*args, **kwargs): pass
def MSelectionList_swigregister(*args, **kwargs): pass
def MFnCamera_setAspectRatio(*args, **kwargs): pass
def MMessageNode_swigregister(*args, **kwargs): pass
def MItSelectionList_getStrings(*args, **kwargs): pass
def MFnLight_intensity(*args, **kwargs): pass
def MUuid___eq__(*args, **kwargs): pass
def MDAGDrawOverrideInfo_fEnableTexturing_get(*args, **kwargs): pass
def MAngle_asUnits(*args, **kwargs): pass
def MIntArray_copy(*args, **kwargs): pass
def MFloatVector_normal(*args, **kwargs): pass
def MFnMessageAttribute_create(*args, **kwargs): pass
def MFnCamera_isClippingPlanes(*args, **kwargs): pass
def MSelectionList_isEmpty(*args, **kwargs): pass
def MMessageNode_fClientPtr_set(*args, **kwargs): pass
def MItMeshVertex_connectedToFace(*args, **kwargs): pass
def MFnSubdData_swigregister(*args, **kwargs): pass
def MFloatVector_assign(*args, **kwargs): pass
def MFnMesh_intersectFaceAtUV(*args, **kwargs): pass
def MAttributeSpecArray_swigregister(*args, **kwargs): pass
def MFnContainerNode_getPublishedNames(*args, **kwargs): pass
def delete_MUserData(*args, **kwargs): pass
def MPlug_asMDistance(*args, **kwargs): pass
def MObject_hasFn(*args, **kwargs): pass
def MImage_release(*args, **kwargs): pass
def MFnMesh_setCheckSamePointTwice(*args, **kwargs): pass
def MFnCamera_filmTranslateH(*args, **kwargs): pass
def MFloatArray_setLength(*args, **kwargs): pass
def MItSubdFace_setLevel(*args, **kwargs): pass
def MItDag_fullPathName(*args, **kwargs): pass
def MItMeshVertex_getNormal(*args, **kwargs): pass
def MFnStringArrayData_array(*args, **kwargs): pass
def MFnMesh_booleanOp(*args, **kwargs): pass
def MFnTransform_setRestPosition(*args, **kwargs): pass
def MURI_getHost(*args, **kwargs): pass
def MDGModifier_swigregister(*args, **kwargs): pass
def MPlug_assign(*args, **kwargs): pass
def MCallbackIdArray_remove(*args, **kwargs): pass
def MImage_pixelType(*args, **kwargs): pass
def MFnReference_containsNode(*args, **kwargs): pass
def MFileIO_exportAnimFromReference(*args, **kwargs): pass
def MFnSet_getIntersection(*args, **kwargs): pass
def MFnCamera_setFilmFitOffset(*args, **kwargs): pass
def MScriptUtil_asIntPtr(*args, **kwargs): pass
def MFileObject_ithFullName(*args, **kwargs): pass
def MConnectDisconnectAttrEdit_editType(*args, **kwargs): pass
def MColorArray_append(*args, **kwargs): pass
def MItMeshPolygon_isHoled(*args, **kwargs): pass
def MFnSpotLight_setBarnDoors(*args, **kwargs): pass
def MFnMesh_collapseFaces(*args, **kwargs): pass
def MFnTransform_setScalePivotTranslation(*args, **kwargs): pass
def MStreamUtils_swigregister(*args, **kwargs): pass
def MPlug_isFreeToChange(*args, **kwargs): pass
def MImageFileInfo_width(*args, **kwargs): pass
def MFnTransform_setRotatePivot(*args, **kwargs): pass
def MFnMesh_getColor(*args, **kwargs): pass
def MTransformationMatrix_getScale(*args, **kwargs): pass
def MFileObject_setRawName(*args, **kwargs): pass
def MFnDependencyNode_setExternalContentForFileAttr(*args, **kwargs): pass
def MEdit_className(*args, **kwargs): pass
def MCallbackIdArray_insert(*args, **kwargs): pass
def MItMeshPolygon_getEdges(*args, **kwargs): pass
def MDGModifier_newPlugValueMAngle(*args, **kwargs): pass
def new_MFnSphereData(*args, **kwargs): pass
def MFnMesh_className(*args, **kwargs): pass
def MFnAssembly_swigregister(*args, **kwargs): pass
def MUintArray___radd__(*args, **kwargs): pass
def MDGModifier_createNode(*args, **kwargs): pass
def MIffFile_isActive(*args, **kwargs): pass
def MFnMesh_setFaceColor(*args, **kwargs): pass
def delete_MSyntax(*args, **kwargs): pass
def MFnCamera_getAspectRatioLimits(*args, **kwargs): pass
def MFileIO_loadReference(*args, **kwargs): pass
def MRenderPassDef_addIntParameter(*args, **kwargs): pass
def MCacheFormatDescription_getChannelInterpretation(*args, **kwargs): pass
def MItMeshPolygon_getAxisAtUV(*args, **kwargs): pass
def MFnSingleIndexedComponent_type(*args, **kwargs): pass
def MFnMatrixData_className(*args, **kwargs): pass
def MUintArray_length(*args, **kwargs): pass
def MFnSet_addMembers(*args, **kwargs): pass
def MMeshSmoothOptions_keepHardEdge(*args, **kwargs): pass
def MPlug_logicalIndex(*args, **kwargs): pass
def MFnMesh_assignUV(*args, **kwargs): pass
def MFnCamera_set(*args, **kwargs): pass
def MFileIO_mustRenameToSaveMsg(*args, **kwargs): pass
def MRampAttribute_createColorRamp(*args, **kwargs): pass
def MBoundingBox_swigregister(*args, **kwargs): pass
def MItMeshPolygon_setIndex(*args, **kwargs): pass
def MFnCamera_shakeEnabled(*args, **kwargs): pass
def new_MFnSet(*args, **kwargs): pass
def new_MFnMatrixArrayData(*args, **kwargs): pass
def MFnDagNode_objectGroupComponent(*args, **kwargs): pass
def MUint64Array___len__(*args, **kwargs): pass
def floatPtr_frompointer(*args, **kwargs): pass
def MPlugArray_className(*args, **kwargs): pass
def MGlobal_setZAxisUp(*args, **kwargs): pass
def MFnMesh_getUVSetsInFamily(*args, **kwargs): pass
def MDGModifier_newPlugValueString(*args, **kwargs): pass
def MFnReference_nodes(*args, **kwargs): pass
def MFileIO_exportAnim(*args, **kwargs): pass
def MRampAttribute_assign(*args, **kwargs): pass
def MAttributePatternArray_sizeIncrement(*args, **kwargs): pass
def MItMeshFaceVertex_getColorIndex(*args, **kwargs): pass
def MFnPointArrayData_className(*args, **kwargs): pass
def MFnLayeredShader_hardwareColor(*args, **kwargs): pass
def MFnDagNode_setObjectColorType(*args, **kwargs): pass
def MItDag_swigregister(*args, **kwargs): pass
def new_MObjectSetMessage(*args, **kwargs): pass
def MGlobal_clearSelectionList(*args, **kwargs): pass
def MFnMesh_cleanupEdgeSmoothing(*args, **kwargs): pass
def MItSubdVertex_reset(*args, **kwargs): pass
def MEvaluationNodeIterator_swigregister(*args, **kwargs): pass
def MQuaternion_conjugate(*args, **kwargs): pass
def MTimeArray_assign(*args, **kwargs): pass
def new_array4dDouble(*args, **kwargs): pass
def MItMeshFaceVertex_vertId(*args, **kwargs): pass
def MFnSet_intersectsWith(*args, **kwargs): pass
def new_MFnLatticeData(*args, **kwargs): pass
def MFnDagNode_isInstanceable(*args, **kwargs): pass
def MObjectArray_sizeIncrement(*args, **kwargs): pass
def MGlobal_selectCommand(*args, **kwargs): pass
def MFnMesh_lockVertexNormals(*args, **kwargs): pass
def delete_MFnReflectShader(*args, **kwargs): pass
def MSyntax_useSelectionAsDefault(*args, **kwargs): pass
def new_MNodeClass(*args, **kwargs): pass
def MEvaluationNode_child(*args, **kwargs): pass
def MQuaternion_setToXAxis(*args, **kwargs): pass
def delete_array4dFloat(*args, **kwargs): pass
def MItMeshEdge_geomChanged(*args, **kwargs): pass
def MFnPartition_removeMember(*args, **kwargs): pass
def MFnGeometryData_copyObjectGroups(*args, **kwargs): pass
def new_MFnDagNode(*args, **kwargs): pass
def MSetAttrEdit_plug(*args, **kwargs): pass
def MTransformationMatrix_rotatePivotTranslation(*args, **kwargs): pass
def MPointOnNurbs_getPoint(*args, **kwargs): pass
def MFnBase_type(*args, **kwargs): pass
def MFnMesh_getPolygonTriangleVertices(*args, **kwargs): pass
def MFnLambertShader_setDiffuseCoeff(*args, **kwargs): pass
def MQuaternion_normal(*args, **kwargs): pass
def MEulerRotation_swigregister(*args, **kwargs): pass
def MScriptUtil_setDouble3ArrayItem(*args, **kwargs): pass
def MItInstancer_swigregister(*args, **kwargs): pass
def MFnNurbsSurface_getPatchUVs(*args, **kwargs): pass
def MAttributePattern_assign(*args, **kwargs): pass
def MFnGeometryData_className(*args, **kwargs): pass
def MFnDependencyNode_setExternalContent(*args, **kwargs): pass
def MTransformationMatrix_rotationOrder(*args, **kwargs): pass
def MNodeMessage_addKeyableChangeOverride(*args, **kwargs): pass
def new_MFnVolumeLight(*args, **kwargs): pass
def MItMeshFaceVertex_faceVertId(*args, **kwargs): pass
def delete_MURI(*args, **kwargs): pass
def MItDependencyGraph_rootNode(*args, **kwargs): pass
def MEulerRotation_bound(*args, **kwargs): pass
def MScriptUtil_getInt4ArrayItem(*args, **kwargs): pass
def uIntPtr_frompointer(*args, **kwargs): pass
def MItGeometry_className(*args, **kwargs): pass
def MFnNurbsSurface_boundaryType(*args, **kwargs): pass
def MFnFloatArrayData_array(*args, **kwargs): pass
def MFnDependencyNode_deallocateAllFlags(*args, **kwargs): pass
def MNodeClass_removeExtensionAttributeIfUnset(*args, **kwargs): pass
def MFnSet_swigregister(*args, **kwargs): pass
def MFnUnitAttribute_setSoftMax(*args, **kwargs): pass
def MFnAttribute_setRenderSource(*args, **kwargs): pass
def MDataHandle_setGenericChar(*args, **kwargs): pass
def MEulerRotation___add__(*args, **kwargs): pass
def MScriptUtil_getShortArrayItem(*args, **kwargs): pass
def MAttributePattern_name(*args, **kwargs): pass
def new_MItGeometry(*args, **kwargs): pass
def MFnNurbsSurface_normal(*args, **kwargs): pass
def MFnBase_className(*args, **kwargs): pass
def MFnExpression_setExpression(*args, **kwargs): pass
def MFnDependencyNode_attribute(*args, **kwargs): pass
def MNamespace_setRelativeNames(*args, **kwargs): pass
def MFnMesh_getPolygonNormal(*args, **kwargs): pass
def MFnUnitAttribute_type(*args, **kwargs): pass
def MFnAttribute_affectsAppearance(*args, **kwargs): pass
def MDataHandle_set2Double(*args, **kwargs): pass
def MAttributePattern_attrPatternCount(*args, **kwargs): pass
def MScriptUtil_getShort(*args, **kwargs): pass
def delete_MAttributeSpec(*args, **kwargs): pass
def MItEdits_addRemoveAttrEdit(*args, **kwargs): pass
def MFnNurbsSurface_numNonZeroSpansInV(*args, **kwargs): pass
def MFnEnumAttribute_create(*args, **kwargs): pass
def MFnDependencyNode_type(*args, **kwargs): pass
def MTime___eq__(*args, **kwargs): pass
def MFnPointArrayData_copyTo(*args, **kwargs): pass
def MMeshSmoothOptions_setSmoothUVs(*args, **kwargs): pass
def new_MModelMessage(*args, **kwargs): pass
def MItDependencyGraph_resetFilter(*args, **kwargs): pass
def new_MDoubleArray(*args, **kwargs): pass
def MScriptUtil_asFloat3Ptr(*args, **kwargs): pass
def MItDependencyNodes_reset(*args, **kwargs): pass
def MFnNurbsSurface_getCVs(*args, **kwargs): pass
def MFnDoubleArrayData_swigregister(*args, **kwargs): pass
def MSyntax_canQuery(*args, **kwargs): pass
def MFloatVector_angle(*args, **kwargs): pass
def MTimeArray_clear(*args, **kwargs): pass
def MMeshIntersector_getClosestPoint(*args, **kwargs): pass
def MMatrixArray_setLength(*args, **kwargs): pass
def MFnTripleIndexedComponent_getCompleteData(*args, **kwargs): pass
def MFnArrayAttrsData_checkArrayExist(*args, **kwargs): pass
def MFnMesh_getFaceUVSetNames(*args, **kwargs): pass
def MDataHandle_asDouble4(*args, **kwargs): pass
def MDistance_asUnits(*args, **kwargs): pass
def MScriptUtil_asBool(*args, **kwargs): pass
def MFnCamera_setRenderPanZoom(*args, **kwargs): pass
def MItDependencyGraph_toggleLevel(*args, **kwargs): pass
def MFnNurbsCurve_swigregister(*args, **kwargs): pass
def MFnCameraSet_isLayerActive(*args, **kwargs): pass
def delete_MComputation(*args, **kwargs): pass
def MFloatVector___getitem__(*args, **kwargs): pass
def MTesselationParams_setBoundingBoxDiagonal(*args, **kwargs): pass
def MMatrix___ne__(*args, **kwargs): pass
def MFnSubdNames_parentFaceId(*args, **kwargs): pass
def MDagModifier_createNode(*args, **kwargs): pass
def delete_MFnAreaLight(*args, **kwargs): pass
def MDataHandle_asInt64(*args, **kwargs): pass
def new_MCameraSetMessage(*args, **kwargs): pass
def MPolyMessage_addColorSetChangedCallback(*args, **kwargs): pass
def MArrayDataHandle_elementCount(*args, **kwargs): pass
def MItDependencyGraph_currentFilter(*args, **kwargs): pass
def MFileIO_beforeExportFilename(*args, **kwargs): pass
def MFnNurbsCurve_getPointAtParam(*args, **kwargs): pass
def MFnCamera_setFarClippingPlane(*args, **kwargs): pass
def MPlug_name(*args, **kwargs): pass
def MFloatVectorArray_set(*args, **kwargs): pass
def MTesselationParams_setSubdivisionFlag(*args, **kwargs): pass
def MCurveAttribute_sort(*args, **kwargs): pass
def MFnSubdNames_base(*args, **kwargs): pass
def MFnNonExtendedLight_setCastSoftShadows(*args, **kwargs): pass
def MWeight_swigregister(*args, **kwargs): pass
def new_MDGContextGuard(*args, **kwargs): pass
def MProfiler_resetRecording(*args, **kwargs): pass
def MFnSingleIndexedComponent_elementMax(*args, **kwargs): pass
def MArrayDataBuilder_addElement(*args, **kwargs): pass
def MItDag_getPath(*args, **kwargs): pass
def MFnNurbsCurve_getCV(*args, **kwargs): pass
def new_MFnCompoundAttribute(*args, **kwargs): pass
def MFloatPoint_distanceTo(*args, **kwargs): pass
def MSyntax_enableQuery(*args, **kwargs): pass
def new_MContainerMessage(*args, **kwargs): pass
def MItSurfaceCV_setPosition(*args, **kwargs): pass
def MFnGenericAttribute_type(*args, **kwargs): pass
def MFnSubd_polygonGetVertexUVs(*args, **kwargs): pass
def MFnSingleIndexedComponent_element(*args, **kwargs): pass
def MFnAnisotropyShader_anisotropicReflectivity(*args, **kwargs): pass
def MVector_isParallel(*args, **kwargs): pass
def MDataBlock_context(*args, **kwargs): pass
def MProfiler_eventBegin(*args, **kwargs): pass
def MArgList_asDouble(*args, **kwargs): pass
def MItCurveCV_index(*args, **kwargs): pass
def MFnNumericData_swigregister(*args, **kwargs): pass
def MFnComponent_setWeights(*args, **kwargs): pass
def new_MDagPathArray(*args, **kwargs): pass
def MStreamUtils_readInt(*args, **kwargs): pass
def MComputation_progressMin(*args, **kwargs): pass
def MItSubdVertex_isDone(*args, **kwargs): pass
def MFnSubd_edgeIsValid(*args, **kwargs): pass
def new_MFnAnisotropyShader(*args, **kwargs): pass
def MVector___iadd__(*args, **kwargs): pass
def MFnAssembly_deleteRepresentation(*args, **kwargs): pass
def MDagPath_isInstanced(*args, **kwargs): pass
def MPoint_x_get(*args, **kwargs): pass
def MArgParser_commandArgumentMAngle(*args, **kwargs): pass
def MInt64Array___getitem__(*args, **kwargs): pass
def MFnNumericData_getData2Int(*args, **kwargs): pass
def MFnCamera_usePivotAsLocalSpace(*args, **kwargs): pass
def MFloatPointArray___getitem__(*args, **kwargs): pass
def MParentingEdit_className(*args, **kwargs): pass
def MCommandMessage_addProcCallback(*args, **kwargs): pass
def MItSubdEdge_setSharpness(*args, **kwargs): pass
def MFnSubd_vertexIncidentEdges(*args, **kwargs): pass
def MItDependencyGraph_currentTraversal(*args, **kwargs): pass
def MFnLight_lightSpecular(*args, **kwargs): pass
def MVectorArray_append(*args, **kwargs): pass
def MDagPath_extendToShapeDirectlyBelow(*args, **kwargs): pass
def MPoint___call__(*args, **kwargs): pass
def MArgParser_numberOfFlagsUsed(*args, **kwargs): pass
def delete_MInt64Array(*args, **kwargs): pass
def MFnNumericAttribute_getSoftMin(*args, **kwargs): pass
def MFnDependencyNode_enableDGTiming(*args, **kwargs): pass
def MFloatMatrix___sub__(*args, **kwargs): pass
def new_MSelectionMask(*args, **kwargs): pass
def MFnSingleIndexedComponent_getCompleteData(*args, **kwargs): pass
def MMessage_removeCallback(*args, **kwargs): pass
def MItSelectionList_itemType(*args, **kwargs): pass
def MFnSubd_vertexIdFromBaseVertexIndex(*args, **kwargs): pass
def MArgParser_commandArgumentMTime(*args, **kwargs): pass
def MFnLight_setIntensity(*args, **kwargs): pass
def MUuid___ne__(*args, **kwargs): pass
def MDAGDrawOverrideInfo_fEnableVisible_set(*args, **kwargs): pass
def MPointArray_set(*args, **kwargs): pass
def MAngle_asRadians(*args, **kwargs): pass
def MIntArray_clear(*args, **kwargs): pass
def MFnDependencyNode_setName(*args, **kwargs): pass
def MFnMessageAttribute_swigregister(*args, **kwargs): pass
def MFnCamera_setNearClippingPlane(*args, **kwargs): pass
def MFloatArray___add__(*args, **kwargs): pass
def MItDependencyGraph_previousPlug(*args, **kwargs): pass
def MMessageNode_fClientPtr_get(*args, **kwargs): pass
def MItMeshVertex_connectedToEdge(*args, **kwargs): pass
def MFnSubd_type(*args, **kwargs): pass
def MEventMessage_className(*args, **kwargs): pass
def MDagMessage_addWorldMatrixModifiedCallback(*args, **kwargs): pass
def MTesselationParams_setStdFractionalTolerance(*args, **kwargs): pass
def MFnContainerNode_getMembers(*args, **kwargs): pass
def MUserData_deleteAfterUse(*args, **kwargs): pass
def MDagPathArray_copy(*args, **kwargs): pass
def MPlug_asMAngle(*args, **kwargs): pass
def MObject_isNull(*args, **kwargs): pass
def MImage_verticalFlip(*args, **kwargs): pass
def MFnMesh_getCheckSamePointTwice(*args, **kwargs): pass
def MFnCamera_setFilmTranslateV(*args, **kwargs): pass
def MFloatArray_length(*args, **kwargs): pass
def MRichSelection_swigregister(*args, **kwargs): pass
def MItDependencyGraph_setTraversalOverWorldSpaceDependents(*args, **kwargs): pass
def MColor___add__(*args, **kwargs): pass
def MItMeshVertex_getNormals(*args, **kwargs): pass
def MFnStringArrayData_create(*args, **kwargs): pass
def MEulerRotation_reorder(*args, **kwargs): pass
def MFnMesh_booleanOps(*args, **kwargs): pass
def MFnTransform_resetFromRestPosition(*args, **kwargs): pass
def MURI_getPort(*args, **kwargs): pass
def new_MDagModifier(*args, **kwargs): pass
def MPlug___getitem__(*args, **kwargs): pass
def MDataHandle_asNurbsCurve(*args, **kwargs): pass
def MImage_pixels(*args, **kwargs): pass
def MFnSphereData_className(*args, **kwargs): pass
def MFnMesh_getFloatBlindData(*args, **kwargs): pass
def MFnCamera_filmFitOffset(*args, **kwargs): pass
def MRampAttribute_deleteEntries(*args, **kwargs): pass
def MFileObject_exists(*args, **kwargs): pass
def MConnectDisconnectAttrEdit_className(*args, **kwargs): pass
def MColorArray_copy(*args, **kwargs): pass
def MItMeshPolygon_isPlanar(*args, **kwargs): pass
def MFnDagNode_usingHiliteColor(*args, **kwargs): pass
def MFnSpotLight_barnDoorAngle(*args, **kwargs): pass
def MFnMesh_collapseEdges(*args, **kwargs): pass
def MFnDependencyNode_attributeCount(*args, **kwargs): pass
def MURI_setUserName(*args, **kwargs): pass
def MDGModifier_newPlugValueInt(*args, **kwargs): pass
def MImageFileInfo_height(*args, **kwargs): pass
def new_MFnData(*args, **kwargs): pass
def MFnMesh_assignColor(*args, **kwargs): pass
def MFnCamera_setPanZoomEnabled(*args, **kwargs): pass
def MDagPath_pop(*args, **kwargs): pass
def MFileObject_setRawPath(*args, **kwargs): pass
def MEdit_swigregister(*args, **kwargs): pass
def MCallbackIdArray_append(*args, **kwargs): pass
def MTesselationParams_setChordHeightRatio(*args, **kwargs): pass
def MFnCamera_setStereoHITEnabled(*args, **kwargs): pass
def MFnSphereData_create(*args, **kwargs): pass
def new_MFnMesh(*args, **kwargs): pass
def MFnTransform_type(*args, **kwargs): pass
def MUintArray___iadd__(*args, **kwargs): pass
def MDGModifier_deleteNode(*args, **kwargs): pass
def MPlug_sourceWithConversion(*args, **kwargs): pass
def MIffFile_beginReadGroup(*args, **kwargs): pass
def MFnMesh_setVertexColor(*args, **kwargs): pass
def MDagPathArray_append(*args, **kwargs): pass
def MFnCamera_setVerticalLock(*args, **kwargs): pass
def MFileIO_loadReferenceByNode(*args, **kwargs): pass
def MRenderPassDef_className(*args, **kwargs): pass
def MCacheFormatDescription_getChannelDataType(*args, **kwargs): pass
def MItMeshPolygon_getUVAtPoint(*args, **kwargs): pass
def delete_MFnSingleIndexedComponent(*args, **kwargs): pass
def new_MFnMatrixData(*args, **kwargs): pass
def MScriptUtil_asUint4Ptr(*args, **kwargs): pass
def MFnAssembly_getRepLabel(*args, **kwargs): pass
def MUintArray_remove(*args, **kwargs): pass
def MFnSphereData_setRadius(*args, **kwargs): pass
def MMeshSmoothOptions_setBoundaryRule(*args, **kwargs): pass
def MPlug_selectAncestorLogicalIndex(*args, **kwargs): pass
def MFnMesh_getCreaseVertices(*args, **kwargs): pass
def MGlobal_setErrorLogPathName(*args, **kwargs): pass
def MFnMesh_assignUVs(*args, **kwargs): pass
def MFnCamera_setEyePoint(*args, **kwargs): pass
def MFileIO_setMustRenameToSaveMsg(*args, **kwargs): pass
def MRampAttribute_createRamp(*args, **kwargs): pass
def MFnNurbsCurve_closestPoint(*args, **kwargs): pass
def MCacheConfigRuleRegistry_registerFilter(*args, **kwargs): pass
def MItMeshPolygon_vertexIndex(*args, **kwargs): pass
def MFnCamera_overscan(*args, **kwargs): pass
def MFnSet_create(*args, **kwargs): pass
def MFnMatrixArrayData_length(*args, **kwargs): pass
def MFnDagNode_swigregister(*args, **kwargs): pass
def floatPtr_swigregister(*args, **kwargs): pass
def MPlugArray_swigregister(*args, **kwargs): pass
def MGlobal_isYAxisUp(*args, **kwargs): pass
def MDagPathArray_setSizeIncrement(*args, **kwargs): pass
def MFnReference_isLoaded(*args, **kwargs): pass
def MFileIO_exportSelectedAnim(*args, **kwargs): pass
def delete_MRampAttribute(*args, **kwargs): pass
def MAttributePatternArray_className(*args, **kwargs): pass
def MItMeshFaceVertex_updateSurface(*args, **kwargs): pass
def new_MFnPointArrayData(*args, **kwargs): pass
def MFnLayeredShader_setHardwareColor(*args, **kwargs): pass
def MFnDagNode_setObjectColor(*args, **kwargs): pass
def MTypeId_swigregister(*args, **kwargs): pass
def MPlug_numConnectedChildren(*args, **kwargs): pass
def intPtr_value(*args, **kwargs): pass
def delete_MObjectSetMessage(*args, **kwargs): pass
def MGlobal_isSelected(*args, **kwargs): pass
def MFnMesh_getCreaseEdges(*args, **kwargs): pass
def MFnBlinnShader_setEccentricity(*args, **kwargs): pass
def new_MFileIO(*args, **kwargs): pass
def MItMeshFaceVertex_currentItem(*args, **kwargs): pass
def MQuaternion_conjugateIt(*args, **kwargs): pass
def MItSubdVertex_className(*args, **kwargs): pass
def delete_array4dDouble(*args, **kwargs): pass
def MItMeshFaceVertex_faceId(*args, **kwargs): pass
def MFnSpotLight_className(*args, **kwargs): pass
def new_MFnPhongShader(*args, **kwargs): pass
def MFnLatticeData_create(*args, **kwargs): pass
def MFnDagNode_setInstanceable(*args, **kwargs): pass
def MTrimBoundaryArray___getitem__(*args, **kwargs): pass
def MGlobal_selectByName(*args, **kwargs): pass
def MFnMesh_lockFaceVertexNormals(*args, **kwargs): pass
def new_MFnNonExtendedLight(*args, **kwargs): pass
def MFnCamera_verticalRollPivot(*args, **kwargs): pass
def MPlug_info(*args, **kwargs): pass
def MEvaluationNode_iterator(*args, **kwargs): pass
def MQuaternion_setToYAxis(*args, **kwargs): pass
def array4dFloat_get(*args, **kwargs): pass
def MItMeshEdge_setIndex(*args, **kwargs): pass
def MFnPartition_swigregister(*args, **kwargs): pass
def MFnGeometryData_swigregister(*args, **kwargs): pass
def MFnUnitAttribute_hasMax(*args, **kwargs): pass
def MFnDagNode_create(*args, **kwargs): pass
def new_MDAGDrawOverrideInfo(*args, **kwargs): pass
def MGlobal_mayaVersion(*args, **kwargs): pass
def MFnMesh_setPoint(*args, **kwargs): pass
def MFnLambertShader_color(*args, **kwargs): pass
def delete_MSelectionMask(*args, **kwargs): pass
def MEventMessage_addEventCallback(*args, **kwargs): pass
def MScriptUtil_getDouble4ArrayItem(*args, **kwargs): pass
def new_MItMeshEdge(*args, **kwargs): pass
def MFnNurbsSurface_getPatchUVid(*args, **kwargs): pass
def MTesselationParams_setEdgeSmoothFactor(*args, **kwargs): pass
def MFnDependencyNode_affectsAnimation(*args, **kwargs): pass
def MTransformationMatrix_reorderRotation(*args, **kwargs): pass
def MNodeMessage_className(*args, **kwargs): pass
def MFnVolumeLight_create(*args, **kwargs): pass
def MFnSubd_getCubicSpline(*args, **kwargs): pass
def MDataHandle_copy(*args, **kwargs): pass
def MFnAttribute_removeFromCategory(*args, **kwargs): pass
def MItDependencyGraph_getNodePath(*args, **kwargs): pass
def MEulerRotation_boundIt(*args, **kwargs): pass
def uIntPtr_swigregister(*args, **kwargs): pass
def MItGeometry_swigregister(*args, **kwargs): pass
def MFnNurbsSurface_numEdges(*args, **kwargs): pass
def MFnFloatArrayData_create(*args, **kwargs): pass
def MFnDependencyNode_setFlag(*args, **kwargs): pass
def delete_MTransformationMatrix(*args, **kwargs): pass
def MNodeClass_getAttributes(*args, **kwargs): pass
def MFnSpotLight_penumbraAngle(*args, **kwargs): pass
def MFnUnitAttribute_getDefault(*args, **kwargs): pass
def MFnAttribute_setWorldSpace(*args, **kwargs): pass
def MDataHandle_setGenericDouble(*args, **kwargs): pass
def MEulerRotation___iadd__(*args, **kwargs): pass
def MScriptUtil_getFloatArrayItem(*args, **kwargs): pass
def MAttributePattern_rootAttrCount(*args, **kwargs): pass
def delete_MItGeometry(*args, **kwargs): pass
def MFnNurbsCurve_getKnotDomain(*args, **kwargs): pass
def MFnDependencyNode_isLocked(*args, **kwargs): pass
def MFnExpression_getDefaultObject(*args, **kwargs): pass
def MFnDependencyNode_attributeClass(*args, **kwargs): pass
def new_MTimer(*args, **kwargs): pass
def MNamespace_getNamespaceFromName(*args, **kwargs): pass
def delete_MFnUnitAttribute(*args, **kwargs): pass
def MFnAttribute_isProxyAttribute(*args, **kwargs): pass
def MDataHandle_set3Short(*args, **kwargs): pass
def MTesselationParams_setUNumber(*args, **kwargs): pass
def MDoubleArray___delitem__(*args, **kwargs): pass
def MScriptUtil_getFloat(*args, **kwargs): pass
def MAttributeSpec_name(*args, **kwargs): pass
def MItEdits_setAttrEdit(*args, **kwargs): pass
def MFnNurbsSurface_numCVsInU(*args, **kwargs): pass
def MFnEnumAttribute_addField(*args, **kwargs): pass
def delete_MFnDependencyNode(*args, **kwargs): pass
def MTime___ne__(*args, **kwargs): pass
def MFnCamera_getViewParameters(*args, **kwargs): pass
def MMeshSmoothOptions_smoothUVs(*args, **kwargs): pass
def delete_MModelMessage(*args, **kwargs): pass
def array3dInt_set(*args, **kwargs): pass
def MFnUInt64ArrayData_set(*args, **kwargs): pass
def MFnAttribute_isConnectable(*args, **kwargs): pass
def MDataHandle_setChar(*args, **kwargs): pass
def delete_MItSelectionList(*args, **kwargs): pass
def MScriptUtil_asFloat4Ptr(*args, **kwargs): pass
def MGlobal_swigregister(*args, **kwargs): pass
def delete_MAttributeSpecArray(*args, **kwargs): pass
def MItDependencyNodes_thisNode(*args, **kwargs): pass
def MFnNurbsSurface_setCVs(*args, **kwargs): pass
def MFnSpotLight_barnDoors(*args, **kwargs): pass
def MFloatVector_isEquivalent(*args, **kwargs): pass
def MTimeArray_setSizeIncrement(*args, **kwargs): pass
def MItEdits_removeCurrentEdit(*args, **kwargs): pass
def MMeshIntersector_className(*args, **kwargs): pass
def MMatrixArray_length(*args, **kwargs): pass
def MFnTripleIndexedComponent_swigregister(*args, **kwargs): pass
def MFnCameraSet_appendLayer(*args, **kwargs): pass
def MDataHandle_asVector(*args, **kwargs): pass
def MDistance_asInches(*args, **kwargs): pass
def MFnDependencyNode_allocateFlag(*args, **kwargs): pass
def MAttributeIndex_hasValidRange(*args, **kwargs): pass
def MItDependencyGraph_next(*args, **kwargs): pass
def MFnNurbsSurfaceData_type(*args, **kwargs): pass
def MFnCameraSet_setLayerOrder(*args, **kwargs): pass
def MFloatVector___xor__(*args, **kwargs): pass
def MTesselationParams_setUDistanceFraction(*args, **kwargs): pass
def MDagMessage_addDagDagPathCallback(*args, **kwargs): pass
def MMatrix_inverse(*args, **kwargs): pass
def MFnSubdNames_nonBaseFaceVertices(*args, **kwargs): pass
def MDAGDrawOverrideInfo_fEnableTexturing_set(*args, **kwargs): pass
def MVector_swigregister(*args, **kwargs): pass
def MFnAreaLight_className(*args, **kwargs): pass
def MDataHandle_asAddr(*args, **kwargs): pass
def delete_MCameraSetMessage(*args, **kwargs): pass
def MPolyMessage_deletedId(*args, **kwargs): pass
def MArrayDataHandle_elementIndex(*args, **kwargs): pass
def MItDependencyGraph_setCurrentFilter(*args, **kwargs): pass
def MFloatPoint___isub__(*args, **kwargs): pass
def MFnNurbsCurve_getParamAtPoint(*args, **kwargs): pass
def MFnData_className(*args, **kwargs): pass
def MFnDirectionalLight_swigregister(*args, **kwargs): pass
def MPlug_isKeyable(*args, **kwargs): pass
def MFloatVectorArray_setLength(*args, **kwargs): pass
def MTesselationParams_setFitTolerance(*args, **kwargs): pass
def MCurveAttribute_pack(*args, **kwargs): pass
def new_MMatrix(*args, **kwargs): pass
def MFnSubdNames_first(*args, **kwargs): pass
def MFnNonExtendedLight_useDepthMapShadows(*args, **kwargs): pass
def MDataHandle_isNumeric(*args, **kwargs): pass
def MDGContextGuard_swigregister(*args, **kwargs): pass
def MProfiler_setRecordingActive(*args, **kwargs): pass
def MFnSpotLight_useDecayRegions(*args, **kwargs): pass
def MArrayDataBuilder_addLastArray(*args, **kwargs): pass
def MItDag_getAllPaths(*args, **kwargs): pass
def MFnNurbsCurve_setCV(*args, **kwargs): pass
def MFnCompoundAttribute_create(*args, **kwargs): pass
def MUserData_setDeleteAfterUse(*args, **kwargs): pass
def MFloatPoint_isEquivalent(*args, **kwargs): pass
def MSyntax_enableEdit(*args, **kwargs): pass
def MItSurfaceCV_translateBy(*args, **kwargs): pass
def MFloatVector___sub__(*args, **kwargs): pass
def array4dInt_set(*args, **kwargs): pass
def MFnAnisotropyShader_setAnisotropicReflectivity(*args, **kwargs): pass
def MVector_transformAsNormal(*args, **kwargs): pass
def MDataBlock_setContext(*args, **kwargs): pass
def MProfiler_eventEnd(*args, **kwargs): pass
def MArgList_asString(*args, **kwargs): pass
def MFnGeometryData_matrixIsNotIdentity(*args, **kwargs): pass
def MFnNurbsCurveData_type(*args, **kwargs): pass
def MFnComponent_swigregister(*args, **kwargs): pass
def MDAGDrawOverrideInfo_fPlaybackVisible_set(*args, **kwargs): pass
def MFloatPoint_setCast(*args, **kwargs): pass
def MStreamUtils_readFloat(*args, **kwargs): pass
def MComputation_progressMax(*args, **kwargs): pass
def MItSubdVertex_next(*args, **kwargs): pass
def MFnSubd_edgeIsCreased(*args, **kwargs): pass
def MVector___neg__(*args, **kwargs): pass
def MDistance_asKilometers(*args, **kwargs): pass
def MDagPath_instanceNumber(*args, **kwargs): pass
def MPoint_y_set(*args, **kwargs): pass
def MPlug_isChannelBoxFlagSet(*args, **kwargs): pass
def MInt64Array___delitem__(*args, **kwargs): pass
def MFnNumericData_getData2Float(*args, **kwargs): pass
def MFnCamera_postProjectionMatrix(*args, **kwargs): pass
def MFloatPointArray_assign(*args, **kwargs): pass
def MParentingEdit_swigregister(*args, **kwargs): pass
def new_MCommandMessage(*args, **kwargs): pass
def MItSubdEdge_isBoundary(*args, **kwargs): pass
def MFnSubd_vertexIncidentPolygons(*args, **kwargs): pass
def MFnSpotLight_endDistance(*args, **kwargs): pass
def MFnLight_swigregister(*args, **kwargs): pass
def MVectorArray_copy(*args, **kwargs): pass
def MDagPath_numberOfShapesDirectlyBelow(*args, **kwargs): pass
def MPoint_assign(*args, **kwargs): pass
def MFnStringArrayData___getitem__(*args, **kwargs): pass
def MArgParser_numberOfFlagUses(*args, **kwargs): pass
def MInt64Array_assign(*args, **kwargs): pass
def MFnNumericAttribute_getSoftMax(*args, **kwargs): pass
def array2dDouble_get(*args, **kwargs): pass
def MFnCamera_setShutterAngle(*args, **kwargs): pass
def MFloatMatrix___imul__(*args, **kwargs): pass
def MFnCamera_setHorizontalFieldOfView(*args, **kwargs): pass
def MFnVolumeLight_setVolumeLightDirection(*args, **kwargs): pass
def MItSelectionList_setFilter(*args, **kwargs): pass
def MFnSubd_vertexBaseIndexFromVertexId(*args, **kwargs): pass
def uCharPtr_value(*args, **kwargs): pass
def MFnLight_useRayTraceShadows(*args, **kwargs): pass
def MUuid_get(*args, **kwargs): pass
def MDAGDrawOverrideInfo_fEnableVisible_get(*args, **kwargs): pass
def MPointArray_setLength(*args, **kwargs): pass
def MAngle_asDegrees(*args, **kwargs): pass
def MIntArray_get(*args, **kwargs): pass
def MFnNumericAttribute_type(*args, **kwargs): pass
def MFnCamera_nearClippingPlane(*args, **kwargs): pass
def MFloatArray___radd__(*args, **kwargs): pass
def MSelectionList_getDependNode(*args, **kwargs): pass
def MMessageNode_fServerPtr_set(*args, **kwargs): pass
def MItMeshVertex_getOppositeVertex(*args, **kwargs): pass
def delete_MFnSubd(*args, **kwargs): pass
def MAttributeSpecArray_remove(*args, **kwargs): pass
def MTimeArray_set(*args, **kwargs): pass
def MFnContainerNode_getSubcontainers(*args, **kwargs): pass
def MDagPathArray_clear(*args, **kwargs): pass
def MPlug_asMTime(*args, **kwargs): pass
def MObject_apiType(*args, **kwargs): pass
def MImage_setRGBA(*args, **kwargs): pass
def MFnMesh_createInPlace(*args, **kwargs): pass
def MFnCamera_filmTranslateV(*args, **kwargs): pass
def MFloatArray_remove(*args, **kwargs): pass
def MSceneMessage_addCallback(*args, **kwargs): pass
def MItEdits_isDone(*args, **kwargs): pass
def MColor___neg__(*args, **kwargs): pass
def MItMeshVertex_getNormalIndices(*args, **kwargs): pass
def MFileObject_isSet(*args, **kwargs): pass
def MFnMesh_uniformGridParams(*args, **kwargs): pass
def MFnTransform_clearRestPosition(*args, **kwargs): pass
def MURI_getAllQueryItemKeys(*args, **kwargs): pass
def delete_MDagModifier(*args, **kwargs): pass
def MPlug___eq__(*args, **kwargs): pass
def MProfiler_getCategoryIndex(*args, **kwargs): pass
def MFnStringArrayData_className(*args, **kwargs): pass
def MFnMesh_getDoubleBlindData(*args, **kwargs): pass
def MFnCamera_setOverscan(*args, **kwargs): pass
def MStreamUtils_stdErrorStream(*args, **kwargs): pass
def MConnectDisconnectAttrEdit_swigregister(*args, **kwargs): pass
def MColorArray_clear(*args, **kwargs): pass
def MItMeshPolygon_isUVReversed(*args, **kwargs): pass
def MFnSpotLight_setBarnDoorAngle(*args, **kwargs): pass
def MFnMesh_numVertices(*args, **kwargs): pass
def MFnDependencyNode_plugsAlias(*args, **kwargs): pass
def MFnTransform_setShear(*args, **kwargs): pass
def MURI_setPassword(*args, **kwargs): pass
def MDGModifier_newPlugValueInt64(*args, **kwargs): pass
def MPlug_destructHandle(*args, **kwargs): pass
def MImageFileInfo_channels(*args, **kwargs): pass
def MFnMesh_assignColors(*args, **kwargs): pass
def MFnCamera_renderPanZoom(*args, **kwargs): pass
def MIteratorType_setObjectType(*args, **kwargs): pass
def MFileObject_setRawFullName(*args, **kwargs): pass
def MTimeArray_insert(*args, **kwargs): pass
def MItMeshPolygon_getConnectedEdges(*args, **kwargs): pass
def MFnSphereData_radius(*args, **kwargs): pass
def MQuaternion_getAxisAngle(*args, **kwargs): pass
def MFnMesh_create(*args, **kwargs): pass
def delete_MFnTransform(*args, **kwargs): pass
def MUintArray_className(*args, **kwargs): pass
def MDGModifier_renameNode(*args, **kwargs): pass
def MPlug_destinationsWithConversions(*args, **kwargs): pass
def MIffFile_endReadGroup(*args, **kwargs): pass
def MFnCamera_isVerticalLock(*args, **kwargs): pass
def MFileIO_unloadReference(*args, **kwargs): pass
def MRenderPassDef_swigregister(*args, **kwargs): pass
def MCacheFormatDescription_getChannelSamplingType(*args, **kwargs): pass
def MItMeshPolygon_getUVIndex(*args, **kwargs): pass
def MFnSingleIndexedComponent_className(*args, **kwargs): pass
def MScriptUtil_setUint(*args, **kwargs): pass
def MFnMatrixData_isTransformation(*args, **kwargs): pass
def MFnAssembly_repTypes(*args, **kwargs): pass
def MFnStringArrayData_set(*args, **kwargs): pass
def MMeshSmoothOptions_boundaryRule(*args, **kwargs): pass
def MPlug_getExistingArrayAttributeIndices(*args, **kwargs): pass
def MFnNumericAttribute_swigregister(*args, **kwargs): pass
def MGlobal_errorLogPathName(*args, **kwargs): pass
def MFnMesh_clearUVs(*args, **kwargs): pass
def MFnCamera_setCenterOfInterestPoint(*args, **kwargs): pass
def MFileIO_beforeOpenFilename(*args, **kwargs): pass
def MRampAttribute_className(*args, **kwargs): pass
def MCacheConfigRuleRegistry_unregisterFilter(*args, **kwargs): pass
def MItMeshPolygon_getVertices(*args, **kwargs): pass
def MFnDependencyNode_addExternalContentForFileAttr(*args, **kwargs): pass
def MFnSet_getUnion(*args, **kwargs): pass
def MFnMatrixArrayData_copyTo(*args, **kwargs): pass
def MFnAssembly_type(*args, **kwargs): pass
def new_doublePtr(*args, **kwargs): pass
def MGlobal_isZAxisUp(*args, **kwargs): pass
def MFnSubd_convertToNurbs(*args, **kwargs): pass
def MFnCamera_setNearFarClippingPlanes(*args, **kwargs): pass
def MFnMesh_isUVSetPerInstance(*args, **kwargs): pass
def MDagPath_length(*args, **kwargs): pass
def MFnReference_isLocked(*args, **kwargs): pass
def MFileIO_exportAsReference(*args, **kwargs): pass
def MRampAttribute_getNumEntries(*args, **kwargs): pass
def MAttributePatternArray_swigregister(*args, **kwargs): pass
def MItMeshFaceVertex_geomChanged(*args, **kwargs): pass
def MFnPointArrayData_length(*args, **kwargs): pass
def MCallbackIdArray_copy(*args, **kwargs): pass
def MFnDagNode_objectColorRGB(*args, **kwargs): pass
def new_MUint64Array(*args, **kwargs): pass
def MPlug_setMObject(*args, **kwargs): pass
def MItGeometry_normal(*args, **kwargs): pass
def intPtr_cast(*args, **kwargs): pass
def MObjectSetMessage_swigregister(*args, **kwargs): pass
def MGlobal_trackSelectionOrderEnabled(*args, **kwargs): pass
def MFnMesh_setCreaseEdges(*args, **kwargs): pass
def MFnBlinnShader_specularRollOff(*args, **kwargs): pass
def delete_MFileIO(*args, **kwargs): pass
def MQuaternion_inverse(*args, **kwargs): pass
def MFnNurbsCurve_cvs(*args, **kwargs): pass
def MTimeArray_copy(*args, **kwargs): pass
def MFnPhongShader_create(*args, **kwargs): pass
def MDagPath_getAllPathsTo(*args, **kwargs): pass
def MFnLatticeData_lattice(*args, **kwargs): pass
def MFnDagNode_isInstanced(*args, **kwargs): pass
def MTrimBoundaryArray_get(*args, **kwargs): pass
def MObjectArray_swigregister(*args, **kwargs): pass
def MGlobal_unselectByName(*args, **kwargs): pass
def MFnMesh_unlockVertexNormals(*args, **kwargs): pass
def MTimeArray_className(*args, **kwargs): pass
def new_MFnReflectShader(*args, **kwargs): pass
def MEvaluationNode_dirtyPlugExists(*args, **kwargs): pass
def MQuaternion_setToZAxis(*args, **kwargs): pass
def array4dFloat_set(*args, **kwargs): pass
def MItMeshEdge_getConnectedFaces(*args, **kwargs): pass
def MFloatVectorArray___getitem__(*args, **kwargs): pass
def MFnPhongEShader_type(*args, **kwargs): pass
def MFnIntArrayData_type(*args, **kwargs): pass
def MFnGenericAttribute_removeDataAccept(*args, **kwargs): pass
def delete_MAddRemoveAttrEdit(*args, **kwargs): pass
def MFnDagNode_parentCount(*args, **kwargs): pass
def MTransformationMatrix_isEquivalent(*args, **kwargs): pass
def MDagPath_push(*args, **kwargs): pass
def delete_MPointOnNurbs(*args, **kwargs): pass
def MGlobal_apiVersion(*args, **kwargs): pass
def MFnMesh_getPoint(*args, **kwargs): pass
def MEventMessage_getEventNames(*args, **kwargs): pass
def array4dInt_getptr(*args, **kwargs): pass
def delete_MItMeshEdge(*args, **kwargs): pass
def MFnAttribute_setReadable(*args, **kwargs): pass
def array4dFloat_getptr(*args, **kwargs): pass
def MFnGeometryData_setMatrix(*args, **kwargs): pass
def MFnDependencyNode_setAffectsAnimation(*args, **kwargs): pass
def new_MNodeMessage(*args, **kwargs): pass
def MFnVolumeLight_lightShape(*args, **kwargs): pass
def MFnAttribute_hasCategory(*args, **kwargs): pass
def new_MFnStringData(*args, **kwargs): pass
def MEulerRotation_alternateSolution(*args, **kwargs): pass
def MScriptUtil_getShort2ArrayItem(*args, **kwargs): pass
def new_uCharPtr(*args, **kwargs): pass
def new_MItInstancer(*args, **kwargs): pass
def MFnIntArrayData_create(*args, **kwargs): pass
def MFnNurbsSurface_edge(*args, **kwargs): pass
def MFnFloatArrayData_swigregister(*args, **kwargs): pass
def MFnDependencyNode_isFlagSet(*args, **kwargs): pass
def new_MTransformationMatrix(*args, **kwargs): pass
def MNodeClass_attributeCount(*args, **kwargs): pass
def MFnCamera_isDepthOfField(*args, **kwargs): pass
def MFnAttribute_setAffectsWorldSpace(*args, **kwargs): pass
def MDataHandle_setGenericFloat(*args, **kwargs): pass
def MEulerRotation___sub__(*args, **kwargs): pass
def MScriptUtil_getDoubleArrayItem(*args, **kwargs): pass
def MFnMesh_setFaceVertexColor(*args, **kwargs): pass
def MAttributePattern_rootAttr(*args, **kwargs): pass
def MItGeometry_isDone(*args, **kwargs): pass
def MFnCamera_setNearFocusDistance(*args, **kwargs): pass
def MFnNurbsSurface_getTangents(*args, **kwargs): pass
def MFnDependencyNode_dgTimerReset(*args, **kwargs): pass
def MFnExpression_setDefaultObject(*args, **kwargs): pass
def delete_MTimer(*args, **kwargs): pass
def MNamespace_stripNamespaceFromName(*args, **kwargs): pass
def MFnUnitAttribute_className(*args, **kwargs): pass
def MFnAttribute_disconnectBehavior(*args, **kwargs): pass
def MDataHandle_set3Int(*args, **kwargs): pass
def MTime_setUnit(*args, **kwargs): pass
def MDoubleArray___repr__(*args, **kwargs): pass
def MScriptUtil_getDouble(*args, **kwargs): pass
def MFnSubd_vertexBaseMeshAdd(*args, **kwargs): pass
def MAttributeSpec_dimensions(*args, **kwargs): pass
def MItEdits_parentingEdit(*args, **kwargs): pass
def MFnNurbsSurface_numCVsInV(*args, **kwargs): pass
def MFnEnumAttribute_fieldName(*args, **kwargs): pass
def MFnDependencyNode_className(*args, **kwargs): pass
def MTime___le__(*args, **kwargs): pass
def MFnLight_opticalFXvisibility(*args, **kwargs): pass
def MMeshSmoothOptions_setPropEdgeHardness(*args, **kwargs): pass
def array2dDouble_set(*args, **kwargs): pass
def MFnUInt64ArrayData_array(*args, **kwargs): pass
def MFnAttribute_isStorable(*args, **kwargs): pass
def MDataHandle_setShort(*args, **kwargs): pass
def MDoubleArray_assign(*args, **kwargs): pass
def MItDag_depth(*args, **kwargs): pass
def MScriptUtil_asDouble2Ptr(*args, **kwargs): pass
def MAttributeSpecArray___getitem__(*args, **kwargs): pass
def MItDependencyNodes_next(*args, **kwargs): pass
def MFnSubdData_type(*args, **kwargs): pass
def delete_MFnDoubleIndexedComponent(*args, **kwargs): pass
def MFloatVector_isParallel(*args, **kwargs): pass
def MTimeArray_sizeIncrement(*args, **kwargs): pass
def MMeshIntersector_swigregister(*args, **kwargs): pass
def MMatrixArray_remove(*args, **kwargs): pass
def MFnTypedAttribute_type(*args, **kwargs): pass
def MTrimBoundaryArray_reserve(*args, **kwargs): pass
def MDataHandle_asFloatVector(*args, **kwargs): pass
def MNamespace_validateName(*args, **kwargs): pass
def MFnDependencyNode_addAttribute(*args, **kwargs): pass
def MScriptUtil_asShortPtr(*args, **kwargs): pass
def MAttributeIndex_hasLowerBound(*args, **kwargs): pass
def MItDependencyGraph_isDone(*args, **kwargs): pass
def delete_MFnNurbsSurfaceData(*args, **kwargs): pass
def MFnCameraSet_getLayerOrder(*args, **kwargs): pass
def MTesselationParams_setVDistanceFraction(*args, **kwargs): pass
def MDagMessage_addAllDagChangesCallback(*args, **kwargs): pass


MFn_kPolyCutManip = 900

MFn_kPolyCutManipContainer = 899

MFn_kSymmetryMapVector = 829

MFn_kPolyWedgeFace = 898

MFn_kPolyPoke = 897

MFn_kPolyCut = 896

MFn_kBevelPlus = 894

MFn_kOceanShader = 893

MFn_kObjectFilter = 671

MFn_kVolumeLight = 892

MFn_kRampShader = 891

MFn_kImplicitSphere = 890

MFn_kImplicitCone = 889

MFn_kSubdCleanTopology = 888

MFn_kPluginHwShaderNode = 886

MFn_kUvChooser = 792

MFn_kPluginHardwareShader = 885

MFn_kHwShaderNode = 884

MFn_kPolyFlipUV = 883

MFn_kCurveParamComponent = 535

MFn_kSkinShader = 668

MFileIO_kVersion2013 = 167

MFn_kSubdHierBlind = 796

MFn_kEnvFogShape = 278

MFn_kSubdivEdgeComponent = 698

MFn_kDisplayLayerManager = 729

MFn_kCurveSegmentManip = 160

MFn_kDefaultLightList = 317

MFn_kDeformSquash = 622

MFn_kHistorySwitch = 983

MFn_kImageSource = 786

MFn_kResolution = 522

MFn_kBlinnMaterial = 386

MFn_kBlendColors = 31

MFn_kSubdAddTopology = 887

MFn_kRenderGlobals = 519

MFn_kCrater = 506

MFn_kReverseCurveManip = 181

MFn_kSetGroupComponent = 555

MFileIO_kVersion4_5 = 83

MFn_kMaterialInfo = 389

MFn_kLightSourceMaterial = 388

MFn_kPhongMaterial = 387

MFn_kBarnDoorManip = 150

MFn_kLambertMaterial = 385

MFn_kDiffuseMaterial = 384

MFn_kMakeGroup = 382

MFn_kLuminance = 381

MFn_kArrayMapper = 524

MFn_kLightList = 379

MFn_kEnvFogMaterial = 378

MFn_kLeastSquares = 376

MFn_kLightInfo = 375

MFn_kMountain = 499

MFn_kDynTurbulenceManip = 721

MFn_kLayeredShader = 374

MFn_kPhong = 372

MFn_kTwoPointArcManip = 645

MFn_kBlinn = 371

MFn_kLambert = 369

MFn_kBox = 862

MFn_kImagePlane = 368

MFn_kIkSystem = 367

MFn_kRPsolver = 365

MFn_kSCsolver = 364

MFn_kPASolver = 363

MFn_kIkSolver = 361

kUnknownParameter = 'unknown'

MFn_kHyperView = 360

MFn_kHyperLayout = 359

MFn_kHyperGraphInfo = 358

MFn_kHsvToRgb = 357

MFn_kPolyPlanProj = 421

MFn_kGuide = 356

MFn_kGroupParts = 355

MFn_kRoundRadiusCrvManip = 642

MFn_kWire = 353

MFn_kProxWrap = 352

MFn_kTension = 351

MFn_kPolyCreator = 431

MFn_kPolyTriangulate = 430

MFnData_kSphere = 18

MFn_kPolySubdEdge = 428

MFn_kPolySplit = 427

MFn_kPolySphProj = 426

MFn_kPolySoftEdge = 425

MFn_kPolySmooth = 424

MFn_kPolyQuad = 423

MFn_kPolyProj = 422

MFn_kBulge = 493

MFn_kPolyNormal = 420

MFn_kPolyMoveVertex = 418

MFn_kPolyMoveUV = 417

MFn_kWriteToColorBuffer = 1039

MFn_kPolyMoveFacetUV = 416

MFn_kPolyMoveFacet = 415

MFn_kPolyMoveEdge = 414

MFn_kNurbsCircular2PtArc = 638

MFn_kPolyMergeEdge = 412

MFn_kPolyMapSew = 411

MFn_kPolyMapDel = 410

MVector_kTol = 1e-10

MFn_kPolyMapCut = 409

MTransformationMatrix_kTol = 1e-10

MFn_kPolyExtrudeFacet = 408

MFn_kPolyDelVertex = 407

MPoint_kTol = 1e-10

MFn_kPolyDelFacet = 406

MMatrix_kTol = 1e-10

MFn_kImageDiff = 655

MFn_kPolyCylProj = 404

MCommandResult_kMatrix = 11

kMFnSubdTolerance = 0.001

MFn_kPolyCollapseF = 403

kMFnNurbsEpsilon = 0.001

MFn_kSectionManip = 813

kMFnMeshPointTolerance = 1e-10

MFn_kLodThresholds = 766

MFn_kPolyCloseBorder = 401

kMFnMeshTolerance = 0.001

MFn_kPolyChipOff = 400

MFn_kPolyAppend = 399

MFloatPoint_kTol = 1e-05

MFn_kPolyTweak = 398

MFloatMatrix_kTol = 1e-05

kEulerRotationEpsilon = 1e-10

MFn_kMidModifierWithMatrix = 396

MFn_kMidModifier = 395

MFn_kMatrixWtAdd = 394

MFn_kMatrixPass = 393

MFn_kTranslateLimitsManip = 226

MFn_kMatrixMult = 392

MFn_kMatrixHold = 391

MFn_kLayeredTexture = 799

MFn_kNObjectData = 1010

MFn_kCharacterMap = 798

MFn_kSubdBlindData = 797

MFn_kDeleteUVSet = 795

MFn_kVolumeAxis = 794

MFn_kSubdivCompId = 793

MFn_kGeometryConstraint = 113

MFn_kPolyAppendVertex = 791

MFn_kAnimBlendInOut = 790

MFn_kAnimBlend = 789

MFn_kPolyExtrudeEdge = 788

MFn_kPolyFlipEdge = 787

MFn_kObjectBinFilter = 938

MFn_kRenderedImageSource = 785

MFn_kPrecompExport = 783

MFn_kPassContributionMap = 782

MFn_kRenderLayerManager = 781

MFn_kRenderLayer = 780

MCommandResult_kStringArray = 8

MFn_kRenderPassSet = 779

MFn_kRenderPass = 778

MFn_kSmoothTangentSrf = 777

MFn_kClipLibrary = 775

MFn_kRenderTarget = 784

MFn_kClipScheduler = 774

MFn_kSurfaceFaceComponent = 773

MFn_kSurfaceEdManip = 772

MFn_kTowPointOnSurfaceManip = 771

MFn_kFourByFourMatrix = 770

MFn_kMultDoubleLinear = 769

MFn_kChooser = 767

MFn_kShadingMap = 473

MFn_kPolyReduce = 765

MFn_kDynGlobals = 764

MFn_kLightLink = 763

MFn_kPluginGeometryData = 762

MFn_kStrokeGlobals = 761

MFn_kRigidDeform = 341

MFn_kCurveCurveIntersect = 636

MFn_kCurveFromMeshEdge = 635

MAngle_kAngSeconds = 4

MFn_kDistanceManip = 633

MFn_kSoftModManip = 632

MFn_kScript = 634

MFn_kDimension = 269

MFn_kDeformFlareManip = 629

MFn_kDeformSquashManip = 628

MFn_kStoryBoard = 479

MFn_kDeformBendManip = 626

MFn_kDeformWave = 625

MFn_kSingleIndexedComponent = 708

MFn_kDeformFlare = 623

MFn_kDeformTwist = 621

MFn_kDeformBend = 620

MFn_kDeformFunc = 619

MFn_kNonLinear = 618

MFn_kForceUpdateManip = 690

MFn_kAnisotropy = 617

MFn_kNurbsSquare = 616

MFn_kTripleShadingSwitch = 615

MFn_kSl60 = 477

MFn_kSingleShadingSwitch = 613

MFn_kDeformWaveManip = 631

MFn_kPolyBoolOp = 612

MFn_kTorus = 611

MFn_kPluginDeformerNode = 610

MFn_kCommCornerOperManip = 609

MFn_kCommCornerManip = 608

MFn_kCommEdgePtManip = 605

MFn_kBlendNodeFloat = 1022

MFn_kSelectionList = 603

MFn_kVectorArrayData = 602

MFn_kStringArrayData = 601

MFn_kStringData = 600

MFn_kSphereData = 599

MFn_kUniform = 263

MFn_kPluginData = 596

MFn_kPolyNormalizeUV = 882

MFn_kCloud = 505

MFn_kHardwareReflectionMap = 881

MFn_kSubdMappingManip = 880

MFn_kSubdProjectionManip = 879

MFn_kSubdPlanProj = 877

MFn_kDeformTwistManip = 627

MFn_kData4Double = 876

MFn_kAttribute4Double = 875

MFn_kNoise = 874

MFn_kBlendNodeDoubleAngle = 1019

MFn_kSubdSubdivideFace = 873

MFn_kSubdAutoProj = 872

MFn_kVolumeNoise = 871

MFn_kPointLight = 309

MFn_kTranslateUVManip2D = 701

MFn_kSubdMapSewMove = 869

MFn_kSubdMapCut = 867

MFn_kSubdTweakUV = 866

MFn_kVolumeFog = 865

MFn_kDoubleShadingSwitch = 614

MFn_kSubdSplitFace = 864

MFn_kRenderBox = 863

MFn_kBoxData = 861

MFn_kSubdMergeVert = 860

MFn_kSubdCloseBorder = 859

MFn_kDeformSine = 624

MFn_kGlobalCacheControls = 857

MFn_kJiggleDeformer = 856

MFn_kSubdivMapComponent = 855

MFn_kSubdDelFace = 853

MFn_kSubdMoveFace = 852

MFn_kSubdMoveEdge = 851

MFn_kSubdMoveVertex = 850

MFn_kSubdModifier = 849

MFn_kPolyMapSewMove = 848

MFn_kPolyLayoutUV = 847

MFn_kPolyAverageVertex = 845

MFn_kPolyTransfer = 844

MFn_kUnused6 = 843

MFn_kUnused5 = 842

MFn_kPolyPyramid = 964

MFn_kPolyPrism = 963

MFn_kProxyManager = 961

MFn_kHikHandle = 960

MFn_kHikSolver = 959

MFn_kHikFKJoint = 958

MFn_kHikIKEffector = 957

MFn_kHikEffector = 956

MFn_kPluginConstraintNode = 1012

MFn_kPolyPinUV = 955

MFn_kPolyCreaseEdge = 954

MFn_kPolyMirror = 953

MFn_kKeyframeDeltaBreakdown = 952

MFn_kPolySmoothFacet = 694

MFn_kKeyframeDeltaWeighted = 951

MFn_kKeyframeDeltaTangent = 950

MFn_kKeyframeDeltaInfType = 949

MFn_kKeyframeDeltaBlockAddRemove = 948

MFn_kKeyframeDeltaAddRemove = 947

MFn_kKeyframeDeltaMove = 945

MFn_kKeyframeDelta = 944

MFn_kPsdFileTexture = 943

MFn_kPfxHair = 941

MFn_kProjectionManip = 173

MFn_kPfxGeometry = 940

MFn_kDropOffFunction = 821

MFn_kPolySmoothProxy = 939

MFn_kFloatVectorArrayData = 1009

MFn_kMentalRayTexture = 937

MFn_kGammaCorrect = 333

MFn_kTimeFunction = 936

MFn_kPoseInterpolatorManager = 1122

MFn_kHairConstraint = 935

MFn_kRemapHsv = 934

MFn_kRemapColor = 933

MFn_kRemapValue = 932

MFn_kHairSystem = 931

MFn_kTrimWithBoundaries = 928

MFn_kConstraint = 927

MFn_kMute = 926

MFn_kXformManip = 925

MFn_kTime = 516

MFn_kViewManip = 924

MFn_kGravity = 259

MFn_kFilletCurve = 70

MFn_kVortex = 264

MFn_kPolyMergeFacet = 413

MFn_kCreaseSet = 1085

MFn_kCommEdgeSegmentManip = 607

MFn_kMultiSubVertexComponent = 554

MFn_kSubVertexComponent = 553

MFn_kOrientationComponent = 552

MFn_kMeshFaceVertComponent = 551

MFn_kMeshVertComponent = 550

MFn_kMeshFrEdgeComponent = 549

MFn_kCreateEPManip = 158

MFn_kSkinClusterFilter = 681

MFn_kMeshEdgeComponent = 547

MFn_kMeshComponent = 546

MFn_kDecayRegionCapComponent = 544

MFn_kSurfaceRangeComponent = 543

MFn_kEdgeComponent = 541

MFn_kOffsetSurfaceManip = 647

MFn_kSurfaceEPComponent = 539

MAngle_kAngMinutes = 3

MFn_kSurfaceCVComponent = 538

MFn_kPivotComponent = 537

MFn_kTransformGeometry = 604

MFn_kIsoparmComponent = 536

MFn_kTweak = 345

MFn_kCurveKnotComponent = 534

MDagMessage_kAll = 268435455

MFn_kCurveEPComponent = 533

MFn_kComponent = 531

MFn_kVolumeShader = 530

MFn_kSelectionListOperator = 678

MFn_kVectorProduct = 529

MFn_kUnknown = 528

MFn_kUseBackground = 527

MFn_kUnitToTimeConversion = 526

MFn_kUnitConversion = 525

MFn_kCameraManip = 154

MFn_kHardwareRenderGlobals = 523

MFn_kRenderQuality = 521

MFn_kRenderGlobalsList = 520

MFn_kRenderSetup = 518

MFn_kTimeToUnitConversion = 517

MFileIO_kVersion6_0 = 105

MFn_kWood = 515

MFn_kTxSl = 514

MFn_kShot = 1046

MFn_kSequencer = 1045

MFn_kFollicle = 930

MFn_kSequenceManager = 1044

MFn_kStereoCameraMaster = 1043

MFn_kWriteToDepthBuffer = 1041

MFn_kWriteToVectorBuffer = 1040

MFn_kJointCluster = 349

MFn_kWriteToFrameBuffer = 1038

MFn_kPolySelectEditFeedbackManip = 1037

MFn_kPolyToolFeedbackManip = 1036

MFn_kUint64SingleIndexedComponent = 1035

MFn_kMatrixArrayData = 598

MFn_kFFD = 339

MFn_kMembrane = 1033

MFn_kSubSurface = 776

MFn_kFloatArrayData = 1032

MFn_kNId = 1031

MFn_kNIdData = 1030

MFn_kPluginManipulatorNode = 1029

MFn_kPointArrayData = 597

MFn_kBlendNodeAdditiveRotation = 1028

MFn_kBlendNodeAdditiveScale = 1027

MFn_kBlendNodeInt16 = 1025

MFn_kBlendNodeFloatLinear = 1024

MFn_kBlendNodeFloatAngle = 1023

MFn_kBlendNodeEnum = 1021

MFn_kBlendNodeDoubleLinear = 1020

MFn_kBlendNodeBoolean = 1017

MFn_kBlendNodeBase = 1016

MFn_kAnimLayer = 1015

MFn_kPolyEdgeToCurve = 1014

MFn_kAsset = 1013

MFn_kNObject = 1011

MFn_kPluginObjectSet = 919

MFn_kContainer = 1008

MFn_kPluginCameraSet = 1007

MFn_kCameraSet = 1006

MFn_kFosterParent = 1087

MFn_kPolyEditEdgeFlow = 1086

MFn_kRenderingList = 1068

MFn_kEditMetadata = 1084

MFn_kGreasePencilSequence = 1083

MFn_kGreasePlaneRenderShape = 1082

MFileIO_kVersion2008 = 144

MFn_kGreasePlane = 1081

MFn_kKeyingGroup = 682

MFn_kMandelbrot3D = 1080

MFn_kMandelbrot = 1079

MFn_kClipToGhostData = 1078

MFn_kAssembly = 1076

MFn_kTimeWarp = 1075

MFn_kFilterSimplify = 332

MFn_kPluginThreadedDevice = 1074

MFn_kPluginClientDevice = 1073

MFn_kSetRange = 470

MFn_kClientDevice = 1072

MFn_kThreadedDevice = 1071

MFn_kPolyExtrudeManipContainer = 1070

MFn_kGeometryOnLineManip = 142

MFn_kCollision = 253

MFn_kPolyProjectCurve = 1067

MFn_kHardwareRenderingGlobals = 1066

MFn_kPolyUVRectangle = 1065

MFn_kDagContainer = 1064

MFn_kContainerBase = 1063

MFn_kAdskMaterial = 1062

MFn_kNearestPointOnCurve = 1060

MFn_kVertexWeightSet = 1059

MFn_kSkinBinding = 1057

MFn_kFractal = 497

MFn_kFilter = 329

MFn_kPolyConnectComponents = 1056

MFn_kPolyHoleFace = 1054

MFileIO_kVersion8_5 = 139

MFn_kNurbsCurveToBezier = 1051

MFn_kBezierCurveData = 1050

MFn_kBezierCurve = 1049

MFn_kCreateBezierManip = 1048

MFn_kBlendNodeTime = 1047

MFn_kPolyBlindData = 753

MFn_kData3Int = 594

MFn_kData3Float = 593

MFn_kData3Double = 592

MFn_kData2Short = 591

MFn_kData2Int = 590

MFn_kFreePointTriadManip = 137

MFn_kCommEdgeOperManip = 606

MFn_kData2Float = 589

MFn_kData2Double = 588

MFn_kNumericData = 587

MFn_kNurbsCurveData = 586

MFn_kNurbsSurfaceData = 585

MFn_kMeshData = 584

MFn_kToonLineAttributes = 967

MFn_kMatrixData = 583

MFn_kLatticeData = 582

MFn_kIntArrayData = 581

MFn_kDoubleArrayData = 580

MFn_kData = 578

MFn_kReflect = 370

MFn_kPlugin = 577

MFn_kMessageAttribute = 576

MFn_kFloatMatrixAttribute = 575

MFn_kVolumeBindManip = 1058

MFn_kMatrixAttribute = 574

MFn_kLightDataAttribute = 573

MFn_kGenericAttribute = 572

MFn_kCompoundAttribute = 571

MFn_kTypedAttribute = 570

MFn_kEnvChrome = 489

MFn_kUnitAttribute = 569

MFn_kEnumAttribute = 568

MFn_kTimeAttribute = 567

MFn_kFloatLinearAttribute = 566

MFn_kDoubleLinearAttribute = 565

MFn_kDistanceBetween = 322

MFn_kFloatAngleAttribute = 564

MFn_kNumericAttribute = 562

MFn_kItemList = 560

MFn_kSubdLayoutUV = 868

MFn_kNonDagSelectionItem = 559

MFn_kDagSelectionItem = 558

MFn_kSelectionItem = 557

MFn_kPointOnPolyConstraint = 1055

MFn_kDynParticleSetComponent = 556

MFn_kReorderUVSet = 1128

MFn_kArubaTesselate = 1127

MFn_kCustomEvaluatorClusterNode = 1125

MFn_kReForm = 1124

MFn_kControllerTag = 1123

MFn_kOceanDeformer = 1121

MFn_kShapeEditorManager = 1120

MFn_kPolySpinEdge = 1053

MFn_kTrackInfoManager = 1118

MFn_kPolyPassThru = 1117

MFn_kExtrudeManip = 165

MFn_kPluginGeometryFilter = 1115

MFn_kBezierCurveToNurbs = 1052

MFn_kNodeGraphEditorBookmarks = 1112

MFn_kPluginSkinCluster = 1114

MFn_kNodeGraphEditorInfo = 1111

MFn_kContourProjectionManip = 1110

MFn_kPolyRemesh = 1108

MFn_kPolyModifierManipContainer = 1107

MFn_kPluginParticleAttributeMapperNode = 1005

MFn_kNRigid = 1004

MFn_kCaddyManipBase = 1105

MFn_kCenterManip = 134

MFn_kTimeEditorAnimSource = 1104

MFn_kNCloth = 1002

MFn_kTimeEditorInterpolator = 1103

MFn_kPluginImagePlaneNode = 1001

MFn_kTimeEditorTracks = 1102

MFn_kHyperLayoutDG = 1000

MFn_kTimeEditor = 1101

MFn_kTimeEditorClip = 1100

MFn_kWriteToLabelBuffer = 1042

MFn_kCurveNormalizerAngle = 998

MFn_kTimeEditorClipEvaluator = 1099

MFn_kKeyframeRegionManip = 997

MFn_kCacheTrack = 996

MFn_kSpring = 315

MFn_kPolyBevel3 = 1097

MFn_kCacheBlend = 995

MFn_kColorMgtGlobals = 1096

MFn_kCacheBase = 994

MFn_kGeomBind = 1095

MFn_kNBase = 993

MFn_kPolyCBoolOp = 1094

MFn_kNucleus = 992

MFileObject_kInputReference = 62

MFn_kPolyBevel2 = 1093

MFn_kEditsManager = 1092

MFn_kPolyBridgeEdge = 990

MFn_kShrinkWrapFilter = 1091

MFn_kNComponent = 989

MFn_kGeometric = 265

MFn_kDynamicConstraint = 988

MFn_kToolContext = 1089

MFn_kTransferAttributes = 987

MFn_kPolyAutoProj = 846

MFn_kSnapUVManip2D = 1088

MFn_kPinToGeometryProx = 986

MFn_kPinToGeometryUV = 985

MNodeMessage_kAttributeArrayRemoved = 8192

MFn_kAttribute2Int = 745

MFn_kClosestPointOnMesh = 984

MNodeMessage_kAttributeArrayAdded = 4096

MNodeMessage_kIncomingDirection = 2048

MFn_kCacheFile = 982

MNodeMessage_kAttributeUnkeyable = 1024

MFn_kPolyHelix = 981

MFn_kPolyComponentData = 980

MDagMessage_kRotateOrient = 117440512

MFn_kHikGroundPlane = 979

MDagMessage_kRotatePivotTrans = 14680064

MFn_kHikFloorContactMarker = 978

MFn_kPolyToolFeedbackShape = 312

MFn_kPolyPipe = 977

MDagMessage_kRotatePivot = 229376

MDagMessage_kScalePivot = 28672

MFn_kPolyDelEdge = 405

MFn_kPolyArrow = 974

MDagMessage_kRotation = 448

MFn_kLineModifier = 973

MFn_kDiskCache = 858

MFn_kAISEnvFacade = 972

MDagMessage_kRotateOrder = 134217728

MFn_kEnvFacade = 971

MFn_kMaterialFacade = 970

MDagMessage_kRotateOrientY = 33554432

MFn_kFacade = 969

MDagMessage_kRotateOrientX = 16777216

MFn_kPolyDuplicateEdge = 968

MDagMessage_kRotateTransY = 4194304

MDagMessage_kRotateTransX = 2097152

MFn_kPolySplitRing = 965

MDagMessage_kScaleTransZ = 1048576

MDagMessage_kScaleTransY = 524288

MFn_kUnused4 = 841

MDagMessage_kScaleTransX = 262144

MFn_kUnused3 = 840

MDagMessage_kRotatePivotZ = 131072

MFn_kUnused2 = 839

MFn_kUnused1 = 838

MDagMessage_kRotatePivotX = 32768

MDagMessage_kScalePivotZ = 16384

MFn_kSfRevolveManip = 836

MFn_kSubdivSurfaceVarGroup = 835

MDagMessage_kTranslateZ = 2048

MFn_kModifyEdgeBaseManip = 833

MFn_kCreateBPManip = 832

MDagMessage_kTranslateX = 512

MFn_kCurveFromSubdivEdge = 831

MAYA_CUSTOM_VERSION = 20190000

MFn_kSymmetryMapCurve = 830

MAYA_API_VERSION = 20190000

MAYA_APP_VERSION = 2019

MFn_kSymmetryLocator = 828

MFn_kData3Long = 594

MFn_kTransformBoxManip = 827

MFn_kSnapshotShape = 854

MFn_kScalePointManip = 826

MFn_kAttribute3Long = 749

MFn_kModifyEdgeManip = 825

MFn_kAttribute2Long = 745

MFn_kModifyEdgeCrvManip = 824

MFn_kLast = 1130

MFn_kSubdModifyEdge = 823

MFn_kUfeProxyTransform = 1129

MFn_kSubdBoolean = 822

MFn_kCrossSectionEditManip = 820

MFn_kCreateSectionManip = 819

MFn_kCrossSectionManager = 818

MFn_kOffsetSurface = 639

MFn_kEditCurveManip = 817

MFn_kEditCurve = 816

MFn_kSubdivToNurbs = 815

MFn_kXsectionSubdivEdit = 814

MFn_kInstancer = 757

MFn_kMeshMapComponent = 812

MFn_kSubdivReverseFaces = 811

MFn_kPolySplitEdge = 810

MFn_kInt64ArrayData = 809

MFn_kUInt64ArrayData = 808

MFn_kSubdivGeom = 807

MFn_kSubdivData = 806

MFn_kPolySplitVert = 805

MFn_kClip = 804

MFn_kCreateUVSet = 803

MFn_kCopyUVSet = 802

MFn_kParticleSamplerInfo = 801

MFn_kClipGhostShape = 1077

cvar = None

MFn_kPolyNormalPerVertex = 754

MFn_kPlace3dTexture = 454

MFn_kKeyframeDeltaScale = 946

MFn_kLightProjectionGeometry = 234

MFn_kLodGroup = 768

MFn_kReference = 750

MFn_kSoftModFilter = 348

MFn_kClusterFilter = 347

MFn_kWeightGeometryFilt = 346

MFn_kFluidData = 911

MFn_kTextureDeformerHandle = 344

MFn_kTextureDeformer = 343

MFn_kSculpt = 342

MFn_kFfdDualBase = 340

MFn_kBulgeLattice = 338

MFn_kCombinationShape = 337

MFn_kBlendShape = 336

MFn_kBendLattice = 335

MFn_kGeometryFilt = 334

MFn_kFilterEuler = 331

MFn_kFilterClosestSample = 330

MFn_kExtract = 328

MFn_kExpression = 327

MFn_kGeoConnectable = 326

MFn_kDummyConnectable = 324

MFn_kDOF = 323

MFn_kPolyAutoProjManip = 962

MFn_kDisplacementShader = 321

MFn_kShadingEngine = 320

MFn_kDispatchCompute = 319

MFn_kDeleteComponent = 318

MFn_kUnknownDag = 316

MFn_kComponentListData = 579

MFn_kRigid = 314

MFn_kRigidConstraint = 313

MFn_kParticle = 311

MFn_kSpotLight = 310

MFn_kStroke = 759

MFn_kMoveVertexManip = 758

MFn_kMeshPolygonComponent = 548

MFn_kPluginIkSolver = 756

MFn_kMeshVtxFaceComponent = 740

MFn_kNurbsToSubdiv = 755

MFn_kBlindDataTemplate = 752

MFn_kBlindData = 751

MFn_kAttribute3Int = 749

MFn_kAttribute3Short = 748

MFn_kAttribute3Float = 747

MFn_kAttribute3Double = 746

MFn_kAttribute2Short = 744

MFn_kAttribute2Float = 743

MFn_kAttribute2Double = 742

MFn_kBinaryData = 741

MFn_kWrapFilter = 739

MFn_kCurveFromSubdivFace = 837

MFn_kDynSweptGeometryData = 738

MFn_kFluid = 909

MFn_kPolyColorDel = 736

MFn_kPolyColorMod = 735

MFn_kBlendColorSet = 734

MFn_kCopyColorSet = 733

MFn_kMCsolver = 362

MFn_kDeleteColorSet = 732

MFn_kCreateColorSet = 731

MFn_kPolyColorPerVertex = 730

MFn_kDisplayLayer = 728

MFn_kPluginEmitterNode = 726

MFn_kPluginFieldNode = 725

MFn_kDynArrayAttrsData = 724

MFn_kDynAttenuationManip = 723

MFn_kDynSpreadManip = 722

MFn_kDynNewtonManip = 720

MFn_kDynAirManip = 719

MFn_kDistance = 272

MFn_kArcLength = 273

MFn_kAir = 257

MFn_kDrag = 258

MFn_kNewton = 260

MFn_kRadial = 261

MFn_kTurbulence = 262

MFn_kInsertKnotSrf = 76

MFn_kChainToSpline = 35

MFn_kHardenPointCurve = 73

MFn_kFlow = 72

MFn_kFitBspline = 71

MFn_kFFfilletSrf = 69

MFn_kFFblendSrf = 68

MFn_kExtrude = 67

MFn_kAttribute = 561

MFn_kExtendSurface = 66

MFn_kExtendCurve = 65

MFn_kCircleManip = 126

MFn_kDetachCurve = 63

MFn_kCurveFromSurfaceIso = 61

MFn_kCurveFromSurfaceCoS = 60

MFn_kMatrixAdd = 390

MFn_kCurveFromSurfaceBnd = 59

MFn_kMergeVertsToolManip = 1034

MFn_kCurveFromSurface = 58

MFn_kCloseSurface = 57

MDagMessage_kShear = 56

MFn_kPluginSpringNode = 727

MFn_kCloseCurve = 55

MFn_kShaderList = 472

MFn_kBoundary = 53

MFn_kShaderGlow = 471

MFn_kSPbirailSrf = 52

MFileObject_kInputFile = 54

MFn_kMPbirailSrf = 51

MFn_kVertexBakeSet = 469

MFn_kTextureBakeSet = 468

MFn_kBirailSrf = 49

MFn_kBevel = 48

MFn_kRigidSolver = 466

MFn_kAvgNurbsSurfacePoints = 47

MFn_kRgbToHsv = 465

MFn_kReverse = 464

MFn_kAvgCurves = 45

MFn_kData3Short = 595

MFn_kAttachCurve = 43

MFn_kProjection = 461

MFn_kAlignSurface = 42

MFn_kAlignCurve = 41

MFn_kPolySeparate = 459

MFn_kCreate = 40

MFn_kPointMatrixMult = 458

MFn_kClampColor = 39

MFn_kPluginLocatorNode = 456

MFn_kCondition = 37

MFn_kPluginDependNode = 455

MFn_kChoice = 36

MAYA_CUSTOM_VERSION_CLIENT = ''

MFn_kPolyBevel = 397

MFn_kPlace2dTexture = 453

MFileIO_kVersion6_5 = 117

MFn_kPartition = 452

MFn_kHairTubeShader = 942

MFn_kCurveVarGroup = 116

MFn_kParticleTransparencyMapper = 451

MFn_kAnyGeometryVarGroup = 115

MFn_kParticleIncandecenceMapper = 450

MFn_kGeometryVarGroup = 114

MFn_kParticleColorMapper = 449

MFn_kParticleCloud = 448

MFn_kLookAt = 112

MFn_kAimConstraint = 111

MFn_kOldGeometryConstraint = 445

MFn_kUnderWorld = 109

MFn_kMultiplyDivide = 444

MFn_kProxy = 108

MFn_kDagNode = 107

MFn_kPluginMotionPathNode = 442

MFn_kUntrim = 106

MFn_kMotionPath = 441

MFn_kPolyUnite = 440

MFn_kTrsXformManip = 204

MFn_kTextCurves = 104

MFn_kPolyCreateFacet = 439

MFn_kSurfaceInfo = 103

MFn_kSubCurve = 102

MFn_kPolySphere = 437

MFn_kStitchSrf = 101

MFn_kMaterial = 383

MFn_kPolyMesh = 436

MFn_kSkin = 100

MFn_kPolyCylinder = 435

MFn_kSphere = 99

MFn_kPolyCube = 434

MFn_kCylinder = 98

MFn_kPolyCone = 433

MFn_kRenderCone = 97

kQuaternionEpsilon = 1e-10

MFn_kPolyPrimitive = 432

MFn_kCone = 96

MFn_kRevolvedPrimitive = 95

MFn_kNurbsSurface = 294

MFn_kRevolve = 94

MFn_kSolidFractal = 512

MFn_kReverseSurface = 93

MFn_kSnow = 511

MFn_kReverseCurve = 92

MFn_kRock = 510

MFn_kRebuildSurface = 91

MFn_kMarble = 509

MFileIO_kVersion5_0 = 90

MFn_kPolyCircularize = 1126

MFn_kLeather = 508

MFn_kGranite = 507

MFn_kProjectTangent = 88

MFn_kProjectCurve = 87

MFn_kPrimitive = 86

MFn_kBrownian = 504

MFn_kPointOnSurfaceInfo = 85

MFn_kTexture3d = 503

MFn_kPointOnCurveInfo = 84

MFn_kWater = 502

MFn_kLightSource = 380

MFn_kSubdivToPoly = 714

MFn_kStencil = 501

MFn_kOffsetCurve = 82

MFn_kRamp = 500

MFn_kNurbsCube = 80

MFn_kGrid = 498

MFn_kNurbsPlane = 79

MFn_kNurbsTesselate = 78

MFn_kFileTexture = 496

MFn_kIntersectSurface = 77

MDagMessage_kScalePivotX = 4096

MFn_kCloth = 495

MFn_kChecker = 494

MFn_kPolyCaddyManip = 1106

MFn_kTexture2d = 492

MFn_kEnvSphere = 491

MFn_kEnvSky = 490

MFileIO_kVersion2017Update3 = 202

MFn_kEnvCube = 488

MFn_kEnvBall = 487

MFn_kTextureEnv = 486

MFn_kTextureList = 485

MFn_kSurfaceShader = 484

MFn_kPolyExtrudeManip = 1069

MFn_kLightFogMaterial = 377

MFn_kSurfaceLuminance = 483

MFn_kControl = 482

MFn_kSuper = 481

MFn_kSummaryObject = 480

MFn_kSnapshot = 478

MFn_kRBFsurface = 89

MFn_kSimpleVolumeShader = 476

MFn_kShapeFragment = 475

MFn_kSamplerInfo = 474

MFn_kPolyClean = 1119

MFn_kBrush = 760

MFn_kPhongExplorer = 373

MFn_kCurveFromMeshCoM = 929

MFn_kCurveNormalizerLinear = 999

MFn_kCreateCVManip = 157

MFileIO_kVersion2011 = 156

MFn_kCoiManip = 155

MFn_kPluginBlendShape = 1116

MFn_kButtonManip = 153

MFileIO_kVersion2010 = 152

MFn_kBevelManip = 151

MFn_kLinearLight = 306

MFn_kAverageCurveManip = 149

MFn_kManipContainer = 148

MFileIO_kVersion2009 = 147

MFn_kIsoparmManip = 146

MFn_kStateManip = 145

MFn_kFluidTexture3D = 903

MFn_kCameraPlaneManip = 143

MFn_kPolySplitToolManip = 141

MFn_kPolyCreateToolManip = 140

kDefaultNodeType = 'dependNode'

MFn_kPropMoveTriadManip = 138

MFn_kNodeGraphEditorBookmarkInfo = 1113

MFn_kEnableManip = 136

MFn_kLimitManip = 135

MFileIO_kVersion8_0 = 133

MFn_kAmbientLight = 303

MFn_kDiscManip = 132

MFn_kCylindricalProjectionManip = 131

MFn_kCubicProjectionManip = 130

MFn_kConcentricProjectionManip = 129

MDagMessage_kRotateY = 128

MFn_kScreenAlignedCircleManip = 127

MFn_kBallProjectionManip = 125

MFn_kAxesActionManip = 124

MFn_kSplineSolver = 366

MFn_kArrowManip = 123

MFn_kManipulator3D = 122

MFn_kJoint = 121

MFn_kIkHandle = 120

MFn_kIkEffector = 119

MFn_kPolyVertexNormalManip = 197

MFn_kPointConstraint = 240

MFn_kOrientConstraint = 239

MFn_kNormalConstraint = 238

MFn_kTriadManip = 237

MFn_kPolyContourProj = 1109

MFn_kPointManip = 236

MFn_kLineArrowManip = 235

MFn_kFixedLineManip = 233

MFileIO_kVersion2019 = 232

MFn_kCirclePointManip = 231

MFn_kManipulator = 230

MFn_kPolyPrimitiveMisc = 975

MFn_kJointTranslateManip = 229

MFn_kTrimManip = 228

MFn_kTranslateManip = 227

MFn_kSurfaceKnotComponent = 540

MFn_kTranslateBoxManip = 225

MFn_kToggleManip = 224

MFn_kTextureManip3D = 223

MFn_kSphericalProjectionManip = 222

MFn_kScriptManip = 221

MNodeMessage_kLast = 32768

MFn_kCharacterMappingData = 737

MFn_kScalingBoxManip = 220

MNodeMessage_kOtherPlugSet = 16384

MFn_kScaleManip = 219

MFn_kScaleLimitsManip = 218

MFn_kRotateLimitsManip = 217

MFn_kHandleRotateManip = 216

MFn_kRotateManip = 215

MFn_kSubdTweak = 878

MFileIO_kVersion2018Update5 = 214

MFileIO_kVersion2018Update4 = 213

MFileIO_kVersion2018Update3 = 212

MFileIO_kVersion2018Update2 = 211

MFn_kNParticle = 1003

MFileIO_kVersion2018 = 210

MFn_kTowPointOnCurveManip = 209

MFn_kPointOnCurveManip = 208

MFn_kPlanarProjectionManip = 207

MFn_kTranslateManip2D = 206

MFn_kInsertKnotCrv = 75

MFn_kManipulator2D = 205

MFileIO_kVersion2017Update4 = 203

MFn_kGroupId = 354

MFileIO_kVersion2017 = 201

MFn_kTexLattice = 200

MFileIO_kVersion4_0 = 74

MFn_kStucco = 513

MDagMessage_kRotateZ = 256

MFnDagNode_kNextPos = 255

MFn_kSoftMod = 252

MFn_kCluster = 251

MFn_kCamera = 250

MFn_kBlend = 27

MFn_kBaseLattice = 249

MFn_kShape = 248

MFn_kWorld = 247

MFn_kUnknownTransform = 246

MFn_kTimeEditorClipBase = 1098

MFn_kScaleConstraint = 244

MFn_kPoleVectorConstraint = 243

MFn_kParentConstraint = 242

MFn_kSymmetryConstraint = 241

MFn_kTexLatticeDeformManip = 199

MFn_kDummy = 254

MFn_kSurfaceVarGroup = 118

MFn_kPolyMoveVertexManip = 196

MFn_kPolyModifierManip = 195

MFn_kDeltaMush = 350

MFn_kPolyMappingManip = 194

MFn_kBlendNodeInt32 = 1026

MFileIO_kVersion2016 = 192

MFn_kPivotManip2D = 191

MFn_kDblTrsManip = 190

MFn_kTriplanarProjectionManip = 188

MFn_kAvgSurfacePoints = 46

MFn_kSpotManip = 186

MFn_kRevolvedPrimitiveManip = 185

MFileIO_kVersion2015 = 184

MFn_kReverseSurfaceManip = 183

MDagMessage_kRotateX = 64

MFn_kReverseCrvManip = 182

MFn_kMarker = 283

MFileIO_kVersion2014 = 179

MFn_kPropModManip = 178

MFn_kObjectScriptFilter = 677

MFn_kProjectionMultiManip = 176

MFn_kObjectRenderFilter = 676

MFn_kProjectionUVManip = 175

MFn_kObjectAttrFilter = 675

MFn_kPolyProjectionManip = 174

MFn_kObjectTypeFilter = 674

MFn_kObjectNameFilter = 673

MFn_kOffsetCurveManip = 172

MFn_kObjectMultiFilter = 672

MFn_kOffsetCosManip = 171

MFn_kMotionPathManip = 170

MFn_kSubdivCollapse = 800

MFn_kSelectionListData = 670

MFn_kLightManip = 169

MFn_kComponentManip = 669

MFn_kJointClusterManip = 168

MFn_kMatrixFloatData = 667

MFn_kIkSplineManip = 166

MFn_kViewColorManager = 666

MFn_kImageMotionBlur = 665

MFn_kExtendCurveDistanceManip = 164

MFn_kImageView = 664

MFn_kDropoffManip = 163

MFn_kDofManip = 162

MFn_kImageDepth = 662

MFileIO_kVersion2012 = 161

MFn_kImageFilter = 661

MFn_kImageBlur = 660

MFn_kCurveEdManip = 159

MFn_kImageColorCorrect = 659

MFn_kImageUnder = 658

MFn_kImageOver = 657

MFn_kCameraView = 34

MFn_kImageMultiply = 656

MFn_kBump3d = 33

MDagMessage_kShearYZ = 32

MFn_kImageAdd = 654

MFn_kImageRender = 653

MFn_kBlendDevice = 30

MFn_kImageNetDest = 652

MFn_kBlendWeighted = 29

MFn_kImageNetSrc = 651

MFn_kBlendTwoAttr = 28

MFn_kImageSave = 650

MFloatVector_kTol = 1e-05

MFn_kImageLoad = 649

MFn_kRampBackground = 26

MFn_kImageData = 648

MFnData_kLast = 25

MFnData_kAny = 24

MFn_kTextButtonManip = 646

MFnData_kNId = 23

MFn_kTangentConstraint = 245

MFnData_kNObject = 22

MFn_kThreePointArcManip = 644

MFnData_kSubdSurface = 21

MFn_kRoundConstantRadiusManip = 643

MFnData_kDynSweptGeometry = 20

MFn_kRoundRadiusManip = 641

MFn_kRoundConstantRadius = 640

MFnData_kNurbsSurface = 17

MDagMessage_kShearXZ = 16

MFnData_kLattice = 15

MFn_kNurbsCircular3PtArc = 637

MFnData_kMesh = 14

MFnData_kComponentList = 13

MFn_kDynBaseFieldManip = 718

MFn_kPluginShape = 706

MCommandResult_kMatrixArray = 12

MFn_kDynFieldsManip = 717

MFn_kDynEmitterManip = 716

MCommandResult_kVectorArray = 10

MFn_kDynBase = 715

MCommandResult_kVector = 9

MFn_kSquareSrfManip = 713

MCommandResult_kString = 7

MFn_kData2Long = 590

MFn_kSquareSrf = 712

MCacheFormatDescription_kFloatVectorArray = 6

MFn_kExtendSurfaceDistanceManip = 711

MAngle_kLast = 5

MFn_kTripleIndexedComponent = 710

MFn_kDoubleIndexedComponent = 709

MAngle_kDegrees = 2

MFn_kGeometryData = 707

MAngle_kRadians = 1

MAYA_CUSTOM_VERSION_MAJOR = 0

MFn_kMoveUVShellManip2D = 705

MDagMessage_kInvalidMsg = -1

MFn_kPolyTweakUV = 704

MFn_kScaleUVManip2D = 703

MFn_kRotateUVManip2D = 702

MNodeMessage_kAttributeKeyable = 512

MFn_kColorProfile = 1061

MFn_kUVManip2D = 700

MFn_kSubdivFaceComponent = 699

MFn_kSubdivCVComponent = 697

MFn_kGlobalStitch = 696

MFn_kSmoothCurve = 695

MFn_kPolyMoveVertexUV = 419

MFn_kPolyTorus = 438

MFn_kOffsetCos = 81

MFn_kPolyMergeVert = 693

MFn_kPolySewEdge = 692

MFn_kPluginManipContainer = 691

MFn_kStitchSrfManip = 689

MFn_kNurbsBoolean = 688

MFn_kExplodeNurbsShell = 687

MFn_kStitchAsNurbsShell = 686

MFileIO_kVersion2016R2 = 198

MFn_kDagPose = 685

MFn_kCharacterOffset = 684

MDagMessage_kScalePivotTrans = 1835008

MFn_kCharacter = 683

MFn_kDPbirailSrf = 50

MFn_kPolyToSubdiv = 680

MFn_kAngle = 270

MFn_kSubdiv = 679

MFn_kDeformSineManip = 630

MFn_kPolyPlatonicSolid = 976

MFn_kSet = 467

MDagMessage_kTranslation = 3584

MFn_kPolyMoveUVManip = 193

MFn_kStyleCurve = 895

MFn_kRenderUtilityList = 463

MFn_kAttachSurface = 44

MFn_kRecord = 462

MDagMessage_kRotateOrientZ = 67108864

MFn_kPostProcessList = 460

MFn_kTrsManip = 189

MFn_kDoubleAngleAttribute = 563

MDagMessage_kRotateTransZ = 8388608

MFn_kSpotCylinderManip = 187

MFn_kPfxToon = 966

MFn_kCurveCVComponent = 532

MFn_kPlusMinusAverage = 457

kMFnSubdPointTolerance = 1e-10

MFn_kOcean = 870

MFn_kPolyCollapseEdge = 402

MFn_kDirectionalLight = 308

MFn_kNonExtendedLight = 307

MFn_kPolySubdFacet = 429

MFn_kAreaLight = 305

MFn_kNonAmbientLight = 304

MFn_kDynamicsController = 325

MFn_kLight = 302

MFn_kGuideLine = 301

MFn_kClusterFlexor = 300

MFn_kFlexor = 299

MFn_kRenderSphere = 298

MDagMessage_kRotatePivotY = 65536

MFn_kMeshGeom = 297

MFn_kMesh = 296

MFn_kNurbsSurfaceGeom = 295

MFn_kRbfSrfManip = 180

MFn_kSurface = 293

MFn_kSprite = 292

MFn_kOrthoGrid = 291

MFn_kGroundPlane = 290

MFn_kSketchPlane = 289

MFn_kPlane = 288

MFn_kTrimLocator = 287

MFn_kOrientationLocator = 286

MFn_kPositionMarker = 285

MFn_kOrientationMarker = 284

MFn_kDropoffLocator = 282

MFn_kDecayRegionComponent = 545

MFn_kLocator = 281

MFn_kLatticeGeom = 280

MDagMessage_kScalePivotY = 8192

MFn_kLattice = 279

MFn_kRadius = 274

MFn_kParamDimension = 275

MFn_kProjectTangentManip = 177

MFn_kDirectedDisc = 276

MFn_kRenderRect = 277

MFn_kCurve = 266

MFn_kNurbsCurve = 267

MFn_kSubdExtrudeFace = 834

MFn_kNurbsCurveGeom = 268

MFn_kImageDisplay = 663

MFnData_kDynArrayAttrs = 19

MFn_kParticleAgeMapper = 447

MFn_kAnnotation = 271

MFn_kTextManip = 923

MFn_kPairBlend = 922

MFn_kNLE = 1090

MFn_kPolyExtrudeVertex = 921

MFn_kLatticeComponent = 542

MFn_kQuadShadingSwitch = 920

MFn_kOpticalFX = 446

MDagMessage_kTranslateY = 1024

MFn_kSnapshotPath = 918

MFn_kTransform = 110

MFn_kGeoConnector = 917

MFn_kHeightField = 916

MFn_kFluidEmitter = 915

MFn_kStudioClearCoat = 914

MFn_kStringShadingSwitch = 913

MFn_kSmear = 912

MFn_kFluidGeom = 910

MFn_kBlendNodeDouble = 1018

MFn_kPluginTransformNode = 908

MFn_kAlignManip = 907

MFn_kPolyStraightenUVBorder = 906

MFn_kPolyMergeUV = 905

MFn_kFluidTexture2D = 904

MFn_kContrast = 38

MFn_kPolyPokeManip = 902

MFn_kMultilisterLight = 443

MFn_kCacheableNode = 991

MFn_kPolyMirrorManipContainer = 901


