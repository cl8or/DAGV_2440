if False:
    from typing import Dict, List, Tuple, Union, Optional

def MFnCircleSweepManip_setRadius(*args, **kwargs): pass
def MFnDistanceManip_setDrawLine(*args, **kwargs): pass
def MFnRotateManip_connectToRotationCenterPlug(*args, **kwargs): pass
def MFnToggleManip_swigregister(*args, **kwargs): pass
def delete_MMaterialArray(*args, **kwargs): pass
def MFnCurveSegmentManip_endParamIndex(*args, **kwargs): pass
def MMaterialArray_className(*args, **kwargs): pass
def uIntPtr_swigregister(*args, **kwargs): pass
def MSelectInfo_singleSelection(*args, **kwargs): pass
def MCursor___eq__(*args, **kwargs): pass
def MFnCurveSegmentManip_connectToCurvePlug(*args, **kwargs): pass
def MFnFreePointTriadManip_setDrawAxes(*args, **kwargs): pass
def new_MFnScaleManip(*args, **kwargs): pass
def MGraphEditorInfo_name(*args, **kwargs): pass
def MProgressWindow_startProgress(*args, **kwargs): pass
def MSelectInfo_swigregister(*args, **kwargs): pass
def M3dView_playblastPortWidth(*args, **kwargs): pass
def MDeviceState_buttonState(*args, **kwargs): pass
def M3dView_swigregister(*args, **kwargs): pass
def MFeedbackLine_swigregister(*args, **kwargs): pass
def MFnDirectionManip_connectToDirectionPlug(*args, **kwargs): pass
def MFnPointOnCurveManip_create(*args, **kwargs): pass
def MManipData_asShort(*args, **kwargs): pass
def MProgressWindow_isInterruptable(*args, **kwargs): pass
def MDrawRequest_className(*args, **kwargs): pass
def delete_shortPtr(*args, **kwargs): pass
def M3dView_endGL(*args, **kwargs): pass
def MDrawInfo_setMultiPath(*args, **kwargs): pass
def MDrawTraversal_leafLevelCulling(*args, **kwargs): pass
def MFnManip3D_lineSize(*args, **kwargs): pass
def MFnDiscManip_setCenterPoint(*args, **kwargs): pass
def MFnPointOnSurfaceManip_create(*args, **kwargs): pass
def delete_MFnToggleManip(*args, **kwargs): pass
def MMaterial_materialIsTextured(*args, **kwargs): pass
def MQtUtil_getParent(*args, **kwargs): pass
def MPaintMessage_swigregister(*args, **kwargs): pass
def doublePtr_value(*args, **kwargs): pass
def M3dView_setUserDefinedColor(*args, **kwargs): pass
def M3dView_multipleDrawPassCount(*args, **kwargs): pass
def MFnDistanceManip_setDrawStart(*args, **kwargs): pass
def MFnRotateManip_connectToRotationPlug(*args, **kwargs): pass
def MFnToggleManip_setToggle(*args, **kwargs): pass
def new_MMaterialArray(*args, **kwargs): pass
def MSelectInfo_view(*args, **kwargs): pass
def MFnCircleSweepManip_connectToAnglePlug(*args, **kwargs): pass
def uIntPtr_frompointer(*args, **kwargs): pass
def M3dView_activeAffectedColor(*args, **kwargs): pass
def MCursor_assign(*args, **kwargs): pass
def MDrawRequest_color(*args, **kwargs): pass
def MExternalDropData_image(*args, **kwargs): pass
def MFnCurveSegmentManip_create(*args, **kwargs): pass
def MFnFreePointTriadManip_connectToPointPlug(*args, **kwargs): pass
def MManipData_isSimple(*args, **kwargs): pass
def MFnScaleManip_className(*args, **kwargs): pass
def MGraphEditorInfo_reset(*args, **kwargs): pass
def MProgressWindow_reserve(*args, **kwargs): pass
def MSelectInfo_className(*args, **kwargs): pass
def M3dView_makeSharedContextCurrent(*args, **kwargs): pass
def M3dView_modelViewMatrix(*args, **kwargs): pass
def MDeviceState_setDevicePosition(*args, **kwargs): pass
def MDrawRequestQueue_isEmpty(*args, **kwargs): pass
def delete_MFeedbackLine(*args, **kwargs): pass
def M3dView_isShadeActiveOnly(*args, **kwargs): pass
def MFnDirectionManip_create(*args, **kwargs): pass
def new_MFnPointOnCurveManip(*args, **kwargs): pass
def MFnScaleManip_scaleCenterIndex(*args, **kwargs): pass
def MSelectInfo_selectOnHilitedOnly(*args, **kwargs): pass
def MProgressWindow_setInterruptable(*args, **kwargs): pass
def MUiMessage_addUiDeletedCallback(*args, **kwargs): pass
def M3dView_viewSelectedPrefix(*args, **kwargs): pass
def new_shortPtr(*args, **kwargs): pass
def M3dView_beginGL(*args, **kwargs): pass
def M3dView_rendererString(*args, **kwargs): pass
def MDrawInfo_multiPath(*args, **kwargs): pass
def MFnManip3D_setHandleSize(*args, **kwargs): pass
def MFnDiscManip_connectToAnglePlug(*args, **kwargs): pass
def new_MFnPointOnSurfaceManip(*args, **kwargs): pass
def MFnToggleManip_type(*args, **kwargs): pass
def MMaterial_evaluateTexture(*args, **kwargs): pass
def MQtUtil_getLayoutChildren(*args, **kwargs): pass
def delete_MPaintMessage(*args, **kwargs): pass
def doublePtr_assign(*args, **kwargs): pass
def M3dView_numUserDefinedColors(*args, **kwargs): pass
def M3dView_setMultipleDrawEnable(*args, **kwargs): pass
def delete_MDrawRequest(*args, **kwargs): pass
def MEvent_setModifiers(*args, **kwargs): pass
def MFnCircleSweepManip_setEndPoint(*args, **kwargs): pass
def MFnDistanceManip_setDirection(*args, **kwargs): pass
def MFnRotateManip_create(*args, **kwargs): pass
def MExternalDropData_hasText(*args, **kwargs): pass
def MFnToggleManip_setLength(*args, **kwargs): pass
def MMaterial_swigregister(*args, **kwargs): pass
def delete_MSelectInfo(*args, **kwargs): pass
def delete_MExternalDropCallback(*args, **kwargs): pass
def MDrawRequest_view(*args, **kwargs): pass
def M3dView_hiliteColor(*args, **kwargs): pass
def delete_MCursor(*args, **kwargs): pass
def MDrawRequest_setDisplayStyle(*args, **kwargs): pass
def MExternalDropData_hasImage(*args, **kwargs): pass
def new_MFnCurveSegmentManip(*args, **kwargs): pass
def MFnFreePointTriadManip_create(*args, **kwargs): pass
def delete_MFnScaleManip(*args, **kwargs): pass
def MGraphEditorInfo_isNormalizedViewportMode(*args, **kwargs): pass
def MMaterialArray_swigregister(*args, **kwargs): pass
def MSelectInfo_selectPath(*args, **kwargs): pass
def MFnScaleManip_connectToScaleCenterPlug(*args, **kwargs): pass
def M3dView_displayStatus(*args, **kwargs): pass
def M3dView_projectionMatrix(*args, **kwargs): pass
def MDeviceState_devicePosition(*args, **kwargs): pass
def delete_MDrawRequestQueue(*args, **kwargs): pass
def new_MFeedbackLine(*args, **kwargs): pass
def new_MFnDirectionManip(*args, **kwargs): pass
def MFnCircleSweepManip_setNormal(*args, **kwargs): pass
def MFnPointOnCurveManip_className(*args, **kwargs): pass
def MFnScaleManip_scaleIndex(*args, **kwargs): pass
def MToolsInfo_swigregister(*args, **kwargs): pass
def MDrawRequestQueue_add(*args, **kwargs): pass
def intPtr_swigregister(*args, **kwargs): pass
def M3dView_viewport(*args, **kwargs): pass
def M3dView_getRendererName(*args, **kwargs): pass
def MDrawInfo_view(*args, **kwargs): pass
def MDrawTraversal_frustumValid(*args, **kwargs): pass
def MUiMessage_addCameraChangedCallback(*args, **kwargs): pass
def MFnDiscManip_create(*args, **kwargs): pass
def MFnPointOnSurfaceManip_className(*args, **kwargs): pass
def MFnStateManip_swigregister(*args, **kwargs): pass
def MMaterial_evaluateSpecular(*args, **kwargs): pass
def MQtUtil_createIcon(*args, **kwargs): pass
def new_MPaintMessage(*args, **kwargs): pass
def delete_doublePtr(*args, **kwargs): pass
def M3dView_numActiveColors(*args, **kwargs): pass
def M3dView_multipleDrawEnabled(*args, **kwargs): pass
def M3dView_backgroundColorBottom(*args, **kwargs): pass
def new_MDrawRequest(*args, **kwargs): pass
def MEvent_modifiers(*args, **kwargs): pass
def MFnCircleSweepManip_setStartPoint(*args, **kwargs): pass
def MFnDistanceManip_setStartPoint(*args, **kwargs): pass
def new_MFnRotateManip(*args, **kwargs): pass
def MFnToggleManip_setDirection(*args, **kwargs): pass
def MMaterial_getTextureTransformation(*args, **kwargs): pass
def new_MSelectInfo(*args, **kwargs): pass
def new_MExternalDropCallback(*args, **kwargs): pass
def M3dView_widget(*args, **kwargs): pass
def uIntPtr_value(*args, **kwargs): pass
def M3dView_leadColor(*args, **kwargs): pass
def new_MCursor(*args, **kwargs): pass
def MDrawRequest_displayStyle(*args, **kwargs): pass
def MDrawRequestQueue_assign(*args, **kwargs): pass
def MExternalDropData_color(*args, **kwargs): pass
def new_MFnFreePointTriadManip(*args, **kwargs): pass
def MFnScaleManip_type(*args, **kwargs): pass
def MGraphEditorInfo_isStackedViewportMode(*args, **kwargs): pass
def MSelectInfo_setSnapPoint(*args, **kwargs): pass
def M3dView_get3dView(*args, **kwargs): pass
def M3dView_worldToView(*args, **kwargs): pass
def delete_MDeviceState(*args, **kwargs): pass
def MDrawRequest_swigregister(*args, **kwargs): pass
def MFeedbackLine_className(*args, **kwargs): pass
def MFnDirectionManip_className(*args, **kwargs): pass
def delete_MFnPointOnCurveManip(*args, **kwargs): pass
def MDrawTraversal_setPerspFrustum(*args, **kwargs): pass
def MFnScaleManip_getOrientationMode(*args, **kwargs): pass
def MFnRotateManip_setRotateMode(*args, **kwargs): pass
def MProgressWindow_progressStatus(*args, **kwargs): pass
def M3dView_setColorMask(*args, **kwargs): pass
def intPtr_frompointer(*args, **kwargs): pass
def delete_MFnStateManip(*args, **kwargs): pass
def M3dView_popViewport(*args, **kwargs): pass
def M3dView_pluginObjectDisplay(*args, **kwargs): pass
def MDrawInfo_getPrototype(*args, **kwargs): pass
def MDrawTraversal_setFrustum(*args, **kwargs): pass
def MFnManip3D_setGlobalSize(*args, **kwargs): pass
def new_MFnDiscManip(*args, **kwargs): pass
def delete_MFnPointOnSurfaceManip(*args, **kwargs): pass
def MFnStateManip_stateIndex(*args, **kwargs): pass
def MMaterial_evaluateEmission(*args, **kwargs): pass
def MQtUtil_createCursor(*args, **kwargs): pass
def MPaintMessage_className(*args, **kwargs): pass
def new_doublePtr(*args, **kwargs): pass
def M3dView_numDormantColors(*args, **kwargs): pass
def MQtUtil_swigregister(*args, **kwargs): pass
def M3dView_updateViewingParameters(*args, **kwargs): pass
def MDrawInfo_swigregister(*args, **kwargs): pass
def MEvent_isModifierKeyRelease(*args, **kwargs): pass
def MFnCircleSweepManip_setCenterPoint(*args, **kwargs): pass
def MFnDistanceManip_connectToDistancePlug(*args, **kwargs): pass
def MFnRotateManip_className(*args, **kwargs): pass
def MFnToggleManip_setStartPoint(*args, **kwargs): pass
def MMaterial_evaluateTextureTransformation(*args, **kwargs): pass
def MObjectListFilter_swigregister(*args, **kwargs): pass
def M3dView_isBackgroundGradient(*args, **kwargs): pass
def uIntPtr_assign(*args, **kwargs): pass
def M3dView_activeTemplateColor(*args, **kwargs): pass
def delete_MFnCurveSegmentManip(*args, **kwargs): pass
def MFnRotateManip_swigregister(*args, **kwargs): pass
def MGraphEditorInfo_getAnimCurveNodes(*args, **kwargs): pass
def MMaterialArray_sizeIncrement(*args, **kwargs): pass
def MSelectInfo_addSelection(*args, **kwargs): pass
def MPaintMessage_addVertexColorCallback(*args, **kwargs): pass
def MFeedbackLine_setShowFeedback(*args, **kwargs): pass
def delete_MFnDirectionManip(*args, **kwargs): pass
def MFnPointOnCurveManip_type(*args, **kwargs): pass
def MFnScaleManip_setOrientationMode(*args, **kwargs): pass
def MDeviceChannel_hasChildren(*args, **kwargs): pass
def MManipData_assign(*args, **kwargs): pass
def MProgressWindow_setProgressStatus(*args, **kwargs): pass
def delete_MToolsInfo(*args, **kwargs): pass
def MFnManip3D_isVisible(*args, **kwargs): pass
def MDrawRequest_setComponent(*args, **kwargs): pass
def intPtr_cast(*args, **kwargs): pass
def M3dView_pushViewport(*args, **kwargs): pass
def delete_MDrawInfo(*args, **kwargs): pass
def MFnManip3D_globalSize(*args, **kwargs): pass
def MFnDiscManip_className(*args, **kwargs): pass
def MFnFreePointTriadManip_className(*args, **kwargs): pass
def MFnStateManip_positionIndex(*args, **kwargs): pass
def MMaterial_evaluateDiffuse(*args, **kwargs): pass
def MQtUtil_createPixmap(*args, **kwargs): pass
def floatPtr_swigregister(*args, **kwargs): pass
def M3dView_setDrawColorAndAlpha(*args, **kwargs): pass
def M3dView_disallowPolygonOffset(*args, **kwargs): pass
def MDrawInfo_className(*args, **kwargs): pass
def MEvent_mouseButton(*args, **kwargs): pass
def MFnDistanceManip_create(*args, **kwargs): pass
def MFnToggleManip_toggleIndex(*args, **kwargs): pass
def MMaterial_className(*args, **kwargs): pass
def delete_MQtUtil(*args, **kwargs): pass
def MObjectListFilter_className(*args, **kwargs): pass
def MEvent_className(*args, **kwargs): pass
def delete_uIntPtr(*args, **kwargs): pass
def M3dView_referenceLayerColor(*args, **kwargs): pass
def M3dView_className(*args, **kwargs): pass
def MDrawRequest_displayCullOpposite(*args, **kwargs): pass
def MExternalDropData_html(*args, **kwargs): pass
def MFnCurveSegmentManip_type(*args, **kwargs): pass
def delete_MFnFreePointTriadManip(*args, **kwargs): pass
def MFnRotateManip_setRotationCenter(*args, **kwargs): pass
def MGraphEditorInfo_setViewportBounds(*args, **kwargs): pass
def MExternalDropCallback_externalDropCallback(*args, **kwargs): pass
def MMaterialArray_setSizeIncrement(*args, **kwargs): pass
def MSelectInfo_setHighestPriority(*args, **kwargs): pass
def M3dView_active3dView(*args, **kwargs): pass
def M3dView_viewToWorld(*args, **kwargs): pass
def MDeviceChannel_numChildren(*args, **kwargs): pass
def MDrawRequest_assign(*args, **kwargs): pass
def MFeedbackLine_showFeedback(*args, **kwargs): pass
def MFnDirectionManip_type(*args, **kwargs): pass
def M3dView_setDisplayStyle(*args, **kwargs): pass
def MFnFreePointTriadManip_swigregister(*args, **kwargs): pass
def MFnScaleManip_getOrientation(*args, **kwargs): pass
def new_MManipData(*args, **kwargs): pass
def MDrawInfo_displayStyle(*args, **kwargs): pass
def MProgressWindow_title(*args, **kwargs): pass
def new_MToolsInfo(*args, **kwargs): pass
def MDeviceChannel_swigregister(*args, **kwargs): pass
def MFnCircleSweepManip_endPoint(*args, **kwargs): pass
def M3dView_playblastPortHeight(*args, **kwargs): pass
def M3dView_objectDisplay(*args, **kwargs): pass
def new_MDrawInfo(*args, **kwargs): pass
def MDrawTraversal_setOrthoFrustum(*args, **kwargs): pass
def MFnManip3D_setOptimizePlayback(*args, **kwargs): pass
def delete_MFnDiscManip(*args, **kwargs): pass
def MFnPointOnCurveManip_swigregister(*args, **kwargs): pass
def MMaterial_evaluateShininess(*args, **kwargs): pass
def MQtUtil_getCurrentParent(*args, **kwargs): pass
def MUiMessage_swigregister(*args, **kwargs): pass
def floatPtr_frompointer(*args, **kwargs): pass
def M3dView_setDrawColor(*args, **kwargs): pass
def M3dView_setDisallowPolygonOffset(*args, **kwargs): pass
def MDrawInfo_canDrawComponent(*args, **kwargs): pass
def MEvent_getWindowPosition(*args, **kwargs): pass
def MFnCircleSweepManip_create(*args, **kwargs): pass
def new_MFnDistanceManip(*args, **kwargs): pass
def MFnRotateManip_type(*args, **kwargs): pass
def MFnToggleManip_lengthIndex(*args, **kwargs): pass
def MMaterial_shadingEngine(*args, **kwargs): pass
def new_MQtUtil(*args, **kwargs): pass
def MObjectListFilter_deregisterFilter(*args, **kwargs): pass
def MFnDirectionManip_setDirection(*args, **kwargs): pass
def M3dView_liveColor(*args, **kwargs): pass
def M3dView_filteredObjectList(*args, **kwargs): pass
def MDrawRequest_setDisplayCulling(*args, **kwargs): pass
def delete_MFnToolContext(*args, **kwargs): pass
def MExternalDropData_hasHtml(*args, **kwargs): pass
def MFnCircleSweepManip_swigregister(*args, **kwargs): pass
def MFnFreePointTriadManip_type(*args, **kwargs): pass
def MFnRotateManip_rotationCenterIndex(*args, **kwargs): pass
def MGraphEditorInfo_getViewportBounds(*args, **kwargs): pass
def MMaterialArray_clear(*args, **kwargs): pass
def MSelectInfo_highestPriority(*args, **kwargs): pass
def delete_M3dView(*args, **kwargs): pass
def MQtUtil_nativeWindow(*args, **kwargs): pass
def M3dView_getLightIndex(*args, **kwargs): pass
def MDeviceChannel_childByIndex(*args, **kwargs): pass
def MDrawRequest_setMatrix(*args, **kwargs): pass
def MFeedbackLine_clear(*args, **kwargs): pass
def MFnCurveSegmentManip_swigregister(*args, **kwargs): pass
def MFnFreePointTriadManip_pointIndex(*args, **kwargs): pass
def MFnScaleManip_setOrientation(*args, **kwargs): pass
def delete_MManipData(*args, **kwargs): pass
def MProgressWindow_setTitle(*args, **kwargs): pass
def M3dView_display(*args, **kwargs): pass
def MToolsInfo_className(*args, **kwargs): pass
def charPtr_swigregister(*args, **kwargs): pass
def delete_uCharPtr(*args, **kwargs): pass
def intPtr_assign(*args, **kwargs): pass
def MDrawRequest_setDisplayStatus(*args, **kwargs): pass
def M3dView_setObjectDisplay(*args, **kwargs): pass
def MDrawData_swigregister(*args, **kwargs): pass
def MDrawTraversal_filterNode(*args, **kwargs): pass
def MFnManip3D_isOptimizePlaybackOn(*args, **kwargs): pass
def MFnDiscManip_type(*args, **kwargs): pass
def MFnPointOnCurveManip_paramIndex(*args, **kwargs): pass
def MFnStateManip_maxStates(*args, **kwargs): pass
def MMaterial_evaluateMaterial(*args, **kwargs): pass
def MQtUtil_fullName(*args, **kwargs): pass
def delete_MUiMessage(*args, **kwargs): pass
def floatPtr_cast(*args, **kwargs): pass
def M3dView_endXorDrawing(*args, **kwargs): pass
def M3dView_usingDefaultMaterial(*args, **kwargs): pass
def MDrawInfo_completelyInside(*args, **kwargs): pass
def MEvent_setPosition(*args, **kwargs): pass
def new_MFnCircleSweepManip(*args, **kwargs): pass
def MFnDistanceManip_className(*args, **kwargs): pass
def MFnPointOnSurfaceManip_swigregister(*args, **kwargs): pass
def MFnToggleManip_directionIndex(*args, **kwargs): pass
def MMaterial_defaultMaterial(*args, **kwargs): pass
def MQtUtil_className(*args, **kwargs): pass
def MObjectListFilter_registerFilter(*args, **kwargs): pass
def MFnCircleSweepManip_centerIndex(*args, **kwargs): pass
def boolPtr_swigregister(*args, **kwargs): pass
def MExternalDropData_hasUrls(*args, **kwargs): pass
def M3dView_viewIsFiltered(*args, **kwargs): pass
def MDrawRequest_displayCulling(*args, **kwargs): pass
def MExternalDropData_urls(*args, **kwargs): pass
def MFnCircleSweepManip_endCircleIndex(*args, **kwargs): pass
def MFnDistanceManip_swigregister(*args, **kwargs): pass
def MFnRotateManip_rotationIndex(*args, **kwargs): pass
def delete_MGraphEditorInfo(*args, **kwargs): pass
def MMaterialArray_copy(*args, **kwargs): pass
def MFnPointOnSurfaceManip_type(*args, **kwargs): pass
def M3dView_assign(*args, **kwargs): pass
def M3dView_isLightVisible(*args, **kwargs): pass
def MDeviceChannel_parent(*args, **kwargs): pass
def MDrawRequest_matrix(*args, **kwargs): pass
def MFeedbackLine_setValue(*args, **kwargs): pass
def MFnFreePointTriadManip_isKeyframeAllOn(*args, **kwargs): pass
def MFnScaleManip_snapIncrement(*args, **kwargs): pass
def MHWShaderSwatchGenerator_swigregister(*args, **kwargs): pass
def MProgressWindow_progress(*args, **kwargs): pass
def MToolsInfo_isDirty(*args, **kwargs): pass
def MExternalDropCallback_addCallback(*args, **kwargs): pass
def charPtr_frompointer(*args, **kwargs): pass
def delete_intPtr(*args, **kwargs): pass
def M3dView_isVisible(*args, **kwargs): pass
def MFnCircleSweepManip_startCircleIndex(*args, **kwargs): pass
def MDrawData_className(*args, **kwargs): pass
def MDrawTraversal_traverse(*args, **kwargs): pass
def MFnManip3D_setManipScale(*args, **kwargs): pass
def MFnDirectionManip_swigregister(*args, **kwargs): pass
def MFnPointOnCurveManip_curveIndex(*args, **kwargs): pass
def MFnStateManip_setMaxStates(*args, **kwargs): pass
def delete_MMaterial(*args, **kwargs): pass
def MQtUtil_findWindow(*args, **kwargs): pass
def new_MUiMessage(*args, **kwargs): pass
def uCharPtr_cast(*args, **kwargs): pass
def floatPtr_value(*args, **kwargs): pass
def M3dView_beginXorDrawing(*args, **kwargs): pass
def M3dView_usingMipmappedTextures(*args, **kwargs): pass
def MDrawInfo_userChangingViewContext(*args, **kwargs): pass
def MFnCircleSweepManip_className(*args, **kwargs): pass
def delete_MFnDistanceManip(*args, **kwargs): pass
def MFnPointOnSurfaceManip_paramIndex(*args, **kwargs): pass
def MFnToggleManip_startPointIndex(*args, **kwargs): pass
def MMaterial_getHwShaderNode(*args, **kwargs): pass
def M3dView_showObjectFilterNameInHUD(*args, **kwargs): pass
def MQtUtil_dpiScale(*args, **kwargs): pass
def MObjectListFilter_setUIName(*args, **kwargs): pass
def boolPtr_frompointer(*args, **kwargs): pass
def M3dView_backgroundColorTop(*args, **kwargs): pass
def MExternalDropCallback_swigregister(*args, **kwargs): pass
def MFnDistanceManip_currentPointIndex(*args, **kwargs): pass
def MFnRotateManip_snapIncrement(*args, **kwargs): pass
def new_MGraphEditorInfo(*args, **kwargs): pass
def MMaterialArray_append(*args, **kwargs): pass
def MSelectInfo_selectForHilite(*args, **kwargs): pass
def new_M3dView(*args, **kwargs): pass
def MFeedbackLine_setTitle(*args, **kwargs): pass
def MFnCurveSegmentManip_startParamIndex(*args, **kwargs): pass
def MFnFreePointTriadManip_isSnapModeOn(*args, **kwargs): pass
def MFnScaleManip_setSnapIncrement(*args, **kwargs): pass
def delete_MHWShaderSwatchGenerator(*args, **kwargs): pass
def MProgressWindow_advanceProgress(*args, **kwargs): pass
def MToolsInfo_resetDirtyFlag(*args, **kwargs): pass
def charPtr_cast(*args, **kwargs): pass
def M3dView_portWidth(*args, **kwargs): pass
def MDrawRequest_setDisplayCullOpposite(*args, **kwargs): pass
def delete_MDrawTraversal(*args, **kwargs): pass
def MFnManip3D_manipScale(*args, **kwargs): pass
def MFnDirectionManip_directionIndex(*args, **kwargs): pass
def MManipData_asUnsigned(*args, **kwargs): pass
def MFnStateManip_setInitialState(*args, **kwargs): pass
def new_MMaterial(*args, **kwargs): pass
def MQtUtil_findMenuItem(*args, **kwargs): pass
def MUiMessage_className(*args, **kwargs): pass
def floatPtr_assign(*args, **kwargs): pass
def M3dView_initNames(*args, **kwargs): pass
def M3dView_readBufferTo2dTexture(*args, **kwargs): pass
def MDrawInfo_inUserInteraction(*args, **kwargs): pass
def delete_MEvent(*args, **kwargs): pass
def delete_MFnCircleSweepManip(*args, **kwargs): pass
def MFnDistanceManip_type(*args, **kwargs): pass
def MFnPointOnSurfaceManip_surfaceIndex(*args, **kwargs): pass
def MFnToggleManip_toggle(*args, **kwargs): pass
def MMaterial_textureImage(*args, **kwargs): pass
def MQtUtil_toQString(*args, **kwargs): pass
def MObjectListFilter_UIname(*args, **kwargs): pass
def boolPtr_cast(*args, **kwargs): pass
def M3dView_backgroundColor(*args, **kwargs): pass
def M3dView_setShowObjectFilterNameInHUD(*args, **kwargs): pass
def MExternalDropData_hasColor(*args, **kwargs): pass
def MExternalDropData_text(*args, **kwargs): pass
def MFnCircleSweepManip_angleIndex(*args, **kwargs): pass
def MFnDistanceManip_startPointIndex(*args, **kwargs): pass
def MFnRotateManip_setSnapIncrement(*args, **kwargs): pass
def MFnToolContext_swigregister(*args, **kwargs): pass
def MMaterialArray_insert(*args, **kwargs): pass
def MSelectInfo_getLocalRay(*args, **kwargs): pass
def uCharPtr_swigregister(*args, **kwargs): pass
def M3dView_getLightingMode(*args, **kwargs): pass
def MDeviceChannel_axisIndex(*args, **kwargs): pass
def MDrawRequest_token(*args, **kwargs): pass
def MFeedbackLine_setFormat(*args, **kwargs): pass
def MFnCurveSegmentManip_curveIndex(*args, **kwargs): pass
def MFnFreePointTriadManip_isDrawAxesOn(*args, **kwargs): pass
def MFnScaleManip_isSnapModeOn(*args, **kwargs): pass
def MHWShaderSwatchGenerator_doIteration(*args, **kwargs): pass
def MProgressWindow_setProgress(*args, **kwargs): pass
def MToolsInfo_setDirtyFlag(*args, **kwargs): pass
def charPtr_value(*args, **kwargs): pass
def M3dView_wireframeOnlyInShadedMode(*args, **kwargs): pass
def M3dView_displayStyle(*args, **kwargs): pass
def delete_MDrawData(*args, **kwargs): pass
def M3dView_drawText(*args, **kwargs): pass
def MFnManip3D_setVisible(*args, **kwargs): pass
def MFnDirectionManip_endPointIndex(*args, **kwargs): pass
def MFnPointOnCurveManip_parameter(*args, **kwargs): pass
def MFnStateManip_connectToStatePlug(*args, **kwargs): pass
def MManipData_swigregister(*args, **kwargs): pass
def MQtUtil_findLayout(*args, **kwargs): pass
def MUiMessage_add3dViewRenderOverrideChangedCallback(*args, **kwargs): pass
def delete_floatPtr(*args, **kwargs): pass
def M3dView_popName(*args, **kwargs): pass
def M3dView_readDepthMap(*args, **kwargs): pass
def MDrawInfo_inSelect(*args, **kwargs): pass
def new_MEvent(*args, **kwargs): pass
def MFnCircleSweepManip_type(*args, **kwargs): pass
def MFnDiscManip_swigregister(*args, **kwargs): pass
def MFnPointOnSurfaceManip_isDrawSurfaceOn(*args, **kwargs): pass
def MFnToggleManip_length(*args, **kwargs): pass
def MMaterial_applyTexture(*args, **kwargs): pass
def MQtUtil_toMString(*args, **kwargs): pass
def MObjectListFilter_name(*args, **kwargs): pass
def MProgressWindow_swigregister(*args, **kwargs): pass
def boolPtr_value(*args, **kwargs): pass
def M3dView_templateColor(*args, **kwargs): pass
def M3dView_objectListFilterName(*args, **kwargs): pass
def MDrawRequest_setDrawData(*args, **kwargs): pass
def MDrawTraversal_setLeafLevelCulling(*args, **kwargs): pass
def MFnCircleSweepManip_axisIndex(*args, **kwargs): pass
def MFnDistanceManip_directionIndex(*args, **kwargs): pass
def MFnRotateManip_isSnapModeOn(*args, **kwargs): pass
def MFnToolContext_title(*args, **kwargs): pass
def MMaterialArray_remove(*args, **kwargs): pass
def MSelectInfo_getAlignmentMatrix(*args, **kwargs): pass
def uIntPtr_cast(*args, **kwargs): pass
def uCharPtr_frompointer(*args, **kwargs): pass
def M3dView_getLightCount(*args, **kwargs): pass
def MDeviceChannel_longName(*args, **kwargs): pass
def MDrawRequest_setDrawLast(*args, **kwargs): pass
def MExternalDropData_swigregister(*args, **kwargs): pass
def MFnCurveSegmentManip_endParameter(*args, **kwargs): pass
def MFnFreePointTriadManip_setDirection(*args, **kwargs): pass
def MFnScaleManip_setSnapMode(*args, **kwargs): pass
def MHWShaderSwatchGenerator_getSwatchBackgroundColor(*args, **kwargs): pass
def MProgressWindow_progressMax(*args, **kwargs): pass
def MTextureEditorDrawInfo_swigregister(*args, **kwargs): pass
def charPtr_assign(*args, **kwargs): pass
def MDrawData_geometry(*args, **kwargs): pass
def MEvent_getPosition(*args, **kwargs): pass
def new_MDrawData(*args, **kwargs): pass
def MDrawRequestQueue_swigregister(*args, **kwargs): pass
def MDrawRequest_setColor(*args, **kwargs): pass
def MFnDirectionManip_startPointIndex(*args, **kwargs): pass
def MFnPointOnCurveManip_isDrawCurveOn(*args, **kwargs): pass
def MFnStateManip_create(*args, **kwargs): pass
def MManipData_className(*args, **kwargs): pass
def MQtUtil_findControl(*args, **kwargs): pass
def MUiMessage_add3dViewRendererChangedCallback(*args, **kwargs): pass
def new_floatPtr(*args, **kwargs): pass
def M3dView_pushName(*args, **kwargs): pass
def M3dView_writeColorBuffer(*args, **kwargs): pass
def MDrawInfo_pluginObjectDisplayStatus(*args, **kwargs): pass
def MDrawTraversal_swigregister(*args, **kwargs): pass
def MFnManip3D_swigregister(*args, **kwargs): pass
def MFnDiscManip_angleIndex(*args, **kwargs): pass
def MFnPointOnSurfaceManip_getParameters(*args, **kwargs): pass
def MFnToggleManip_direction(*args, **kwargs): pass
def MMaterial_getHasTransparency(*args, **kwargs): pass
def MFnPointOnCurveManip_curvePoint(*args, **kwargs): pass
def MObjectListFilter_filterType(*args, **kwargs): pass
def new_intPtr(*args, **kwargs): pass
def boolPtr_assign(*args, **kwargs): pass
def M3dView_setObjectListFilterName(*args, **kwargs): pass
def MDrawRequest_drawData(*args, **kwargs): pass
def MEvent_swigregister(*args, **kwargs): pass
def MExternalDropData_formats(*args, **kwargs): pass
def MFnDistanceManip_distanceIndex(*args, **kwargs): pass
def MFnRotateManip_setSnapMode(*args, **kwargs): pass
def MFnToolContext_name(*args, **kwargs): pass
def MMaterialArray_length(*args, **kwargs): pass
def MSelectInfo_isRay(*args, **kwargs): pass
def MMaterialArray___getitem__(*args, **kwargs): pass
def delete_MFnRotateManip(*args, **kwargs): pass
def M3dView_refresh(*args, **kwargs): pass
def MDeviceChannel_name(*args, **kwargs): pass
def MDrawRequest_drawLast(*args, **kwargs): pass
def SWIG_PyInstanceMethod_New(*args, **kwargs): pass
def delete_MExternalDropData(*args, **kwargs): pass
def MFnCurveSegmentManip_startParameter(*args, **kwargs): pass
def MFnFreePointTriadManip_setPoint(*args, **kwargs): pass
def MFnScaleManip_displayWithNode(*args, **kwargs): pass
def intPtr_value(*args, **kwargs): pass
def MHWShaderSwatchGenerator_initialize(*args, **kwargs): pass
def MProgressWindow_progressMin(*args, **kwargs): pass
def MTextureEditorDrawInfo_className(*args, **kwargs): pass
def delete_charPtr(*args, **kwargs): pass
def M3dView_window(*args, **kwargs): pass
def M3dView_getM3dViewFromModelEditor(*args, **kwargs): pass
def MDrawRequestQueue_className(*args, **kwargs): pass
def new_MFnManip3D(*args, **kwargs): pass
def M3dView_scheduleRefresh(*args, **kwargs): pass
def MFnPointOnCurveManip_setParameter(*args, **kwargs): pass
def new_MFnStateManip(*args, **kwargs): pass
def MManipData_asMObject(*args, **kwargs): pass
def MUiMessage_add3dViewPostMultipleDrawPassMsgCallback(*args, **kwargs): pass
def shortPtr_swigregister(*args, **kwargs): pass
def M3dView_loadName(*args, **kwargs): pass
def M3dView_readColorBuffer(*args, **kwargs): pass
def MDrawInfo_objectDisplayStatus(*args, **kwargs): pass
def MDrawTraversal_itemHasStatus(*args, **kwargs): pass
def MFnManip3D_rotateXYZValue(*args, **kwargs): pass
def MFnPointOnSurfaceManip_setParameters(*args, **kwargs): pass
def MFnToggleManip_startPoint(*args, **kwargs): pass
def MMaterial_getSpecular(*args, **kwargs): pass
def MQtUtil_resourceGLContext(*args, **kwargs): pass
def MObjectListFilter_setFilterType(*args, **kwargs): pass
def delete_boolPtr(*args, **kwargs): pass
def M3dView_renderOverrideName(*args, **kwargs): pass
def MFnDistanceManip_scalingFactor(*args, **kwargs): pass
def MExternalDropData_dataSize(*args, **kwargs): pass
def MFnRotateManip_rotateMode(*args, **kwargs): pass
def new_MFnToolContext(*args, **kwargs): pass
def MMaterialArray_setLength(*args, **kwargs): pass
def MSelectInfo_selectRect(*args, **kwargs): pass
def uCharPtr_value(*args, **kwargs): pass
def MFnStateManip_state(*args, **kwargs): pass
def delete_MDeviceChannel(*args, **kwargs): pass
def MDrawRequest_setIsTransparent(*args, **kwargs): pass
def MFnCurveSegmentManip_setEndParameter(*args, **kwargs): pass
def MFnFreePointTriadManip_setGlobalTriadPlane(*args, **kwargs): pass
def MManipData_asBool(*args, **kwargs): pass
def MFnScaleManip_setInitialScale(*args, **kwargs): pass
def MHWShaderSwatchGenerator_createObj(*args, **kwargs): pass
def MProgressWindow_setProgressMax(*args, **kwargs): pass
def new_charPtr(*args, **kwargs): pass
def shortPtr_cast(*args, **kwargs): pass
def MFnCurveSegmentManip_className(*args, **kwargs): pass
def M3dView_getM3dViewFromModelPanel(*args, **kwargs): pass
def MDeviceState_swigregister(*args, **kwargs): pass
def MFnManip3D_className(*args, **kwargs): pass
def MFnDirectionManip_setStartPoint(*args, **kwargs): pass
def MFnStateManip_className(*args, **kwargs): pass
def MManipData_asDouble(*args, **kwargs): pass
def delete_MProgressWindow(*args, **kwargs): pass
def MUiMessage_add3dViewPreMultipleDrawPassMsgCallback(*args, **kwargs): pass
def shortPtr_frompointer(*args, **kwargs): pass
def M3dView_textureMode(*args, **kwargs): pass
def M3dView_twoSidedLighting(*args, **kwargs): pass
def MDrawTraversal_itemPath(*args, **kwargs): pass
def MFnManip3D_setDrawPlaneHandles(*args, **kwargs): pass
def MFnDiscManip_centerIndex(*args, **kwargs): pass
def MFnPointOnSurfaceManip_setDrawArrows(*args, **kwargs): pass
def MFnToggleManip_connectToTogglePlug(*args, **kwargs): pass
def MMaterial_getEmission(*args, **kwargs): pass
def MQtUtil_mainWindow(*args, **kwargs): pass
def MObjectListFilter_dependentOnSceneUpdates(*args, **kwargs): pass
def new_boolPtr(*args, **kwargs): pass
def MDrawRequest_displayStatus(*args, **kwargs): pass
def M3dView_colorMask(*args, **kwargs): pass
def M3dView_setRenderOverrideName(*args, **kwargs): pass
def MDrawRequest_component(*args, **kwargs): pass
def MEvent_isModifierMiddleMouseButton(*args, **kwargs): pass
def MFnCircleSweepManip_startPoint(*args, **kwargs): pass
def MFnDistanceManip_isDrawLineOn(*args, **kwargs): pass
def MExternalDropData_keyboardModifiers(*args, **kwargs): pass
def MFnToolContext_className(*args, **kwargs): pass
def MMaterialArray_set(*args, **kwargs): pass
def MSelectInfo_selectableComponent(*args, **kwargs): pass
def MFnManip3D_handleSize(*args, **kwargs): pass
def uCharPtr_assign(*args, **kwargs): pass
def M3dView_scheduleRefreshAllViews(*args, **kwargs): pass
def new_MDeviceChannel(*args, **kwargs): pass
def MDrawRequest_isTransparent(*args, **kwargs): pass
def MExternalDropData_mouseButtons(*args, **kwargs): pass
def MFnCurveSegmentManip_setStartParameter(*args, **kwargs): pass
def MFnFreePointTriadManip_setDrawArrowHead(*args, **kwargs): pass
def new_MHWShaderSwatchGenerator(*args, **kwargs): pass
def MProgressWindow_setProgressMin(*args, **kwargs): pass
def MTextureEditorDrawInfo_drawingFunction(*args, **kwargs): pass
def M3dView_getScreenPosition(*args, **kwargs): pass
def M3dView_setPluginObjectDisplay(*args, **kwargs): pass
def M3dView_setShowViewSelectedChildren(*args, **kwargs): pass
def MDeviceState_isNull(*args, **kwargs): pass
def MFnDirectionManip_setDrawStart(*args, **kwargs): pass
def MFnPointOnCurveManip_connectToParamPlug(*args, **kwargs): pass
def M3dView_getLightPath(*args, **kwargs): pass
def MManipData_asFloat(*args, **kwargs): pass
def new_MProgressWindow(*args, **kwargs): pass
def MUiMessage_add3dViewPostRenderMsgCallback(*args, **kwargs): pass
def MProgressWindow_isCancelled(*args, **kwargs): pass
def M3dView_selectMode(*args, **kwargs): pass
def M3dView_xrayJoints(*args, **kwargs): pass
def MDrawTraversal_numberOfItems(*args, **kwargs): pass
def MTextureEditorDrawInfo_setDrawingFunction(*args, **kwargs): pass
def MFnManip3D_drawPlaneHandles(*args, **kwargs): pass
def MFnDiscManip_setAngle(*args, **kwargs): pass
def MFnPointOnSurfaceManip_setDrawSurface(*args, **kwargs): pass
def MFnToggleManip_create(*args, **kwargs): pass
def MMaterial_getDiffuse(*args, **kwargs): pass
def MQtUtil_deregisterUIType(*args, **kwargs): pass
def MObjectListFilter_getList(*args, **kwargs): pass
def new_uIntPtr(*args, **kwargs): pass
def doublePtr_swigregister(*args, **kwargs): pass
def M3dView_getColorIndexAndTable(*args, **kwargs): pass
def M3dView_endProjMatrixOverride(*args, **kwargs): pass
def MDrawRequest_setMultiPath(*args, **kwargs): pass
def MEvent_isModifierLeftMouseButton(*args, **kwargs): pass
def MFnCircleSweepManip_setDrawAsArc(*args, **kwargs): pass
def MFnDistanceManip_isDrawStartOn(*args, **kwargs): pass
def MFnRotateManip_displayWithNode(*args, **kwargs): pass
def MFnDiscManip_axisIndex(*args, **kwargs): pass
def MMaterialArray_assign(*args, **kwargs): pass
def MSelectInfo_selectable(*args, **kwargs): pass
def disown_MExternalDropCallback(*args, **kwargs): pass
def M3dView_setCamera(*args, **kwargs): pass
def MCursor_swigregister(*args, **kwargs): pass
def MDrawRequest_setMaterial(*args, **kwargs): pass
def MFnCurveSegmentManip_connectToEndParamPlug(*args, **kwargs): pass
def MFnFreePointTriadManip_setKeyframeAll(*args, **kwargs): pass
def MFnScaleManip_connectToScalePlug(*args, **kwargs): pass
def MGraphEditorInfo_swigregister(*args, **kwargs): pass
def MProgressWindow_setProgressRange(*args, **kwargs): pass
def delete_MTextureEditorDrawInfo(*args, **kwargs): pass
def M3dView_applicationShell(*args, **kwargs): pass
def M3dView_showViewSelectedChildren(*args, **kwargs): pass
def M3dView_portHeight(*args, **kwargs): pass
def MDeviceState_maxAxis(*args, **kwargs): pass
def new_MDrawRequestQueue(*args, **kwargs): pass
def delete_MFnManip3D(*args, **kwargs): pass
def MFnPointOnCurveManip_connectToCurvePlug(*args, **kwargs): pass
def MFnStateManip_type(*args, **kwargs): pass
def MDrawRequest_setToken(*args, **kwargs): pass
def MFnPointOnCurveManip_setDrawCurve(*args, **kwargs): pass
def MProgressWindow_className(*args, **kwargs): pass
def MUiMessage_add3dViewPreRenderMsgCallback(*args, **kwargs): pass
def shortPtr_value(*args, **kwargs): pass
def M3dView_endSelect(*args, **kwargs): pass
def M3dView_xray(*args, **kwargs): pass
def MDrawInfo_inclusiveMatrix(*args, **kwargs): pass
def MDrawTraversal_filteringEnabled(*args, **kwargs): pass
def MFnManip3D_deleteManipulator(*args, **kwargs): pass
def MFnDiscManip_setRadius(*args, **kwargs): pass
def MFnPointOnSurfaceManip_connectToParamPlug(*args, **kwargs): pass
def new_MFnToggleManip(*args, **kwargs): pass
def MQtUtil_registerUIType(*args, **kwargs): pass
def MObjectListFilter_requireListUpdate(*args, **kwargs): pass
def doublePtr_frompointer(*args, **kwargs): pass
def M3dView_colorAtIndex(*args, **kwargs): pass
def M3dView_beginProjMatrixOverride(*args, **kwargs): pass
def MDrawRequest_multiPath(*args, **kwargs): pass
def MEvent_isModifierControl(*args, **kwargs): pass
def MFnCircleSweepManip_setAngle(*args, **kwargs): pass
def MFnDistanceManip_setScalingFactor(*args, **kwargs): pass
def MFnRotateManip_setInitialRotation(*args, **kwargs): pass
def MFnToolContext_type(*args, **kwargs): pass
def M3dView_numberOf3dViews(*args, **kwargs): pass
def MSelectInfo_selectClosest(*args, **kwargs): pass
def MExternalDropCallback_removeCallback(*args, **kwargs): pass
def new_uCharPtr(*args, **kwargs): pass
def M3dView_getCamera(*args, **kwargs): pass
def MCursor___ne__(*args, **kwargs): pass
def MDrawRequest_material(*args, **kwargs): pass
def MExternalDropData_hasFormat(*args, **kwargs): pass
def MFnCurveSegmentManip_connectToStartParamPlug(*args, **kwargs): pass
def MFnFreePointTriadManip_setSnapMode(*args, **kwargs): pass
def MFnScaleManip_create(*args, **kwargs): pass
def MGraphEditorInfo_className(*args, **kwargs): pass
def MProgressWindow_endProgress(*args, **kwargs): pass
def new_MTextureEditorDrawInfo(*args, **kwargs): pass
def MDrawInfo_displayStatus(*args, **kwargs): pass
def M3dView_deviceContext(*args, **kwargs): pass
def M3dView_setViewSelectedPrefix(*args, **kwargs): pass
def MDeviceState_setButtonState(*args, **kwargs): pass
def MEvent_isModifierNone(*args, **kwargs): pass
def MDrawRequestQueue_remove(*args, **kwargs): pass
def new_MDrawTraversal(*args, **kwargs): pass
def MFnManip3D_type(*args, **kwargs): pass
def MFnDirectionManip_setNormalizeDirection(*args, **kwargs): pass
def MMaterial_getShininess(*args, **kwargs): pass
def MFnScaleManip_swigregister(*args, **kwargs): pass
def MManipData_asLong(*args, **kwargs): pass
def M3dView_viewToObjectSpace(*args, **kwargs): pass
def MUiMessage_add3dViewDestroyMsgCallback(*args, **kwargs): pass
def shortPtr_assign(*args, **kwargs): pass
def M3dView_beginSelect(*args, **kwargs): pass
def M3dView_wireframeOnShaded(*args, **kwargs): pass
def MDrawInfo_projectionMatrix(*args, **kwargs): pass
def MDrawTraversal_enableFiltering(*args, **kwargs): pass
def MFnManip3D_setLineSize(*args, **kwargs): pass
def MFnDiscManip_setNormal(*args, **kwargs): pass
def MFnPointOnSurfaceManip_connectToSurfacePlug(*args, **kwargs): pass
def MFnToggleManip_className(*args, **kwargs): pass
def MMaterial_setMaterial(*args, **kwargs): pass
def MQtUtil_addWidgetToMayaLayout(*args, **kwargs): pass
def delete_MObjectListFilter(*args, **kwargs): pass
def doublePtr_cast(*args, **kwargs): pass
def M3dView_userDefinedColorIndex(*args, **kwargs): pass
def M3dView_setMultipleDrawPassCount(*args, **kwargs): pass
def MDrawRequest_setView(*args, **kwargs): pass
def MEvent_isModifierShift(*args, **kwargs): pass


M3dView_kDisplayParticleInstancers = 1024

M3dView_kDisplayGrid = 65536

M3dView_kDisplayManipulators = 268435456

M3dView_kExcludePluginShapes = -2147483648

M3dView_kDisplayLocators = 2048

M3dView_kDisplayHulls = 262144

M3dView_kDisplayCVs = 131072

M3dView_kDisplayJoints = 64

M3dView_kDisplayDynamicConstraints = 134217728

M3dView_kExcludeMotionTrails = 1073741824

M3dView_kDisplayImagePlane = 16777216

M3dView_kDisplayHairSystems = 8388608

M3dView_kDisplayFollicles = 4194304

M3dView_kDisplayFluids = 2097152

M3dView_kDisplayNRigids = 67108864

M3dView_kDisplayStrokes = 524288

MExternalDropData_kAltModifier = 134217728

M3dView_kExternalRenderer = 3

MExternalDropData_kShiftModifier = 33554432

M3dView_kDisplayDynamics = 512

M3dView_kDisplayNCloths = 33554432

M3dView_kDisplayPivots = 16384

M3dView_kCenter = 1

M3dView_kDisplayTextures = 32768

MMaterial_kReflectivity = 14

M3dView_kDisplayCameras = 32

MExternalDropData_kControlModifier = 67108864

M3dView_kDisplaySubdivSurfaces = 1048576

M3dView_kDisplayLights = 16

M3dView_kDisplaySelectHandles = 8192

MMaterial_kReflectedColor = 15

MMaterial_kSpecularColor = 13

cvar = None

MMaterial_kSpecularRollOff = 12

M3dView_kNoStatus = 11

M3dView_kActiveAffected = 10

M3dView_kDisplayDimensions = 4096

M3dView_kIntermediateObject = 9

M3dView_kDisplayPlanes = 8

M3dView_kActiveComponent = 7

M3dView_kActiveTemplate = 6

M3dView_kLightNone = 5

M3dView_kDisplayMeshes = 4

M3dView_kDisplayDeformers = 256

M3dView_kDisplayIkHandles = 128

M3dView_kDisplayNurbsSurfaces = 2

M3dView_kActive = 0

M3dView_kDisplayNParticles = 536870912

M3dView_kDisplayEverything = -1


