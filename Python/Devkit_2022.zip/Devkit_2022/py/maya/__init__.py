from pkgutil import extend_path


if False:
    from typing import Dict, List, Tuple, Union, Optional

stringTable = None


