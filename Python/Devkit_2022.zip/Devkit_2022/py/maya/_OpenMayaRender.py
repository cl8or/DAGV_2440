if False:
    from typing import Dict, List, Tuple, Union, Optional

def MGLFunctionTable_glBufferDataARB(*args, **kwargs): pass
def MRenderView_refresh(*args, **kwargs): pass
def MRenderShadowData_internalData_get(*args, **kwargs): pass
def MGLFunctionTable_glDeleteTextures(*args, **kwargs): pass
def MGLFunctionTable_glRects(*args, **kwargs): pass
def MHwrCallback_swigregister(*args, **kwargs): pass
def MGLFunctionTable_glEvalCoord2f(*args, **kwargs): pass
def MRenderData_resY_get(*args, **kwargs): pass
def MGLFunctionTable_glLightModelf(*args, **kwargs): pass
def MGLFunctionTable_glVertexAttrib2f(*args, **kwargs): pass
def MRenderSetup_getEnabledSelectedNodeNames(*args, **kwargs): pass
def MGLFunctionTable_glTexCoord3d(*args, **kwargs): pass
def MGLFunctionTable_glGetProgramiv(*args, **kwargs): pass
def MGLFunctionTable_glGetProgramParameterfvNV(*args, **kwargs): pass
def delete_MVaryingParameterList(*args, **kwargs): pass
def MHardwareRenderer_referenceDefaultGeometry(*args, **kwargs): pass
def MGLFunctionTable_glTexCoord3dv(*args, **kwargs): pass
def MHardwareRenderer_getSwatchPerspectiveCameraSetting(*args, **kwargs): pass
def floatPtr_assign(*args, **kwargs): pass
def MRenderingInfo_width(*args, **kwargs): pass
def MGeometryList_path(*args, **kwargs): pass
def MRenderUtil_eval2dTexture(*args, **kwargs): pass
def MGLFunctionTable_glGetTexLevelParameteriv(*args, **kwargs): pass
def MSwatchRenderBase_image(*args, **kwargs): pass
def MLightLinks_getIgnoredObjects(*args, **kwargs): pass
def MRenderUtil_noiseTableCubeSide(*args, **kwargs): pass
def MGLFunctionTable_glVertexAttrib3f(*args, **kwargs): pass
def charPtr_swigregister(*args, **kwargs): pass
def MGeometryLegacy_tangent(*args, **kwargs): pass
def MGLFunctionTable_glVertexAttrib4fNV(*args, **kwargs): pass
def MGLFunctionTable_glVertexAttrib3d(*args, **kwargs): pass
def MGLFunctionTable_glMultTransposeMatrixd(*args, **kwargs): pass
def MRenderTargetLegacy_makeTargetCurrent(*args, **kwargs): pass
def MGLFunctionTable_glColorFragmentOp2ATI(*args, **kwargs): pass
def MGLFunctionTable_glUniform4fARB(*args, **kwargs): pass
def MGLFunctionTable_glIsVariantEnabledEXT(*args, **kwargs): pass
def MGLFunctionTable_glPixelZoom(*args, **kwargs): pass
def MGLFunctionTable_glFlushVertexArrayRangeNV(*args, **kwargs): pass
def MGeometryData_elementCount(*args, **kwargs): pass
def MCommonRenderSettingsData_namingScheme_set(*args, **kwargs): pass
def MRenderShadowData_midDistMaps_get(*args, **kwargs): pass
def MUniformParameter_setKeyable(*args, **kwargs): pass
def MGLFunctionTable_glGetVariantBooleanvEXT(*args, **kwargs): pass
def MGLFunctionTable_glPixelMapfv(*args, **kwargs): pass
def MRenderUtil_relativeFileName(*args, **kwargs): pass
def MGLFunctionTable_glSwizzleEXT(*args, **kwargs): pass
def MGLFunctionTable_glRenderbufferStorageEXT(*args, **kwargs): pass
def delete_MRenderCallback(*args, **kwargs): pass
def MGLFunctionTable_glColor4f(*args, **kwargs): pass
def MGeometryLegacy_componentId(*args, **kwargs): pass
def MGLFunctionTable_glDetachObjectARB(*args, **kwargs): pass
def MGLFunctionTable_glBindTextureUnitParameterEXT(*args, **kwargs): pass
def MCommonRenderSettingsData_width_get(*args, **kwargs): pass
def MLightLinks_getIgnoredLights(*args, **kwargs): pass
def MGLFunctionTable_glDeleteObjectARB(*args, **kwargs): pass
def MGLFunctionTable_glMultiTexCoord2f(*args, **kwargs): pass
def uCharPtr_value(*args, **kwargs): pass
def MRenderData_fieldOfView_set(*args, **kwargs): pass
def new_MUniformParameter(*args, **kwargs): pass
def MGLFunctionTable_glMatrixMode(*args, **kwargs): pass
def MGLFunctionTable_glVertexAttribPointer(*args, **kwargs): pass
def MSwatchRenderRegister_registerSwatchRender(*args, **kwargs): pass
def MGLFunctionTable_glUniformMatrix4fvARB(*args, **kwargs): pass
def MRenderView_getRenderRegion(*args, **kwargs): pass
def MGLFunctionTable_glClearStencil(*args, **kwargs): pass
def MGLFunctionTable_glGetHandleARB(*args, **kwargs): pass
def MGLFunctionTable_glStencilFunc(*args, **kwargs): pass
def MGLFunctionTable_glGenSymbolsEXT(*args, **kwargs): pass
def boolPtr_value(*args, **kwargs): pass
def MFnRenderLayer_findLayerByName(*args, **kwargs): pass
def MGLFunctionTable_glEvalCoord1f(*args, **kwargs): pass
def MGLFunctionTable_glVertexPointer(*args, **kwargs): pass
def MD3D9Renderer_setBackgroundColor(*args, **kwargs): pass
def MGLFunctionTable_glVertexAttrib3fvNV(*args, **kwargs): pass
def MGLFunctionTable_glOrtho(*args, **kwargs): pass
def MGeometryManager_swigregister(*args, **kwargs): pass
def MGLFunctionTable_glVertexAttrib3sv(*args, **kwargs): pass
def MUniformParameter_setUINiceName(*args, **kwargs): pass
def MGLFunctionTable_glUniform2fARB(*args, **kwargs): pass
def MGLFunctionTable_extensionExists(*args, **kwargs): pass
def MVaryingParameter_removeElements(*args, **kwargs): pass
def MHardwareRenderer_removeDrawProcedure(*args, **kwargs): pass
def MGLFunctionTable_glReadPixels(*args, **kwargs): pass
def MGLFunctionTable_glFogCoordfEXT(*args, **kwargs): pass
def MHardwareRenderer_getTotalExposureCount(*args, **kwargs): pass
def MDrawProcedureBase_enabled(*args, **kwargs): pass
def MGLFunctionTable_glDepthMask(*args, **kwargs): pass
def MRenderUtil_generatingIprFile(*args, **kwargs): pass
def MGLFunctionTable_glColor3ui(*args, **kwargs): pass
def MGLFunctionTable_glVertex2sv(*args, **kwargs): pass
def shortPtr_frompointer(*args, **kwargs): pass
def MGLFunctionTable_glVertexAttrib2sNV(*args, **kwargs): pass
def delete_MRenderData(*args, **kwargs): pass
def MGeometryList_geometry(*args, **kwargs): pass
def MRenderView_updatePixels(*args, **kwargs): pass
def MGLFunctionTable_glInitNames(*args, **kwargs): pass
def MRenderingInfo_originX(*args, **kwargs): pass
def MGLFunctionTable_glVertexAttrib2s(*args, **kwargs): pass
def MCommonRenderSettingsData_width_set(*args, **kwargs): pass
def MGLFunctionTable_glMapBufferARB(*args, **kwargs): pass
def MGLFunctionTable_glVertexAttrib1dv(*args, **kwargs): pass
def MRenderUtil_className(*args, **kwargs): pass
def MGLFunctionTable_glPassTexCoordATI(*args, **kwargs): pass
def MGLFunctionTable_glColor3uiv(*args, **kwargs): pass
def MGLFunctionTable_glSecondaryColor3bEXT(*args, **kwargs): pass
def MGLFunctionTable_glEndTransformFeedbackEXT(*args, **kwargs): pass
def MCommonRenderSettingsData_preRenderMel_set(*args, **kwargs): pass
def MGLFunctionTable_glProgramParameter4dNV(*args, **kwargs): pass
def MGeometryLegacy_swigregister(*args, **kwargs): pass
def MGLFunctionTable_glTexImage1D(*args, **kwargs): pass
def charPtr_assign(*args, **kwargs): pass
def MGLFunctionTable_glGetVertexAttribdvNV(*args, **kwargs): pass
def MGeometryLegacy_normal(*args, **kwargs): pass
def MRenderData_ysize_get(*args, **kwargs): pass
def MGLFunctionTable_glGetTexLevelParameterfv(*args, **kwargs): pass
def MGLFunctionTable_glLoadIdentity(*args, **kwargs): pass
def MGLFunctionTable_glGetCompressedTexImage(*args, **kwargs): pass
def MCommonRenderSettingsData_frameEnd_get(*args, **kwargs): pass
def MRenderData_eyePoint_set(*args, **kwargs): pass
def MGLFunctionTable_glPrimitiveRestartNV(*args, **kwargs): pass
def MRenderUtil_sampleShadingNetwork(*args, **kwargs): pass
def MUniformParameter_setAsInt(*args, **kwargs): pass
def MRenderShadowData_lightPosition_set(*args, **kwargs): pass
def MGLFunctionTable_glPopClientAttrib(*args, **kwargs): pass
def RV_PIXEL_r_get(*args, **kwargs): pass
def MGLFunctionTable_glEndFragmentShaderATI(*args, **kwargs): pass
def MGLFunctionTable_glBlitFramebufferEXT(*args, **kwargs): pass
def MGLFunctionTable_glVertexAttrib3s(*args, **kwargs): pass
def delete_MViewportRenderer(*args, **kwargs): pass
def MGLFunctionTable_glColor3ubv(*args, **kwargs): pass
def MGLFunctionTable_glColor3usv(*args, **kwargs): pass
def MGLFunctionTable_glGetLocalConstantFloatvEXT(*args, **kwargs): pass
def uIntPtr_assign(*args, **kwargs): pass
def MGeometryData_dataType(*args, **kwargs): pass
def MGLFunctionTable_glGetMapdv(*args, **kwargs): pass
def MGLFunctionTable_glMultiTexCoord3sv(*args, **kwargs): pass
def MCommonRenderSettingsData_getPreRenderFrameCmd(*args, **kwargs): pass
def MGLFunctionTable_glCombinerParameteriNV(*args, **kwargs): pass
def MUniformParameter_setSoftRangeMax(*args, **kwargs): pass
def MGLFunctionTable_glFramebufferTexture1DEXT(*args, **kwargs): pass
def MGLFunctionTable_glNormal3sv(*args, **kwargs): pass
def MGLFunctionTable_glColor4b(*args, **kwargs): pass
def MGLFunctionTable_glProgramLocalParameter4f(*args, **kwargs): pass
def MGLFunctionTable_glIsRenderbufferEXT(*args, **kwargs): pass
def MGLFunctionTable_glBindTexture(*args, **kwargs): pass
def MHardwareRenderer_getBufferSize(*args, **kwargs): pass
def MGLFunctionTable_glTexCoord2f(*args, **kwargs): pass
def MGLFunctionTable_glDisableVariantClientStateEXT(*args, **kwargs): pass
def delete_MLightLinks(*args, **kwargs): pass
def MFnRenderPass_usesFiltering(*args, **kwargs): pass
def MGLFunctionTable_glDisableClientState(*args, **kwargs): pass
def MGLFunctionTable_glFogf(*args, **kwargs): pass
def MRenderUtil_renderPass(*args, **kwargs): pass
def MHwrCallback_addCallback(*args, **kwargs): pass
def MGLFunctionTable_glLoadName(*args, **kwargs): pass
def uIntPtr_swigregister(*args, **kwargs): pass
def MGLFunctionTable_glVertexAttribs3svNV(*args, **kwargs): pass
def MGLFunctionTable_glPixelTransferi(*args, **kwargs): pass
def MGeometryRequirementsLegacy_addBinormal(*args, **kwargs): pass
def MGLFunctionTable_glMaterialf(*args, **kwargs): pass
def MGLFunctionTable_glUniform3ivARB(*args, **kwargs): pass
def delete_RV_AOV(*args, **kwargs): pass
def MGLFunctionTable_glClearAccum(*args, **kwargs): pass
def RV_AOV_numberOfChannels_get(*args, **kwargs): pass
def MGLFunctionTable_glScalef(*args, **kwargs): pass
def MGLFunctionTable_glLogicOp(*args, **kwargs): pass
def MViewportRenderer_deregisterRenderer(*args, **kwargs): pass
def new_MHwrCallback(*args, **kwargs): pass
def MFnRenderLayer_adjustmentPlug(*args, **kwargs): pass
def MGLFunctionTable_glEnd(*args, **kwargs): pass
def MGLFunctionTable_glVertex4i(*args, **kwargs): pass
def MUniformParameter_setUIHidden(*args, **kwargs): pass
def MRenderShadowData_useMidDistMap_get(*args, **kwargs): pass
def MGLFunctionTable_glVertexAttrib2svNV(*args, **kwargs): pass
def new_MRenderProfile(*args, **kwargs): pass
def MCommonRenderSettingsData_postRenderMel_get(*args, **kwargs): pass
def MGLFunctionTable_glLineStipple(*args, **kwargs): pass
def MGLFunctionTable_glTexCoord4sv(*args, **kwargs): pass
def MGLFunctionTable_glEvalPoint1(*args, **kwargs): pass
def MGLFunctionTable_glLinkProgramARB(*args, **kwargs): pass
def MVaryingParameter_getMaximumStride(*args, **kwargs): pass
def MGLFunctionTable_glRasterPos4iv(*args, **kwargs): pass
def MGLFunctionTable_glSecondaryColor3uivEXT(*args, **kwargs): pass
def MViewportRenderer_overrideThenStandardExclusion(*args, **kwargs): pass
def MD3D9Renderer_swigregister(*args, **kwargs): pass
def MGLFunctionTable_glCullFace(*args, **kwargs): pass
def MGLFunctionTable_glVertex2fv(*args, **kwargs): pass
def delete_shortPtr(*args, **kwargs): pass
def MGLFunctionTable_glTexCoordPointer(*args, **kwargs): pass
def MGLFunctionTable_glVertexAttribPointerNV(*args, **kwargs): pass
def new_uCharPtr(*args, **kwargs): pass
def MGeometryList_length(*args, **kwargs): pass
def MGLFunctionTable_glIndexs(*args, **kwargs): pass
def MGLFunctionTable_glMultTransposeMatrixdARB(*args, **kwargs): pass
def MCommonRenderSettingsData_renumberStart_set(*args, **kwargs): pass
def MGLFunctionTable_glIsBufferARB(*args, **kwargs): pass
def MCommonRenderSettingsData_height_get(*args, **kwargs): pass
def MGLFunctionTable_glRasterPos2iv(*args, **kwargs): pass
def MGeometryRequirementsLegacy_addPosition(*args, **kwargs): pass
def MGLFunctionTable_glVertexAttrib4bv(*args, **kwargs): pass
def MUniformParameterList_assign(*args, **kwargs): pass
def MGLFunctionTable_glBeginTransformFeedbackEXT(*args, **kwargs): pass
def MCommonRenderSettingsData_preRenderLayerMel_set(*args, **kwargs): pass
def MGLFunctionTable_glColor4iv(*args, **kwargs): pass
def MGLFunctionTable_glTexGenf(*args, **kwargs): pass
def MGLFunctionTable_glDisable(*args, **kwargs): pass
def MGLFunctionTable_glGetProgramParameterdvNV(*args, **kwargs): pass
def MGeometryLegacy_assign(*args, **kwargs): pass
def MGLFunctionTable_glMap2f(*args, **kwargs): pass
def MGLFunctionTable_glGetTexGendv(*args, **kwargs): pass
def MGLFunctionTable_glCompressedTexImage3D(*args, **kwargs): pass
def MCommonRenderSettingsData_customImageFormat_get(*args, **kwargs): pass
def MGLFunctionTable_glVertexAttrib4sv(*args, **kwargs): pass
def MGLFunctionTable_glBeginOcclusionQueryNV(*args, **kwargs): pass
def MRenderTargetLegacy_swigregister(*args, **kwargs): pass
def MUniformParameter_setAsString(*args, **kwargs): pass
def MGLFunctionTable_glPolygonMode(*args, **kwargs): pass
def MGLFunctionTable_glMultiTexCoord4s(*args, **kwargs): pass
def MGLFunctionTable_glFramebufferTexture3DEXT(*args, **kwargs): pass
def MSwatchRenderRegister_unregisterSwatchRender(*args, **kwargs): pass
def MGLFunctionTable_glHint(*args, **kwargs): pass
def MGLFunctionTable_glLockArraysEXT(*args, **kwargs): pass
def MGLFunctionTable_glTexCoord3sv(*args, **kwargs): pass
def MRenderingInfo_height(*args, **kwargs): pass
def MGLFunctionTable_glVertexArrayRangeNV(*args, **kwargs): pass
def MGLFunctionTable_glBindLightParameterEXT(*args, **kwargs): pass
def new_MGeometryData(*args, **kwargs): pass
def MGLFunctionTable_glGetFloatv(*args, **kwargs): pass
def MGLFunctionTable_glMultiTexCoord3fv(*args, **kwargs): pass
def MCommonRenderSettingsData_setFieldName(*args, **kwargs): pass
def MGLFunctionTable_glGetFenceivNV(*args, **kwargs): pass
def new_MRenderCallback(*args, **kwargs): pass
def MRenderShadowData_lightPosition_get(*args, **kwargs): pass
def MUniformParameter_userData(*args, **kwargs): pass
def MGLFunctionTable_glNormal3fv(*args, **kwargs): pass
def MLightLinks_parseLinks(*args, **kwargs): pass
def MGLFunctionTable_glBindProgramNV(*args, **kwargs): pass
def MGLFunctionTable_glGetShaderSourceARB(*args, **kwargs): pass
def delete_MRenderView(*args, **kwargs): pass
def MGLFunctionTable_glAlphaFunc(*args, **kwargs): pass
def delete_MRenderShadowData(*args, **kwargs): pass
def MGLFunctionTable_glTexCoord1s(*args, **kwargs): pass
def RV_AOV_name_set(*args, **kwargs): pass
def MGLFunctionTable_glVariantusvEXT(*args, **kwargs): pass
def MGLFunctionTable_glEvalPoint2(*args, **kwargs): pass
def MGLFunctionTable_glColor4ubv(*args, **kwargs): pass
def charPtr_cast(*args, **kwargs): pass
def MGLFunctionTable_glMultiTexCoord1fv(*args, **kwargs): pass
def MGLFunctionTable_glUniform1iARB(*args, **kwargs): pass
def uCharPtr_swigregister(*args, **kwargs): pass
def MGeometryRequirementsLegacy_addComponentId(*args, **kwargs): pass
def MGLFunctionTable_glMapGrid1d(*args, **kwargs): pass
def MGLFunctionTable_glVertexAttrib4fv(*args, **kwargs): pass
def MGLFunctionTable_glUniform3fvARB(*args, **kwargs): pass
def MVaryingParameterList_setElement(*args, **kwargs): pass
def MGLFunctionTable_glRenderMode(*args, **kwargs): pass
def MGLFunctionTable_glDeleteVertexShaderEXT(*args, **kwargs): pass
def MGLFunctionTable_glUniform2iARB(*args, **kwargs): pass
def MVaryingParameter_name(*args, **kwargs): pass
def MFnRenderLayer_layerChildren(*args, **kwargs): pass
def MGLFunctionTable_glEdgeFlagPointer(*args, **kwargs): pass
def MGLFunctionTable_glVertex4d(*args, **kwargs): pass
def MRenderData_bytesPerChannel_get(*args, **kwargs): pass
def MGLFunctionTable_glVertexAttrib4ubNV(*args, **kwargs): pass
def MRenderingInfo_renderTarget(*args, **kwargs): pass
def MGLFunctionTable_glLightf(*args, **kwargs): pass
def MGLFunctionTable_glColorFragmentOp3ATI(*args, **kwargs): pass
def MGLFunctionTable_glVertexAttrib4Nub(*args, **kwargs): pass
def MSwatchRenderBase_setRenderQuality(*args, **kwargs): pass
def MCommonRenderSettingsData_className(*args, **kwargs): pass
def MVaryingParameter_getSourceType(*args, **kwargs): pass
def MGLFunctionTable_glVertex3sv(*args, **kwargs): pass
def MGLFunctionTable_glRasterPos4dv(*args, **kwargs): pass
def MGLFunctionTable_glSecondaryColor3svEXT(*args, **kwargs): pass
def MHardwareRenderer_getDrawProcedureCount(*args, **kwargs): pass
def MD3D9Renderer_getD3D9Device(*args, **kwargs): pass
def MRenderCallback_swigregister(*args, **kwargs): pass
def MGLFunctionTable_glCopyTexImage1D(*args, **kwargs): pass
def MGLFunctionTable_glTranslatef(*args, **kwargs): pass
def MViewportRenderer_initialize(*args, **kwargs): pass
def intPtr_cast(*args, **kwargs): pass
def MCommonRenderSettingsData_swigregister(*args, **kwargs): pass
def MRenderData_worldToEyeMatrix_set(*args, **kwargs): pass
def delete_MGeometryList(*args, **kwargs): pass
def MGLFunctionTable_glIndexf(*args, **kwargs): pass
def new_MRenderSetupPrivate(*args, **kwargs): pass
def MGLFunctionTable_glPointParameterfv(*args, **kwargs): pass
def MCommonRenderSettingsData_customExt_set(*args, **kwargs): pass
def MGLFunctionTable_glGetQueryObjectuivARB(*args, **kwargs): pass
def MRenderUtil_mainBeautyPassName(*args, **kwargs): pass
def MGeometryList_setCurrentElement(*args, **kwargs): pass
def MGLFunctionTable_glPixelMapuiv(*args, **kwargs): pass
def MGLFunctionTable_glSetFragmentShaderConstantATI(*args, **kwargs): pass
def MGLFunctionTable_glMateriali(*args, **kwargs): pass
def MCommonRenderSettingsData_preMel_set(*args, **kwargs): pass
def MGLFunctionTable_glColor4dv(*args, **kwargs): pass
def MGLFunctionTable_glTexEnvi(*args, **kwargs): pass
def MGLFunctionTable_glGenProgramsNV(*args, **kwargs): pass
def MGeometryData_objectOwnsData(*args, **kwargs): pass
def MGLFunctionTable_glGetPolygonStipple(*args, **kwargs): pass
def MGLFunctionTable_glActiveTexture(*args, **kwargs): pass
def MCommonRenderSettingsData_namePattern_get(*args, **kwargs): pass
def MGLFunctionTable_glGetFinalCombinerInputParameterivNV(*args, **kwargs): pass
def MGLFunctionTable_glColor4us(*args, **kwargs): pass
def MUniformParameter_setAsFloatArray(*args, **kwargs): pass
def MGLFunctionTable_glPixelTransferf(*args, **kwargs): pass
def MGLFunctionTable_glGetVertexAttribfv(*args, **kwargs): pass
def MGLFunctionTable_glGenFramebuffersEXT(*args, **kwargs): pass
def MGeometryLegacy_texCoord(*args, **kwargs): pass
def MGLFunctionTable_glTexCoord3fv(*args, **kwargs): pass
def MUniformParameter_name(*args, **kwargs): pass
def MGLFunctionTable_glColor4ui(*args, **kwargs): pass
def MGLFunctionTable_glGetVariantFloatvEXT(*args, **kwargs): pass
def MVaryingParameter_getBuffer(*args, **kwargs): pass
def MGLFunctionTable_glVertexAttrib4Niv(*args, **kwargs): pass
def MFnImageSource_getImageName(*args, **kwargs): pass
def MGLFunctionTable_glColor3iv(*args, **kwargs): pass
def MGLFunctionTable_glGetBooleanv(*args, **kwargs): pass
def delete_MHwrCallback(*args, **kwargs): pass
def MGLFunctionTable_glMultiTexCoord2sv(*args, **kwargs): pass
def delete_MCommonRenderSettingsData(*args, **kwargs): pass
def MRenderData_fieldOfView_get(*args, **kwargs): pass
def MGLFunctionTable_glSetFenceNV(*args, **kwargs): pass
def MGLFunctionTable_glGetTexParameterfv(*args, **kwargs): pass
def MRenderShadowData_lightType_get(*args, **kwargs): pass
def MGLFunctionTable_glNormal3bv(*args, **kwargs): pass
def MGLFunctionTable_glDeletePrograms(*args, **kwargs): pass
def MGLFunctionTable_glGetUniformLocationARB(*args, **kwargs): pass
def MGLFunctionTable_glColorMask(*args, **kwargs): pass
def MGLFunctionTable_numTexImageUnits(*args, **kwargs): pass
def MGLFunctionTable_glVertex4iv(*args, **kwargs): pass
def MGLFunctionTable_glTexCoord1f(*args, **kwargs): pass
def boolPtr_cast(*args, **kwargs): pass
def MHwTextureManager_registerTextureFile(*args, **kwargs): pass
def MFnRenderPass_type(*args, **kwargs): pass
def MGLFunctionTable_glCopyTexSubImage3D(*args, **kwargs): pass
def boolPtr_swigregister(*args, **kwargs): pass
def MCommonRenderSettingsData_deviceAspectRatio_get(*args, **kwargs): pass
def MGLFunctionTable_glVertexAttrib4ubvNV(*args, **kwargs): pass
def MGLFunctionTable_glGetInvariantIntegervEXT(*args, **kwargs): pass
def MGLFunctionTable_glMultMatrixf(*args, **kwargs): pass
def MGeometryPrimitive_swigregister(*args, **kwargs): pass
def MGLFunctionTable_glMap1d(*args, **kwargs): pass
def new_MGeometryPrimitive(*args, **kwargs): pass
def MGLFunctionTable_glGenQueriesARB(*args, **kwargs): pass
def MGLFunctionTable_glVertexAttrib4iv(*args, **kwargs): pass
def MGLFunctionTable_glUniform3iARB(*args, **kwargs): pass
def RV_PIXEL_swigregister(*args, **kwargs): pass
def MVaryingParameterList_append(*args, **kwargs): pass
def MHardwareRenderer_insertDrawProcedure(*args, **kwargs): pass
def MGLFunctionTable_glRecti(*args, **kwargs): pass
def MRenderData_worldToScreen(*args, **kwargs): pass
def MGLFunctionTable_glBeginVertexShaderEXT(*args, **kwargs): pass
def MHardwareRenderer_dereferenceGeometry(*args, **kwargs): pass
def delete_MRenderProfile(*args, **kwargs): pass
def delete_MFnRenderLayer(*args, **kwargs): pass
def MCommonRenderSettingsData_name_set(*args, **kwargs): pass
def new_RV_PIXEL(*args, **kwargs): pass
def disown_MRenderCallback(*args, **kwargs): pass
def shortPtr_assign(*args, **kwargs): pass
def MGLFunctionTable_glStencilOp(*args, **kwargs): pass
def delete_MUniformParameterList(*args, **kwargs): pass
def MGLFunctionTable_glTexParameteri(*args, **kwargs): pass
def MVaryingParameter_semanticName(*args, **kwargs): pass
def MHardwareRenderer_backEndString(*args, **kwargs): pass
def new_intPtr(*args, **kwargs): pass
def MRenderData_viewDirection_set(*args, **kwargs): pass
def MGeometryLegacy_binormal(*args, **kwargs): pass
def MGLFunctionTable_glTexParameteriv(*args, **kwargs): pass
def MHwrCallback_removeCallback(*args, **kwargs): pass
def MRenderUtil_exactImagePlaneFileName(*args, **kwargs): pass
def MRenderUtil_valueInNoiseTable(*args, **kwargs): pass
def RV_PIXEL_g_set(*args, **kwargs): pass
def MGLFunctionTable_glRasterPos4sv(*args, **kwargs): pass
def MGLFunctionTable_glDisableVertexAttribArray(*args, **kwargs): pass
def MRenderData_left_get(*args, **kwargs): pass
def MGeometryData_data(*args, **kwargs): pass
def SWIG_PyInstanceMethod_New(*args, **kwargs): pass
def MRenderShadowData_internalData_set(*args, **kwargs): pass
def MUniformParameter_keyable(*args, **kwargs): pass
def MCommonRenderSettingsData_framePadding_set(*args, **kwargs): pass
def MGLFunctionTable_glGetProgramLocalParameterfv(*args, **kwargs): pass
def MSwatchRenderBase_resolution(*args, **kwargs): pass
def MGLFunctionTable_glTexCoord2sv(*args, **kwargs): pass
def MGLFunctionTable_glBindParameterEXT(*args, **kwargs): pass
def MGLFunctionTable_glBindBufferBaseNV(*args, **kwargs): pass
def MRenderSetup_className(*args, **kwargs): pass
def MGLFunctionTable_glIsProgramNV(*args, **kwargs): pass
def MGLFunctionTable_glMultiTexCoord2fv(*args, **kwargs): pass
def uCharPtr_cast(*args, **kwargs): pass
def delete_MUniformParameter(*args, **kwargs): pass
def MGLFunctionTable_glEnableVertexAttribArray(*args, **kwargs): pass
def MGLFunctionTable_glLoadProgramNV(*args, **kwargs): pass
def MGLFunctionTable_glStencilMask(*args, **kwargs): pass
def MCommonRenderSettingsData_enableDefaultLight_get(*args, **kwargs): pass
def MGLFunctionTable_glSetInvariantEXT(*args, **kwargs): pass
def MFnRenderPass_setImplementation(*args, **kwargs): pass
def MHwrCallback_deviceDeleted(*args, **kwargs): pass
def MGLFunctionTable_glViewport(*args, **kwargs): pass
def boolPtr_assign(*args, **kwargs): pass
def MUniformParameter_UIHidden(*args, **kwargs): pass
def MGLFunctionTable_glVertexAttrib3dvNV(*args, **kwargs): pass
def MGLFunctionTable_glVertex3f(*args, **kwargs): pass
def new_MVaryingParameterList(*args, **kwargs): pass
def MGLFunctionTable_glProgramParameter4fNV(*args, **kwargs): pass
def MGLFunctionTable_glColor4d(*args, **kwargs): pass
def MHwTextureManager_className(*args, **kwargs): pass
def MGLFunctionTable_glVertexAttrib3fv(*args, **kwargs): pass
def MGLFunctionTable_glUniform3fARB(*args, **kwargs): pass
def RV_PIXEL_a_set(*args, **kwargs): pass
def MVaryingParameter_getUpdateId(*args, **kwargs): pass
def MGLFunctionTable_glRectd(*args, **kwargs): pass
def MGLFunctionTable_glFogCoordfvEXT(*args, **kwargs): pass
def MHardwareRenderer_restoreCurrent(*args, **kwargs): pass
def MDrawProcedureBase_setName(*args, **kwargs): pass
def MGLFunctionTable_glGetInfoLogARB(*args, **kwargs): pass
def MGLFunctionTable_glVertex3d(*args, **kwargs): pass
def MGLFunctionTable_glVertexAttrib2fNV(*args, **kwargs): pass
def MRenderData_swigregister(*args, **kwargs): pass
def MGLFunctionTable_glUnmapBufferARB(*args, **kwargs): pass
def MGLFunctionTable_glMaterialiv(*args, **kwargs): pass
def MGLFunctionTable_glVertexAttribs1dvNV(*args, **kwargs): pass
def MGLFunctionTable_glGetAttachedObjectsARB(*args, **kwargs): pass
def MGLFunctionTable_glRasterPos3dv(*args, **kwargs): pass
def MGLFunctionTable_glSecondaryColor3bvEXT(*args, **kwargs): pass
def MUniformParameterList_swigregister(*args, **kwargs): pass
def MGLFunctionTable_glGetTransformFeedbackVaryingEXT(*args, **kwargs): pass
def MCommonRenderSettingsData_preRenderMel_get(*args, **kwargs): pass
def MRenderCallback_shadowCastCallback(*args, **kwargs): pass
def MHardwareRenderer_readSwatchContextPixels(*args, **kwargs): pass
def MGLFunctionTable_glTexImage2D(*args, **kwargs): pass
def charPtr_value(*args, **kwargs): pass
def MRenderData_right_set(*args, **kwargs): pass
def MGLFunctionTable_glGetVertexAttribfvNV(*args, **kwargs): pass
def MFnRenderLayer_type(*args, **kwargs): pass
def MRenderUtil_sendRenderProgressInfo(*args, **kwargs): pass
def MGLFunctionTable_glLoadTransposeMatrixf(*args, **kwargs): pass
def MCommonRenderSettingsData_frameBy_set(*args, **kwargs): pass
def MRenderData_rgbaArr_set(*args, **kwargs): pass
def MSwatchRenderBase_cancelParallelRendering(*args, **kwargs): pass
def MGLFunctionTable_glPrimitiveRestartIndexNV(*args, **kwargs): pass
def MGLFunctionTable_glPixelStorei(*args, **kwargs): pass
def MGLFunctionTable_glPopMatrix(*args, **kwargs): pass
def MGLFunctionTable_glActiveVaryingNV(*args, **kwargs): pass
def MGLFunctionTable_glBindBufferOffsetNV(*args, **kwargs): pass
def MGLFunctionTable_glDepthRange(*args, **kwargs): pass
def MGLFunctionTable_glTexCoord4fv(*args, **kwargs): pass
def MGLFunctionTable_glVertexWeightfEXT(*args, **kwargs): pass
def MRenderData_resX_get(*args, **kwargs): pass
def MGeometryData_elementType(*args, **kwargs): pass
def MRenderSetupPrivate__switchToLegacyRenderLayer(*args, **kwargs): pass
def MGLFunctionTable_glMultiTexCoord4d(*args, **kwargs): pass
def MCommonRenderSettingsData_getPostRenderFrameCmd(*args, **kwargs): pass
def MRenderShadowData_depthMaps_set(*args, **kwargs): pass
def MGLFunctionTable_glNormalPointer(*args, **kwargs): pass
def MGLFunctionTable_glProgramParameters4fvNV(*args, **kwargs): pass
def MGLFunctionTable_glProgramLocalParameter4fv(*args, **kwargs): pass
def MGLFunctionTable_glBindRenderbufferEXT(*args, **kwargs): pass
def MSwatchRenderBase_renderParallel(*args, **kwargs): pass
def MGLFunctionTable_glBitmap(*args, **kwargs): pass
def MGLFunctionTable_glTexCoord2fv(*args, **kwargs): pass
def RV_AOV_name_get(*args, **kwargs): pass
def MFnRenderPass_passID(*args, **kwargs): pass
def MGLFunctionTable_glVertex3fv(*args, **kwargs): pass
def MGLFunctionTable_glMultiTexCoord1sv(*args, **kwargs): pass
def MSwatchRenderBase_node(*args, **kwargs): pass
def MGLFunctionTable_glVertexAttribs3fvNV(*args, **kwargs): pass
def new_MCommonRenderSettingsData(*args, **kwargs): pass
def MRenderShadowData_zbufferToWorld(*args, **kwargs): pass
def MGeometryRequirementsLegacy_addColor(*args, **kwargs): pass
def MGLFunctionTable_glMaterialfv(*args, **kwargs): pass
def MGLFunctionTable_glVertexAttrib4Nubv(*args, **kwargs): pass
def MGLFunctionTable_glUniform4ivARB(*args, **kwargs): pass
def RV_AOV_swigregister(*args, **kwargs): pass
def MGLFunctionTable_glClearColor(*args, **kwargs): pass
def MGLFunctionTable_glScissor(*args, **kwargs): pass
def MGLFunctionTable_glDrawArrays(*args, **kwargs): pass
def MGLFunctionTable_glWriteMaskEXT(*args, **kwargs): pass
def MGeometryLegacy_primitiveArray(*args, **kwargs): pass
def MFnRenderLayer_externalRenderPasses(*args, **kwargs): pass
def MGLFunctionTable_glEndList(*args, **kwargs): pass
def MHardwareRenderer_getSwatchLightDirection(*args, **kwargs): pass
def doublePtr_frompointer(*args, **kwargs): pass
def MGLFunctionTable_glVertexAttrib2fvNV(*args, **kwargs): pass
def MGLFunctionTable_glColor4usv(*args, **kwargs): pass
def MGLFunctionTable_glDrawBuffer(*args, **kwargs): pass
def MGLFunctionTable_glVertexAttrib2sv(*args, **kwargs): pass
def MGLFunctionTable_glUseProgramObjectARB(*args, **kwargs): pass
def new_doublePtr(*args, **kwargs): pass
def MVaryingParameter_addElement(*args, **kwargs): pass
def MGLFunctionTable_glRasterPos4s(*args, **kwargs): pass
def MGLFunctionTable_glSecondaryColor3usEXT(*args, **kwargs): pass
def MHardwareRenderer_getColorBufferPixelFormat(*args, **kwargs): pass
def delete_MDrawProcedureBase(*args, **kwargs): pass
def MGLFunctionTable_glVertexAttrib4Nusv(*args, **kwargs): pass
def MGLFunctionTable_glDeleteLists(*args, **kwargs): pass
def MRenderData_depthArr_set(*args, **kwargs): pass
def MGLFunctionTable_glVertex2i(*args, **kwargs): pass
def MGLFunctionTable_glPixelMapusv(*args, **kwargs): pass
def MGLFunctionTable_glVertexAttrib1sNV(*args, **kwargs): pass
def MCommonRenderSettingsData_frameStart_set(*args, **kwargs): pass
def MLightLinks_getLinkedLights(*args, **kwargs): pass
def new_MFnImageSource(*args, **kwargs): pass
def MRenderData_depthArr_get(*args, **kwargs): pass
def MRenderCallback_removeCallback(*args, **kwargs): pass
def MGLFunctionTable_glIndexsv(*args, **kwargs): pass
def MGeometryManager_referenceDefaultGeometry(*args, **kwargs): pass
def MGLFunctionTable_glVertexAttrib1s(*args, **kwargs): pass
def MCommonRenderSettingsData_renumberStart_get(*args, **kwargs): pass
def MUniformParameter_getAsBool(*args, **kwargs): pass
def MGLFunctionTable_glClearDepth(*args, **kwargs): pass
def MFnImageSource_type(*args, **kwargs): pass
def MLightLinks_getShadowLinkedObjects(*args, **kwargs): pass
def MGLFunctionTable_glPixelStoref(*args, **kwargs): pass
def MGLFunctionTable_glUnlockArraysEXT(*args, **kwargs): pass
def MGLFunctionTable_glBindBufferBaseEXT(*args, **kwargs): pass
def MCommonRenderSettingsData_preRenderLayerMel_get(*args, **kwargs): pass
def MViewportRenderer_setRenderingOverride(*args, **kwargs): pass
def MGLFunctionTable_glColor4s(*args, **kwargs): pass
def MGLFunctionTable_glTexGenfv(*args, **kwargs): pass
def intPtr_swigregister(*args, **kwargs): pass
def MRenderView_doesRenderEditorExist(*args, **kwargs): pass
def MGLFunctionTable_glGetProgramivNV(*args, **kwargs): pass
def MGLFunctionTable_glSelectBuffer(*args, **kwargs): pass
def MRenderData_xsize_set(*args, **kwargs): pass
def MGeometryLegacy_primitiveArrayCount(*args, **kwargs): pass
def MGLFunctionTable_glGetTexGenfv(*args, **kwargs): pass
def MGLFunctionTable_glCompressedTexSubImage1D(*args, **kwargs): pass
def MGLFunctionTable_glGetProgramLocalParameterdv(*args, **kwargs): pass
def MGLFunctionTable_glEndOcclusionQueryNV(*args, **kwargs): pass
def MRenderingInfo_renderingAPI(*args, **kwargs): pass
def MRenderUtil_mayaRenderState(*args, **kwargs): pass
def MGLFunctionTable_glBindFragmentShaderATI(*args, **kwargs): pass
def MGLFunctionTable_glFramebufferRenderbufferEXT(*args, **kwargs): pass
def MGLFunctionTable_glColor3s(*args, **kwargs): pass
def MCommonRenderSettingsData_skipExistingFrames_get(*args, **kwargs): pass
def MGLFunctionTable_glVertex3i(*args, **kwargs): pass
def MGLFunctionTable_glShaderSourceARB(*args, **kwargs): pass
def MGLFunctionTable_glGetInvariantFloatvEXT(*args, **kwargs): pass
def MGLFunctionTable_glGetIntegerv(*args, **kwargs): pass
def MGLFunctionTable_glMultiTexCoord3i(*args, **kwargs): pass
def MCommonRenderSettingsData_getImageName(*args, **kwargs): pass
def MGLFunctionTable_glCombinerParameterfvNV(*args, **kwargs): pass
def MGLFunctionTable_glNormal3i(*args, **kwargs): pass
def MRenderUtil_noise4(*args, **kwargs): pass
def MCommonRenderSettingsData_renderAll_set(*args, **kwargs): pass
def new_MSwatchRenderRegister(*args, **kwargs): pass
def MGLFunctionTable_glBindAttribLocationARB(*args, **kwargs): pass
def MRenderData_resX_set(*args, **kwargs): pass
def MGLFunctionTable_glTexCoord1sv(*args, **kwargs): pass
def MGLFunctionTable_glVariantuivEXT(*args, **kwargs): pass
def boolPtr_frompointer(*args, **kwargs): pass
def MFnRenderPass_getImplementation(*args, **kwargs): pass
def MGLFunctionTable_glFeedbackBuffer(*args, **kwargs): pass
def MGLFunctionTable_glMultMatrixd(*args, **kwargs): pass
def uIntPtr_value(*args, **kwargs): pass
def MGLFunctionTable_glGetProgramString(*args, **kwargs): pass
def MGLFunctionTable_glVertexAttribs2svNV(*args, **kwargs): pass
def MGeometryRequirementsLegacy_addNormal(*args, **kwargs): pass
def MGLFunctionTable_glMapGrid1f(*args, **kwargs): pass
def delete_MGeometryPrimitive(*args, **kwargs): pass
def MGLFunctionTable_glVertexAttrib4dv(*args, **kwargs): pass
def MGLFunctionTable_glUniform4fvARB(*args, **kwargs): pass
def RV_AOV_pPixels_set(*args, **kwargs): pass
def MVaryingParameterList_assign(*args, **kwargs): pass
def MGLFunctionTable_glRotated(*args, **kwargs): pass
def MRenderData_screenToWorld(*args, **kwargs): pass
def MGLFunctionTable_glVertexAttrib3fNV(*args, **kwargs): pass
def MRenderUtil_inCurrentRenderLayer(*args, **kwargs): pass
def MHardwareRenderer_drawSwatchBackGroundQuads(*args, **kwargs): pass
def MGLFunctionTable_glEdgeFlagv(*args, **kwargs): pass
def delete_doublePtr(*args, **kwargs): pass
def MGeometryManager_dereferenceDefaultGeometry(*args, **kwargs): pass
def MGLFunctionTable_glPolygonOffset(*args, **kwargs): pass
def MGeometryData_collectionNumber(*args, **kwargs): pass
def MGLFunctionTable_glVertexAttrib3dNV(*args, **kwargs): pass
def MGLFunctionTable_glCompileShaderARB(*args, **kwargs): pass
def new_MRenderUtil(*args, **kwargs): pass
def MVaryingParameter_getSourceSetName(*args, **kwargs): pass
def MGLFunctionTable_glRasterPos4f(*args, **kwargs): pass
def MGLFunctionTable_glSecondaryColor3ubEXT(*args, **kwargs): pass
def MD3D9Renderer_theRenderer(*args, **kwargs): pass
def MGLFunctionTable_glProgramParameter4fvNV(*args, **kwargs): pass
def MGLFunctionTable_glCopyTexImage2D(*args, **kwargs): pass
def MGLFunctionTable_glVertex2d(*args, **kwargs): pass
def MGLFunctionTable_glProgramParameters4dvNV(*args, **kwargs): pass
def MGLFunctionTable_glIsFramebufferEXT(*args, **kwargs): pass
def MGLFunctionTable_glLoadTransposeMatrixfARB(*args, **kwargs): pass
def MCommonRenderSettingsData_customExt_get(*args, **kwargs): pass
def MGLFunctionTable_glBindBufferARB(*args, **kwargs): pass
def MUniformParameterList_setLength(*args, **kwargs): pass
def MRenderShadowData_projectionMatrix_set(*args, **kwargs): pass
def MGLFunctionTable_glRasterPos2f(*args, **kwargs): pass
def MGLFunctionTable_glSetLocalConstantEXT(*args, **kwargs): pass
def RV_PIXEL_g_get(*args, **kwargs): pass
def MGLFunctionTable_glBindFramebufferEXT(*args, **kwargs): pass
def shortPtr_swigregister(*args, **kwargs): pass
def MGLFunctionTable_glGetVaryingLocationNV(*args, **kwargs): pass
def MCommonRenderSettingsData_preMel_get(*args, **kwargs): pass
def MGLFunctionTable_glTexEnviv(*args, **kwargs): pass
def MGLFunctionTable_glAreProgramsResidentNV(*args, **kwargs): pass
def MRenderData_top_set(*args, **kwargs): pass
def MGeometryData_swigregister(*args, **kwargs): pass
def MGLFunctionTable_glProgramEnvParameter4fv(*args, **kwargs): pass
def MGLFunctionTable_glGetString(*args, **kwargs): pass
def MGLFunctionTable_glClientActiveTexture(*args, **kwargs): pass
def MCommonRenderSettingsData_imageFormat_set(*args, **kwargs): pass
def MGLFunctionTable_glGenOcclusionQueriesNV(*args, **kwargs): pass
def MFnRenderLayer_currentLayer(*args, **kwargs): pass
def MGeometryData_elementSize(*args, **kwargs): pass
def MGeometryPrimitive_data(*args, **kwargs): pass
def MGLFunctionTable_glGetVertexAttribiv(*args, **kwargs): pass
def MUniformParameterList_length(*args, **kwargs): pass
def MGLFunctionTable_glCheckFramebufferStatusEXT(*args, **kwargs): pass
def MGLFunctionTable_glAreTexturesResident(*args, **kwargs): pass
def MGLFunctionTable_glColor3f(*args, **kwargs): pass
def MGLFunctionTable_glTexCoord3i(*args, **kwargs): pass
def MHardwareRenderer_makeSwatchContextCurrent(*args, **kwargs): pass
def MFnRenderLayer_swigregister(*args, **kwargs): pass
def MLightLinks_getShadowIgnoredObjects(*args, **kwargs): pass
def MFnImageSource_sourceLayer(*args, **kwargs): pass
def new_RV_AOV(*args, **kwargs): pass
def MGLFunctionTable_glGetClipPlane(*args, **kwargs): pass
def MGLFunctionTable_glMultiTexCoord3d(*args, **kwargs): pass
def MGLFunctionTable_glRasterPos2dv(*args, **kwargs): pass
def MCommonRenderSettingsData_isAnimated(*args, **kwargs): pass
def MRenderView_swigregister(*args, **kwargs): pass
def MGLFunctionTable_glTestFenceNV(*args, **kwargs): pass
def MRenderShadowData_shadowResY_set(*args, **kwargs): pass
def MUniformParameter_numRows(*args, **kwargs): pass
def MGLFunctionTable_glVertex2iv(*args, **kwargs): pass
def MGLFunctionTable_glGenPrograms(*args, **kwargs): pass
def MGLFunctionTable_glGetActiveUniformARB(*args, **kwargs): pass
def MGLFunctionTable_glEvalCoord1fv(*args, **kwargs): pass
def MRenderView_setDrawTileBoundary(*args, **kwargs): pass
def MGLFunctionTable_glTexCoord1fv(*args, **kwargs): pass
def MGLFunctionTable_glVariantfvEXT(*args, **kwargs): pass
def delete_MFnRenderPass(*args, **kwargs): pass
def MGLFunctionTable_glVertexAttrib1fNV(*args, **kwargs): pass
def MGLFunctionTable_glEvalMesh1(*args, **kwargs): pass
def MGLFunctionTable_glMultiTexCoord1d(*args, **kwargs): pass
def MGLFunctionTable_glLineWidth(*args, **kwargs): pass
def MUniformParameter_setEnumFieldNames(*args, **kwargs): pass
def MGLFunctionTable_glEvalCoord2d(*args, **kwargs): pass
def new_MGeometryRequirementsLegacy(*args, **kwargs): pass
def MGLFunctionTable_glGetTransformFeedbackVaryingNV(*args, **kwargs): pass
def MGLFunctionTable_glMap1f(*args, **kwargs): pass
def new_MHwTextureManager(*args, **kwargs): pass
def MGLFunctionTable_glVertexAttrib4ubv(*args, **kwargs): pass
def MGLFunctionTable_glUniform4iARB(*args, **kwargs): pass
def MVaryingParameterList_length(*args, **kwargs): pass
def MRenderShadowData_midDistMaps_set(*args, **kwargs): pass
def MGLFunctionTable_glRectiv(*args, **kwargs): pass
def delete_RV_PIXEL(*args, **kwargs): pass
def MGLFunctionTable_glEndVertexShaderEXT(*args, **kwargs): pass
def MHardwareRenderer_getSwatchOrthoCameraSetting(*args, **kwargs): pass
def MGLFunctionTable_glEvalCoord2dv(*args, **kwargs): pass
def floatPtr_cast(*args, **kwargs): pass
def uCharPtr_assign(*args, **kwargs): pass
def MGeometryList_addLast(*args, **kwargs): pass
def MGLFunctionTable_glLightModelfv(*args, **kwargs): pass
def MGLFunctionTable_glVertexAttrib4s(*args, **kwargs): pass
def MGLFunctionTable_glVertexAttrib3sNV(*args, **kwargs): pass
def MCommonRenderSettingsData_pixelAspectRatio_set(*args, **kwargs): pass
def MGLFunctionTable_glPushAttrib(*args, **kwargs): pass
def MRenderUtil_noise1(*args, **kwargs): pass
def MVaryingParameter_destinationSet(*args, **kwargs): pass
def MGLFunctionTable_glRasterPos3s(*args, **kwargs): pass
def MGLFunctionTable_glSecondaryColor3iEXT(*args, **kwargs): pass
def MHardwareRenderer_addDrawProcedure(*args, **kwargs): pass
def MD3D9Renderer_makeSwatchContextCurrent(*args, **kwargs): pass
def MGLFunctionTable_glColorMaterial(*args, **kwargs): pass
def MHardwareRenderer_glFunctionTable(*args, **kwargs): pass
def MGLFunctionTable_glTexSubImage1D(*args, **kwargs): pass
def MRenderData_right_get(*args, **kwargs): pass
def MRenderData_viewDirection_get(*args, **kwargs): pass
def MGLFunctionTable_glPushClientAttrib(*args, **kwargs): pass
def MCommonRenderSettingsData_renderAll_get(*args, **kwargs): pass
def MSwatchRenderBase_swatchNode(*args, **kwargs): pass
def new_MUniformParameterList(*args, **kwargs): pass
def MGLFunctionTable_glAlphaFragmentOp1ATI(*args, **kwargs): pass
def MGLFunctionTable_glNewList(*args, **kwargs): pass
def MCommonRenderSettingsData_dotPerInch_get(*args, **kwargs): pass
def MGLFunctionTable_glPushMatrix(*args, **kwargs): pass
def MViewportRenderer_override(*args, **kwargs): pass
def MRenderData_rgbaArr_get(*args, **kwargs): pass
def MGeometryData_setCollectionNumber(*args, **kwargs): pass
def MHardwareRenderer_getSwatchPerspectiveCameraTranslation(*args, **kwargs): pass
def MGLFunctionTable_glTexImage3D(*args, **kwargs): pass
def MGLFunctionTable_glFogi(*args, **kwargs): pass
def delete_MFnImageSource(*args, **kwargs): pass
def MGLFunctionTable_glTexSubImage3D(*args, **kwargs): pass
def uCharPtr_frompointer(*args, **kwargs): pass
def MRenderShadowData_lightType_set(*args, **kwargs): pass
def MUniformParameter_assign(*args, **kwargs): pass
def MGLFunctionTable_glShaderOp1EXT(*args, **kwargs): pass
def MFnRenderLayer_inCurrentRenderLayer(*args, **kwargs): pass
def MRenderView_startRegionRender(*args, **kwargs): pass
def MCommonRenderSettingsData_deviceAspectRatio_set(*args, **kwargs): pass
def MGeometryRequirementsLegacy_swigregister(*args, **kwargs): pass
def MRenderShadowData_perspective_set(*args, **kwargs): pass
def MGLFunctionTable_maxTextureSize(*args, **kwargs): pass
def MVaryingParameter_semantic(*args, **kwargs): pass
def MGLFunctionTable_glColor3dv(*args, **kwargs): pass
def MGLFunctionTable_glDrawRangeElements(*args, **kwargs): pass
def MGeometryList_projectionMatrix(*args, **kwargs): pass
def MRenderData_xsize_get(*args, **kwargs): pass
def MGLFunctionTable_glIsQueryARB(*args, **kwargs): pass
def MGeometryPrimitive_elementCount(*args, **kwargs): pass
def MGLFunctionTable_glVertexAttrib4svNV(*args, **kwargs): pass
def MSwatchRenderBase_cancelCurrentSwatchRender(*args, **kwargs): pass
def RV_PIXEL_a_get(*args, **kwargs): pass
def MVaryingParameter_swigregister(*args, **kwargs): pass
def MGLFunctionTable_glVertex4dv(*args, **kwargs): pass
def MGLFunctionTable_glRectdv(*args, **kwargs): pass
def MGLFunctionTable_glFogCoorddEXT(*args, **kwargs): pass
def MGLFunctionTable_glVertexAttrib4fvNV(*args, **kwargs): pass
def MGLFunctionTable_glVertex3dv(*args, **kwargs): pass
def new_floatPtr(*args, **kwargs): pass
def MGLFunctionTable_glVertexAttrib2dNV(*args, **kwargs): pass
def MGLFunctionTable_glVertexAttrib1svNV(*args, **kwargs): pass
def MGLFunctionTable_glVertexAttrib2d(*args, **kwargs): pass
def MCommonRenderSettingsData_height_set(*args, **kwargs): pass
def MUniformParameter_setAsBool(*args, **kwargs): pass
def MGLFunctionTable_glGetBufferParameterivARB(*args, **kwargs): pass
def MGLFunctionTable_glMultiTexCoord4fv(*args, **kwargs): pass
def MHardwareRenderer_theRenderer(*args, **kwargs): pass
def MGLFunctionTable_glVertexAttrib4dvNV(*args, **kwargs): pass
def MGLFunctionTable_glRasterPos3f(*args, **kwargs): pass
def MLightLinks_getShadowIgnoredLights(*args, **kwargs): pass
def MGLFunctionTable_glSecondaryColor3dEXT(*args, **kwargs): pass
def MGLFunctionTable_glTransformFeedbackVaryingsEXT(*args, **kwargs): pass
def MRenderingInfo_viewMatrix(*args, **kwargs): pass
def MCommonRenderSettingsData_postRenderMel_set(*args, **kwargs): pass
def MGLFunctionTable_glLightfv(*args, **kwargs): pass
def MGLFunctionTable_glColor4uiv(*args, **kwargs): pass
def MGLFunctionTable_glTexParameterf(*args, **kwargs): pass
def MRenderView_setCurrentCamera(*args, **kwargs): pass
def MGLFunctionTable_glGetVertexAttribivNV(*args, **kwargs): pass
def MRenderCallback_addCallback(*args, **kwargs): pass
def MGLFunctionTable_glBindBufferRangeNV(*args, **kwargs): pass
def intPtr_frompointer(*args, **kwargs): pass
def MGLFunctionTable_glLoadTransposeMatrixd(*args, **kwargs): pass
def MCommonRenderSettingsData_frameBy_get(*args, **kwargs): pass
def MCommonRenderSettingsData_shouldRenderFrameAtTime(*args, **kwargs): pass
def MUniformParameter_getPlug(*args, **kwargs): pass
def MGLFunctionTable_glPopName(*args, **kwargs): pass
def MGeometryList_cullMode(*args, **kwargs): pass
def MGLFunctionTable_glSampleMapATI(*args, **kwargs): pass
def MGLFunctionTable_glBeginTransformFeedbackNV(*args, **kwargs): pass
def MGLFunctionTable_glTexCoord4i(*args, **kwargs): pass
def MUniformParameter_semantic(*args, **kwargs): pass
def MGLFunctionTable_glVertexWeightfvEXT(*args, **kwargs): pass
def MRenderData_resY_set(*args, **kwargs): pass
def MGeometryData_elementTypeSize(*args, **kwargs): pass
def MGLFunctionTable_glMultiTexCoord4dv(*args, **kwargs): pass
def MRenderData_aspectRatio_get(*args, **kwargs): pass
def MGLFunctionTable_glCombinerOutputNV(*args, **kwargs): pass
def MRenderShadowData_depthMaps_get(*args, **kwargs): pass
def MGLFunctionTable_glFogfv(*args, **kwargs): pass
def MGLFunctionTable_glGetProgramEnvParameterdv(*args, **kwargs): pass
def MGLFunctionTable_glDeleteRenderbuffersEXT(*args, **kwargs): pass
def MGLFunctionTable_glTexCoord2i(*args, **kwargs): pass
def MGLFunctionTable_glBindMaterialParameterEXT(*args, **kwargs): pass
def MGLFunctionTable_glGetRenderbufferParameterivEXT(*args, **kwargs): pass
def MFnRenderPass_customTokenString(*args, **kwargs): pass
def MFnImageSource_className(*args, **kwargs): pass
def MGLFunctionTable_glMultiTexCoord2d(*args, **kwargs): pass
def delete_uCharPtr(*args, **kwargs): pass
def MGLFunctionTable_glVertexAttribs3dvNV(*args, **kwargs): pass
def MViewportRenderer_renderingOverride(*args, **kwargs): pass
def MUniformParameter_setDirty(*args, **kwargs): pass
def MRenderShadowData_shadowResX_get(*args, **kwargs): pass
def MGLFunctionTable_glUniformMatrix2fvARB(*args, **kwargs): pass
def MGLFunctionTable_glMultiTexCoord1s(*args, **kwargs): pass
def MGLFunctionTable_glInsertComponentEXT(*args, **kwargs): pass
def MFnRenderLayer_passHasObject(*args, **kwargs): pass
def MGLFunctionTable_glEvalCoord1d(*args, **kwargs): pass
def MRenderUtil_convertPsdFile(*args, **kwargs): pass
def MGLFunctionTable_glVertex4s(*args, **kwargs): pass
def doublePtr_swigregister(*args, **kwargs): pass
def MHardwareRenderer_getDrawProcedureListNames(*args, **kwargs): pass
def MRenderView_endRender(*args, **kwargs): pass
def MGLFunctionTable_glVertexAttrib2dvNV(*args, **kwargs): pass
def MRenderProfile_numberOfRenderers(*args, **kwargs): pass
def MGLFunctionTable_glMultiTexCoord4i(*args, **kwargs): pass
def MGLFunctionTable_glFrontFace(*args, **kwargs): pass
def MGLFunctionTable_glVertexAttrib2fv(*args, **kwargs): pass
def MUniformParameter_getAsString(*args, **kwargs): pass
def MGLFunctionTable_glValidateProgramARB(*args, **kwargs): pass
def MVaryingParameter_numElements(*args, **kwargs): pass
def delete_MSwatchRenderRegister(*args, **kwargs): pass
def MGLFunctionTable_glSecondaryColor3usvEXT(*args, **kwargs): pass
def MHardwareRenderer_getDepthBufferPixelFormat(*args, **kwargs): pass
def MGLFunctionTable_glFrustum(*args, **kwargs): pass
def shortPtr_value(*args, **kwargs): pass
def MGLFunctionTable_glUniform1fARB(*args, **kwargs): pass
def MVaryingParameter_getElement(*args, **kwargs): pass
def MGeometryList_MSetupFlags_set(*args, **kwargs): pass
def MGLFunctionTable_glColor3us(*args, **kwargs): pass
def MGLFunctionTable_glIndexub(*args, **kwargs): pass
def MGLFunctionTable_glVertexAttrib1f(*args, **kwargs): pass
def MCommonRenderSettingsData_renumberBy_set(*args, **kwargs): pass
def MGLFunctionTable_glEvalCoord2fv(*args, **kwargs): pass
def MRenderData_worldToEyeMatrix_get(*args, **kwargs): pass
def MGLFunctionTable_glBufferSubDataARB(*args, **kwargs): pass
def MGLFunctionTable_glIndexfv(*args, **kwargs): pass
def MRenderUtil_getCommonRenderSettings(*args, **kwargs): pass
def MGLFunctionTable_glLoadMatrixd(*args, **kwargs): pass
def new_MVaryingParameter(*args, **kwargs): pass
def MGLFunctionTable_glRasterPos2s(*args, **kwargs): pass
def MGLFunctionTable_glGenLists(*args, **kwargs): pass
def MGLFunctionTable_glCullParameterdvEXT(*args, **kwargs): pass
def MGLFunctionTable_glReadBuffer(*args, **kwargs): pass
def MGLFunctionTable_glBindBufferOffsetEXT(*args, **kwargs): pass
def MCommonRenderSettingsData_postRenderLayerMel_set(*args, **kwargs): pass
def MViewportRenderer_swigregister(*args, **kwargs): pass
def MGLFunctionTable_glColor4sv(*args, **kwargs): pass
def MGLFunctionTable_glTexGeni(*args, **kwargs): pass
def MGLFunctionTable_glGetProgramStringNV(*args, **kwargs): pass
def MSwatchRenderBase_doIteration(*args, **kwargs): pass
def MGLFunctionTable_glProgramLocalParameter4d(*args, **kwargs): pass
def MGLFunctionTable_glGetTexGeniv(*args, **kwargs): pass
def MGLFunctionTable_glSecondaryColorPointerEXT(*args, **kwargs): pass
def MGLFunctionTable_glRasterPos3i(*args, **kwargs): pass
def MCommonRenderSettingsData_frameStart_get(*args, **kwargs): pass
def MGLFunctionTable_glGetOcclusionQueryivNV(*args, **kwargs): pass
def MGLFunctionTable_glPolygonStipple(*args, **kwargs): pass
def MGLFunctionTable_glDeleteFragmentShaderATI(*args, **kwargs): pass
def MGLFunctionTable_glGetFramebufferAttachmentParameterivEXT(*args, **kwargs): pass
def MFnRenderLayer_defaultRenderLayer(*args, **kwargs): pass
def MGLFunctionTable_glColor3sv(*args, **kwargs): pass
def MHardwareRenderer_getCurrentExposureNumber(*args, **kwargs): pass
def MGLFunctionTable_glTexCoord4d(*args, **kwargs): pass
def MGLFunctionTable_glRasterPos3iv(*args, **kwargs): pass
def MRenderData_left_set(*args, **kwargs): pass
def MGLFunctionTable_glGetLocalConstantBooleanvEXT(*args, **kwargs): pass
def MRenderData_perspective_set(*args, **kwargs): pass
def new_MRenderSetup(*args, **kwargs): pass
def MGeometryData_objectName(*args, **kwargs): pass
def MGLFunctionTable_glGetLightfv(*args, **kwargs): pass
def MRenderUtil_diffuseReflectance(*args, **kwargs): pass
def MHwTextureManager_deregisterTextureFile(*args, **kwargs): pass
def MGLFunctionTable_glMultiTexCoord3iv(*args, **kwargs): pass
def new_MSwatchRenderBase(*args, **kwargs): pass
def MGLFunctionTable_glCombinerParameterfNV(*args, **kwargs): pass
def MRenderShadowData_projectionMatrix_get(*args, **kwargs): pass
def MGLFunctionTable_glNormal3iv(*args, **kwargs): pass
def MGLFunctionTable_glMultiTexCoord2i(*args, **kwargs): pass
def MGLFunctionTable_glGetActiveAttribARB(*args, **kwargs): pass
def MGLFunctionTable_glArrayElement(*args, **kwargs): pass
def MGLFunctionTable_glTexCoord2d(*args, **kwargs): pass
def MGLFunctionTable_glVariantPointerEXT(*args, **kwargs): pass
def MHwTextureManager_swigregister(*args, **kwargs): pass
def MFnRenderPass_frameBufferType(*args, **kwargs): pass
def MCommonRenderSettingsData_namingScheme_get(*args, **kwargs): pass
def MGLFunctionTable_glFinish(*args, **kwargs): pass
def MGLFunctionTable_glMultiTexCoord1i(*args, **kwargs): pass
def uIntPtr_cast(*args, **kwargs): pass
def MGLFunctionTable_glMultiTexCoord2iv(*args, **kwargs): pass
def MGLFunctionTable_glVertexAttribs2fvNV(*args, **kwargs): pass
def MRenderSetupPrivate_swigregister(*args, **kwargs): pass
def MGeometryRequirementsLegacy_addTexCoord(*args, **kwargs): pass
def MGLFunctionTable_glMapGrid2d(*args, **kwargs): pass
def MGLFunctionTable_glVertexAttrib4Nbv(*args, **kwargs): pass
def MRenderUtil_hemisphereCoverage(*args, **kwargs): pass
def MGLFunctionTable_glUniform1ivARB(*args, **kwargs): pass
def RV_AOV_pPixels_get(*args, **kwargs): pass
def MGLFunctionTable_glRotatef(*args, **kwargs): pass
def MGLFunctionTable_glSecondaryColor3fEXT(*args, **kwargs): pass
def MGLFunctionTable_glMultiTexCoord2s(*args, **kwargs): pass
def MFnRenderLayer_listMembers(*args, **kwargs): pass
def MGLFunctionTable_glEnable(*args, **kwargs): pass
def MGLFunctionTable_glVertex4f(*args, **kwargs): pass
def doublePtr_assign(*args, **kwargs): pass
def MGLFunctionTable_glVertexAttrib1fvNV(*args, **kwargs): pass
def MGeometryManager_className(*args, **kwargs): pass
def MGLFunctionTable_glLoadMatrixf(*args, **kwargs): pass
def MGLFunctionTable_glLighti(*args, **kwargs): pass
def MGLFunctionTable_glVertexAttrib1sv(*args, **kwargs): pass
def MGLFunctionTable_glSecondaryColor3fvEXT(*args, **kwargs): pass
def MGLFunctionTable_glCreateProgramObjectARB(*args, **kwargs): pass
def MVaryingParameter_setSource(*args, **kwargs): pass
def MGLFunctionTable_glRasterPos4fv(*args, **kwargs): pass
def MGLFunctionTable_glSecondaryColor3ubvEXT(*args, **kwargs): pass
def MHardwareRenderer_findDrawProcedure(*args, **kwargs): pass
def MGLFunctionTable_glCopyTexSubImage1D(*args, **kwargs): pass
def MGLFunctionTable_glVertex2dv(*args, **kwargs): pass
def MGeometryList_objectToWorldMatrix(*args, **kwargs): pass
def MGLFunctionTable_glVertexAttribs4ubvNV(*args, **kwargs): pass
def MGeometryList_next(*args, **kwargs): pass
def MGLFunctionTable_glIndexi(*args, **kwargs): pass
def MRenderUtil_renderObjectItem(*args, **kwargs): pass
def MGLFunctionTable_glLoadTransposeMatrixdARB(*args, **kwargs): pass
def MCommonRenderSettingsData_renumberFrames_set(*args, **kwargs): pass
def MGLFunctionTable_glDeleteBuffersARB(*args, **kwargs): pass
def MRenderUtil_maximumSpecularReflection(*args, **kwargs): pass
def MUniformParameterList_getElement(*args, **kwargs): pass
def MUniformParameter_isATexture(*args, **kwargs): pass
def MFnRenderLayer_listAllRenderLayers(*args, **kwargs): pass
def MGLFunctionTable_glRasterPos2fv(*args, **kwargs): pass
def MGLFunctionTable_glPNTrianglesiATI(*args, **kwargs): pass
def uIntPtr_frompointer(*args, **kwargs): pass
def MGLFunctionTable_glGenFencesNV(*args, **kwargs): pass
def MGLFunctionTable_glTransformFeedbackAttribsNV(*args, **kwargs): pass
def MCommonRenderSettingsData_postMel_set(*args, **kwargs): pass
def MViewportRenderer_UIname(*args, **kwargs): pass
def MGLFunctionTable_glColor4fv(*args, **kwargs): pass
def MGLFunctionTable_glTexGend(*args, **kwargs): pass
def MGLFunctionTable_glRequestResidentProgramsNV(*args, **kwargs): pass
def MRenderData_top_get(*args, **kwargs): pass
def MGLFunctionTable_glGetTexEnvfv(*args, **kwargs): pass
def MGLFunctionTable_glCompressedTexImage1D(*args, **kwargs): pass
def MCommonRenderSettingsData_imageFormat_get(*args, **kwargs): pass
def MUniformParameter_getAsFloat(*args, **kwargs): pass
def MGLFunctionTable_glDeleteOcclusionQueriesNV(*args, **kwargs): pass
def MVaryingParameterList_swigregister(*args, **kwargs): pass
def MUniformParameter_setAsFloat(*args, **kwargs): pass
def MGLFunctionTable_glGetVertexAttribPointerv(*args, **kwargs): pass
def MGLFunctionTable_glFogiv(*args, **kwargs): pass
def MSwatchRenderBase_swigregister(*args, **kwargs): pass
def MGLFunctionTable_glColor3fv(*args, **kwargs): pass
def MRenderTargetLegacy_height(*args, **kwargs): pass
def MDrawProcedureBase_execute(*args, **kwargs): pass
def MGLFunctionTable_glTexCoord3iv(*args, **kwargs): pass
def MGLFunctionTable_glGetVariantPointervEXT(*args, **kwargs): pass
def MFnImageSource_sourceCamera(*args, **kwargs): pass
def MGLFunctionTable_glGetDoublev(*args, **kwargs): pass
def MGLFunctionTable_glMultiTexCoord3dv(*args, **kwargs): pass
def MGLFunctionTable_glFinishFenceNV(*args, **kwargs): pass
def MGLFunctionTable_glNormal3dv(*args, **kwargs): pass
def MGLFunctionTable_glShaderOp2EXT(*args, **kwargs): pass
def MGLFunctionTable_glGetMapfv(*args, **kwargs): pass
def MRenderUtil_raytrace(*args, **kwargs): pass
def MGLFunctionTable_maxVertexAttributes(*args, **kwargs): pass
def MGLFunctionTable_glVertexAttribs4fvNV(*args, **kwargs): pass
def MGLFunctionTable_glTexCoord1i(*args, **kwargs): pass
def MGLFunctionTable_glVariantdvEXT(*args, **kwargs): pass
def MHwTextureManager_textureFile(*args, **kwargs): pass
def MFnRenderPass_className(*args, **kwargs): pass
def MGLFunctionTable_glEvalMesh2(*args, **kwargs): pass
def MGLFunctionTable_glRasterPos3fv(*args, **kwargs): pass
def MGLFunctionTable_glMultiTexCoord1dv(*args, **kwargs): pass
def delete_uIntPtr(*args, **kwargs): pass
def MRenderData_ysize_set(*args, **kwargs): pass
def MGLFunctionTable_glVertexAttribs1svNV(*args, **kwargs): pass
def MGLFunctionTable_glGetMapiv(*args, **kwargs): pass
def MRenderShadowData_useMidDistMap_set(*args, **kwargs): pass
def MHwrCallback_deviceNew(*args, **kwargs): pass
def MGLFunctionTable_glMap2d(*args, **kwargs): pass
def MGLFunctionTable_glVertexAttrib4usv(*args, **kwargs): pass
def MSwatchRenderBase_enableSwatchRender(*args, **kwargs): pass
def MGLFunctionTable_glUniform1fvARB(*args, **kwargs): pass
def MGLFunctionTable_glBindVertexShaderEXT(*args, **kwargs): pass
def delete_boolPtr(*args, **kwargs): pass
def MGLFunctionTable_glGetMaterialfv(*args, **kwargs): pass
def new_MFnRenderLayer(*args, **kwargs): pass
def MGLFunctionTable_glDrawPixels(*args, **kwargs): pass
def MGLFunctionTable_glVertex3s(*args, **kwargs): pass
def floatPtr_frompointer(*args, **kwargs): pass
def MRenderingInfo_renderingVersion(*args, **kwargs): pass
def MGeometryList_swigregister(*args, **kwargs): pass
def MGLFunctionTable_glLightModeli(*args, **kwargs): pass
def MGLFunctionTable_glEvalCoord1dv(*args, **kwargs): pass
def MGLFunctionTable_glVertexAttrib4f(*args, **kwargs): pass
def MCommonRenderSettingsData_pixelAspectRatio_get(*args, **kwargs): pass
def MRenderShadowData_shadowResX_set(*args, **kwargs): pass
def MGLFunctionTable_glGetMaterialiv(*args, **kwargs): pass
def MRenderUtil_noise2(*args, **kwargs): pass
def MVaryingParameter_dimension(*args, **kwargs): pass
def MGLFunctionTable_glRasterPos3sv(*args, **kwargs): pass
def MGLFunctionTable_glSecondaryColor3ivEXT(*args, **kwargs): pass
def MRenderingInfo_projectionMatrix(*args, **kwargs): pass
def MRenderCallback_className(*args, **kwargs): pass
def MGLFunctionTable_glColorPointer(*args, **kwargs): pass
def MGLFunctionTable_glTexSubImage2D(*args, **kwargs): pass
def intPtr_assign(*args, **kwargs): pass
def MGLFunctionTable_glGetPixelMapfv(*args, **kwargs): pass
def MGLFunctionTable_glIndexd(*args, **kwargs): pass
def MGLFunctionTable_glVariantivEXT(*args, **kwargs): pass
def MGLFunctionTable_glBlendEquationEXT(*args, **kwargs): pass
def MCommonRenderSettingsData_useCustomExt_set(*args, **kwargs): pass
def MGLFunctionTable_glGetQueryivARB(*args, **kwargs): pass
def MGLFunctionTable_glPushName(*args, **kwargs): pass
def MGLFunctionTable_glGetCombinerInputParameterfvNV(*args, **kwargs): pass
def MGLFunctionTable_glAlphaFragmentOp2ATI(*args, **kwargs): pass
def MGLFunctionTable_glEndTransformFeedbackNV(*args, **kwargs): pass
def MCommonRenderSettingsData_enableDefaultLight_set(*args, **kwargs): pass
def MGLFunctionTable_glGetPixelMapuiv(*args, **kwargs): pass
def MGLFunctionTable_glColor4bv(*args, **kwargs): pass
def MGLFunctionTable_glTexEnvf(*args, **kwargs): pass
def MGLFunctionTable_glDeleteProgramsNV(*args, **kwargs): pass
def MRenderData_bottom_get(*args, **kwargs): pass
def MGLFunctionTable_glGetPixelMapusv(*args, **kwargs): pass
def MGeometryList_isDone(*args, **kwargs): pass
def MHwrCallback_deviceReset(*args, **kwargs): pass
def MCommonRenderSettingsData_framePadding_get(*args, **kwargs): pass
def MGLFunctionTable_glRectf(*args, **kwargs): pass
def MUniformParameter_hasChanged(*args, **kwargs): pass
def new_charPtr(*args, **kwargs): pass
def MGLFunctionTable_glNormal3d(*args, **kwargs): pass
def MRenderUtil_swigregister(*args, **kwargs): pass
def MUniformParameter_setRangeMax(*args, **kwargs): pass
def MGLFunctionTable_glColor3bv(*args, **kwargs): pass
def MGLFunctionTable_glTexCoord4s(*args, **kwargs): pass
def new_uIntPtr(*args, **kwargs): pass
def MGeometryRequirementsLegacy_addFaceOffsets(*args, **kwargs): pass
def MLightLinks_getShadowLinkedLights(*args, **kwargs): pass
def MGLFunctionTable_glRectfv(*args, **kwargs): pass
def new_MD3D9Renderer(*args, **kwargs): pass
def MRenderingInfo_cameraPath(*args, **kwargs): pass
def MGeometryData_uniqueID(*args, **kwargs): pass
def MGeometryPrimitive_drawPrimitiveType(*args, **kwargs): pass
def MGLFunctionTable_glProgramString(*args, **kwargs): pass
def MUniformParameter_swigregister(*args, **kwargs): pass
def MGLFunctionTable_glCombinerInputNV(*args, **kwargs): pass
def MRenderProfile_hasRenderer(*args, **kwargs): pass
def MRenderTargetLegacy_width(*args, **kwargs): pass
def MGLFunctionTable_glGenFragmentShadersATI(*args, **kwargs): pass
def MGeometryPrimitive_dataType(*args, **kwargs): pass
def MGLFunctionTable_glMultiTexCoord4iv(*args, **kwargs): pass
def MRenderCallback_renderCallback(*args, **kwargs): pass
def MGLFunctionTable_glFogCoorddvEXT(*args, **kwargs): pass
def delete_MGeometryData(*args, **kwargs): pass
def delete_floatPtr(*args, **kwargs): pass
def MRenderingInfo_originY(*args, **kwargs): pass
def MGeometryList_viewMatrix(*args, **kwargs): pass
def MGLFunctionTable_glGetObjectParameterfvARB(*args, **kwargs): pass
def MGLFunctionTable_glGetBufferPointervARB(*args, **kwargs): pass
def MRenderUtil_noiseTableSize(*args, **kwargs): pass
def MVaryingParameter_type(*args, **kwargs): pass
def MRenderShadowData_perspectiveMatrix_set(*args, **kwargs): pass
def MGLFunctionTable_glFogCoordPointerEXT(*args, **kwargs): pass
def RV_PIXEL_b_get(*args, **kwargs): pass
def MViewportRenderer_nativelySupports(*args, **kwargs): pass
def MGLFunctionTable_swigregister(*args, **kwargs): pass
def MRenderCallback_postProcessCallback(*args, **kwargs): pass
def MGLFunctionTable_glTexParameterfv(*args, **kwargs): pass
def charPtr_frompointer(*args, **kwargs): pass
def MGLFunctionTable_glGetVertexAttribPointervNV(*args, **kwargs): pass
def MRenderData_bytesPerChannel_set(*args, **kwargs): pass
def MGeometryLegacy_color(*args, **kwargs): pass
def MGLFunctionTable_glGetCombinerInputParameterivNV(*args, **kwargs): pass
def MGLFunctionTable_glGetTexParameteriv(*args, **kwargs): pass
def MGLFunctionTable_glMultTransposeMatrixf(*args, **kwargs): pass
def MViewportRenderer_render(*args, **kwargs): pass
def MCommonRenderSettingsData_skipExistingFrames_set(*args, **kwargs): pass
def MGLFunctionTable_glDeleteQueriesARB(*args, **kwargs): pass
def MRenderUtil_exactFileTextureName(*args, **kwargs): pass
def MUniformParameter_getSource(*args, **kwargs): pass
def MRenderShadowData_worldToZbuffer(*args, **kwargs): pass
def MGLFunctionTable_glColorFragmentOp1ATI(*args, **kwargs): pass
def MViewportRenderer_uninitialize(*args, **kwargs): pass
def MGLFunctionTable_glGetCombinerOutputParameterfvNV(*args, **kwargs): pass
def MGLFunctionTable_glTexCoord4iv(*args, **kwargs): pass
def MGLFunctionTable_glVertexWeightPointerEXT(*args, **kwargs): pass
def MRenderSetup_swigregister(*args, **kwargs): pass
def MGLFunctionTable_glMultiTexCoord4f(*args, **kwargs): pass
def MCommonRenderSettingsData_name_get(*args, **kwargs): pass
def delete_MSwatchRenderBase(*args, **kwargs): pass
def MGLFunctionTable_glFinalCombinerInputNV(*args, **kwargs): pass
def MGLFunctionTable_glGetCombinerOutputParameterivNV(*args, **kwargs): pass
def MGLFunctionTable_glPassThrough(*args, **kwargs): pass
def MGLFunctionTable_glGetProgramEnvParameterfv(*args, **kwargs): pass
def MGLFunctionTable_glGenRenderbuffersEXT(*args, **kwargs): pass
def shortPtr_cast(*args, **kwargs): pass
def MGLFunctionTable_glCallList(*args, **kwargs): pass
def MGLFunctionTable_glTexCoord2iv(*args, **kwargs): pass
def MGLFunctionTable_glBindTexGenParameterEXT(*args, **kwargs): pass
def MGLFunctionTable_glInterleavedArrays(*args, **kwargs): pass
def MLightLinks_getLinkedObjects(*args, **kwargs): pass
def MFnRenderPass_swigregister(*args, **kwargs): pass
def MGLFunctionTable_glClearIndex(*args, **kwargs): pass
def MGLFunctionTable_glMultiTexCoord2dv(*args, **kwargs): pass
def MGLFunctionTable_glVertexAttribs4svNV(*args, **kwargs): pass
def MRenderShadowData_perspective_get(*args, **kwargs): pass
def MGLFunctionTable_glVertexAttrib4Nuiv(*args, **kwargs): pass
def MGLFunctionTable_glUniformMatrix3fvARB(*args, **kwargs): pass
def MGLFunctionTable_glShadeModel(*args, **kwargs): pass
def RV_AOV_numberOfChannels_set(*args, **kwargs): pass
def MGLFunctionTable_glExtractComponentEXT(*args, **kwargs): pass
def new_MLightLinks(*args, **kwargs): pass
def MHwrCallback_deviceLost(*args, **kwargs): pass
def MFnRenderLayer_passHasLight(*args, **kwargs): pass
def doublePtr_cast(*args, **kwargs): pass
def MGLFunctionTable_glVertex4sv(*args, **kwargs): pass
def new_boolPtr(*args, **kwargs): pass
def MGLFunctionTable_glVertexAttrib3svNV(*args, **kwargs): pass
def MGLFunctionTable_glGetObjectParameterivARB(*args, **kwargs): pass
def MRenderProfile_addRenderer(*args, **kwargs): pass
def MGeometryPrimitive_uniqueID(*args, **kwargs): pass
def MGLFunctionTable_glListBase(*args, **kwargs): pass
def MGLFunctionTable_glSampleCoverage(*args, **kwargs): pass
def MGLFunctionTable_glVertexAttrib2dv(*args, **kwargs): pass
def MFnRenderLayer_className(*args, **kwargs): pass
def RV_PIXEL_b_set(*args, **kwargs): pass
def delete_MGeometryLegacy(*args, **kwargs): pass
def MGeometryRequirementsLegacy_addTangent(*args, **kwargs): pass
def MRenderData_aspectRatio_set(*args, **kwargs): pass
def MVaryingParameter_assign(*args, **kwargs): pass
def MDrawProcedureBase_setEnabled(*args, **kwargs): pass
def MGLFunctionTable_glDepthFunc(*args, **kwargs): pass
def MGLFunctionTable_glCompressedTexSubImage2D(*args, **kwargs): pass
def MGLFunctionTable_glVertex2s(*args, **kwargs): pass
def MGLFunctionTable_glDrawElements(*args, **kwargs): pass
def MGLFunctionTable_glVertexAttrib1dNV(*args, **kwargs): pass
def MGLFunctionTable_glMapGrid2f(*args, **kwargs): pass
def MGLFunctionTable_glVertexAttrib1d(*args, **kwargs): pass
def MGLFunctionTable_glRasterPos3d(*args, **kwargs): pass
def MCommonRenderSettingsData_renumberBy_get(*args, **kwargs): pass
def MGLFunctionTable_glGetBufferSubDataARB(*args, **kwargs): pass
def MGLFunctionTable_glVertexAttrib3dv(*args, **kwargs): pass
def delete_MVaryingParameter(*args, **kwargs): pass
def MGLFunctionTable_glVertex3iv(*args, **kwargs): pass
def MGLFunctionTable_glRasterPos2sv(*args, **kwargs): pass
def MGLFunctionTable_numTexUnits(*args, **kwargs): pass
def MGLFunctionTable_glCullParameterfvEXT(*args, **kwargs): pass
def MGLFunctionTable_glBindBufferRangeEXT(*args, **kwargs): pass
def MCommonRenderSettingsData_postRenderLayerMel_get(*args, **kwargs): pass
def MGLFunctionTable_glColor4ub(*args, **kwargs): pass
def MGLFunctionTable_glTexGeniv(*args, **kwargs): pass
def delete_charPtr(*args, **kwargs): pass
def MGLFunctionTable_glGetTrackMatrixivNV(*args, **kwargs): pass
def MRenderShadowData_shadowResY_get(*args, **kwargs): pass
def MGeometryLegacy_position(*args, **kwargs): pass
def MGLFunctionTable_glVertexAttrib4sNV(*args, **kwargs): pass
def MGLFunctionTable_glGetTexImage(*args, **kwargs): pass
def MGLFunctionTable_numTexInterpolants(*args, **kwargs): pass
def MGLFunctionTable_glCompressedTexSubImage3D(*args, **kwargs): pass
def MCommonRenderSettingsData_frameEnd_set(*args, **kwargs): pass
def MGLFunctionTable_glGetOcclusionQueryuivNV(*args, **kwargs): pass
def MRenderUtil_raytraceFirstGeometryIntersections(*args, **kwargs): pass
def MUniformParameter_getAsInt(*args, **kwargs): pass
def MGLFunctionTable_glPopAttrib(*args, **kwargs): pass
def MGLFunctionTable_glBeginFragmentShaderATI(*args, **kwargs): pass
def MGLFunctionTable_glGenerateMipmapEXT(*args, **kwargs): pass
def MGLFunctionTable_glIsEnabled(*args, **kwargs): pass
def MSwatchRenderRegister_swigregister(*args, **kwargs): pass
def MGLFunctionTable_glColor3ub(*args, **kwargs): pass
def MGLFunctionTable_glTexCoord4dv(*args, **kwargs): pass
def MRenderUtil_noise3(*args, **kwargs): pass
def MGLFunctionTable_glIndexMask(*args, **kwargs): pass
def MGLFunctionTable_glGetLocalConstantIntegervEXT(*args, **kwargs): pass
def MRenderData_perspective_get(*args, **kwargs): pass
def MGLFunctionTable_glGetLightiv(*args, **kwargs): pass
def delete_intPtr(*args, **kwargs): pass
def MGLFunctionTable_glMultiTexCoord3s(*args, **kwargs): pass
def MCommonRenderSettingsData_getBufferName(*args, **kwargs): pass
def MGLFunctionTable_glCombinerParameterivNV(*args, **kwargs): pass
def MCommonRenderSettingsData_isMovieFormat(*args, **kwargs): pass
def MUniformParameter_setSoftRangeMin(*args, **kwargs): pass
def MGLFunctionTable_glNormal3s(*args, **kwargs): pass
def MGLFunctionTable_glIndexPointer(*args, **kwargs): pass
def MGLFunctionTable_glProgramLocalParameter4dv(*args, **kwargs): pass
def MGLFunctionTable_glGetAttribLocationARB(*args, **kwargs): pass
def MRenderData_internalData_set(*args, **kwargs): pass
def MGLFunctionTable_glBegin(*args, **kwargs): pass
def MGLFunctionTable_glTexCoord2dv(*args, **kwargs): pass
def MGLFunctionTable_glEnableVariantClientStateEXT(*args, **kwargs): pass
def MFnRenderPass_frameBufferChannels(*args, **kwargs): pass
def MDrawProcedureBase_name(*args, **kwargs): pass
def MGLFunctionTable_glFlush(*args, **kwargs): pass
def MGLFunctionTable_glMultiTexCoord1iv(*args, **kwargs): pass
def MGLFunctionTable_glTexCoord1d(*args, **kwargs): pass
def MGLFunctionTable_glVertexAttribs2dvNV(*args, **kwargs): pass
def MGLFunctionTable_glVertexAttrib4Nsv(*args, **kwargs): pass
def MGLFunctionTable_glUniform2ivARB(*args, **kwargs): pass
def MUniformParameter_setRangeMin(*args, **kwargs): pass
def MGLFunctionTable_glClear(*args, **kwargs): pass
def MGLFunctionTable_glScaled(*args, **kwargs): pass
def MGLFunctionTable_glTexCoord1dv(*args, **kwargs): pass
def MGLFunctionTable_glShaderOp3EXT(*args, **kwargs): pass
def MHardwareRenderer_swigregister(*args, **kwargs): pass
def MFnRenderLayer_isPlugAdjusted(*args, **kwargs): pass
def MGLFunctionTable_glEnableClientState(*args, **kwargs): pass
def MGLFunctionTable_glVertex4fv(*args, **kwargs): pass
def doublePtr_value(*args, **kwargs): pass
def MGLFunctionTable_glVertexAttrib1dvNV(*args, **kwargs): pass
def MRenderingInfo_swigregister(*args, **kwargs): pass
def new_MGeometryManager(*args, **kwargs): pass
def MGLFunctionTable_glSecondaryColor3dvEXT(*args, **kwargs): pass
def MGLFunctionTable_glLightiv(*args, **kwargs): pass
def MGLFunctionTable_glVertexAttrib1fv(*args, **kwargs): pass
def MGLFunctionTable_glMultiDrawArrays(*args, **kwargs): pass
def MGLFunctionTable_glAttachObjectARB(*args, **kwargs): pass
def RV_PIXEL_r_set(*args, **kwargs): pass
def MGLFunctionTable_glRasterPos4i(*args, **kwargs): pass
def MLightLinks_swigregister(*args, **kwargs): pass
def MRenderTargetLegacy_writeColorBuffer(*args, **kwargs): pass
def MGLFunctionTable_glSecondaryColor3uiEXT(*args, **kwargs): pass
def delete_MD3D9Renderer(*args, **kwargs): pass
def MGLFunctionTable_glCopyTexSubImage2D(*args, **kwargs): pass
def MGLFunctionTable_glVertex2f(*args, **kwargs): pass
def new_shortPtr(*args, **kwargs): pass
def MRenderView_startRender(*args, **kwargs): pass
def MGLFunctionTable_glMultiDrawElements(*args, **kwargs): pass
def MGLFunctionTable_glTrackMatrixNV(*args, **kwargs): pass
def floatPtr_value(*args, **kwargs): pass
def MRenderCallback_addRenderTileCallback(*args, **kwargs): pass
def MGeometryList_reset(*args, **kwargs): pass
def MGLFunctionTable_glIndexiv(*args, **kwargs): pass
def MGLFunctionTable_glMultTransposeMatrixfARB(*args, **kwargs): pass
def MCommonRenderSettingsData_renumberFrames_get(*args, **kwargs): pass
def MGLFunctionTable_glGenBuffersARB(*args, **kwargs): pass
def MRenderUtil_lightAttenuation(*args, **kwargs): pass
def MUniformParameterList_setElement(*args, **kwargs): pass
def MGLFunctionTable_glPrioritizeTextures(*args, **kwargs): pass
def MGLFunctionTable_glRasterPos2i(*args, **kwargs): pass
def MGLFunctionTable_glPNTrianglesfATI(*args, **kwargs): pass
def MGLFunctionTable_glVariantbvEXT(*args, **kwargs): pass
def MGLFunctionTable_glTransformFeedbackVaryingsNV(*args, **kwargs): pass
def MCommonRenderSettingsData_postMel_get(*args, **kwargs): pass
def MViewportRenderer_setUIName(*args, **kwargs): pass
def MGeometryLegacy_data(*args, **kwargs): pass
def MGLFunctionTable_glColor4i(*args, **kwargs): pass
def MGLFunctionTable_glTexGendv(*args, **kwargs): pass
def MUniformParameter_numColumns(*args, **kwargs): pass
def MVaryingParameter_getElementSize(*args, **kwargs): pass
def new_MGeometryLegacy(*args, **kwargs): pass
def MGLFunctionTable_glGetTexEnviv(*args, **kwargs): pass
def MGLFunctionTable_glCompressedTexImage2D(*args, **kwargs): pass
def MCommonRenderSettingsData_customImageFormat_set(*args, **kwargs): pass
def MGLFunctionTable_glVariantsvEXT(*args, **kwargs): pass
def MGLFunctionTable_glIsOcclusionQueryNV(*args, **kwargs): pass
def MGLFunctionTable_glPointSize(*args, **kwargs): pass
def MGLFunctionTable_glIsProgram(*args, **kwargs): pass
def MGLFunctionTable_glFramebufferTexture2DEXT(*args, **kwargs): pass
def MGLFunctionTable_glTexCoord4f(*args, **kwargs): pass
def MGLFunctionTable_glColor3i(*args, **kwargs): pass
def MDrawProcedureBase_swigregister(*args, **kwargs): pass
def new_MRenderShadowData(*args, **kwargs): pass
def MGLFunctionTable_glTexCoord3s(*args, **kwargs): pass
def MGLFunctionTable_glGetInvariantBooleanvEXT(*args, **kwargs): pass
def MGLFunctionTable_glBeginQueryARB(*args, **kwargs): pass
def new_MRenderData(*args, **kwargs): pass
def MFnImageSource_swigregister(*args, **kwargs): pass
def MGLFunctionTable_glProgramEnvParameter4d(*args, **kwargs): pass
def MGLFunctionTable_glGetError(*args, **kwargs): pass
def MGLFunctionTable_glMultiTexCoord3f(*args, **kwargs): pass
def MCommonRenderSettingsData_setPassName(*args, **kwargs): pass
def MGLFunctionTable_glIsFenceNV(*args, **kwargs): pass
def MUniformParameter_numElements(*args, **kwargs): pass
def MGLFunctionTable_glNormal3f(*args, **kwargs): pass
def MGLFunctionTable_glProgramEnvParameter4dv(*args, **kwargs): pass
def MGLFunctionTable_glEndQueryARB(*args, **kwargs): pass
def MGLFunctionTable_glGetUniformivARB(*args, **kwargs): pass
def MGLFunctionTable_glGetUniformfvARB(*args, **kwargs): pass
def new_MRenderView(*args, **kwargs): pass
def MGLFunctionTable_glAccum(*args, **kwargs): pass
def MHardwareRenderer_makeResourceContextCurrent(*args, **kwargs): pass
def MGLFunctionTable_glTexCoord1iv(*args, **kwargs): pass
def MGeometryList_MSetupFlags_get(*args, **kwargs): pass
def MGLFunctionTable_glVariantubvEXT(*args, **kwargs): pass
def MHwTextureManager_glBind(*args, **kwargs): pass
def MRenderProfile_swigregister(*args, **kwargs): pass
def new_MFnRenderPass(*args, **kwargs): pass
def MGLFunctionTable_glMultiTexCoord1f(*args, **kwargs): pass
def MRenderView_className(*args, **kwargs): pass
def MGLFunctionTable_glVertexAttribs1fvNV(*args, **kwargs): pass
def MGLFunctionTable_glBlendFunc(*args, **kwargs): pass
def MRenderSetupPrivate__triggerSelectionChanged(*args, **kwargs): pass
def MGLFunctionTable_glVertexAttrib4uiv(*args, **kwargs): pass
def MGLFunctionTable_glUniform2fvARB(*args, **kwargs): pass
def MVaryingParameterList_getElement(*args, **kwargs): pass
def MGLFunctionTable_glRectsv(*args, **kwargs): pass
def MGLFunctionTable_glGenVertexShadersEXT(*args, **kwargs): pass
def MGLFunctionTable_glIndexubv(*args, **kwargs): pass
def MFnRenderLayer_inLayer(*args, **kwargs): pass
def MGLFunctionTable_glEdgeFlag(*args, **kwargs): pass
def floatPtr_swigregister(*args, **kwargs): pass
def MGLFunctionTable_glVertexAttrib4dNV(*args, **kwargs): pass
def MGeometryManager_getGeometry(*args, **kwargs): pass
def MGLFunctionTable_glLightModeliv(*args, **kwargs): pass
def MGLFunctionTable_glTexCoord2s(*args, **kwargs): pass
def MGLFunctionTable_glVertexAttrib4d(*args, **kwargs): pass
def MCommonRenderSettingsData_dotPerInch_set(*args, **kwargs): pass
def MGLFunctionTable_glCreateShaderObjectARB(*args, **kwargs): pass
def MGLFunctionTable_glCallLists(*args, **kwargs): pass
def MRenderShadowData_perspectiveMatrix_get(*args, **kwargs): pass
def MGLFunctionTable_glRasterPos4d(*args, **kwargs): pass
def MGLFunctionTable_glSecondaryColor3sEXT(*args, **kwargs): pass
def MD3D9Renderer_readSwatchContextPixels(*args, **kwargs): pass
def MGLFunctionTable_glCopyPixels(*args, **kwargs): pass
def MGLFunctionTable_glTranslated(*args, **kwargs): pass
def intPtr_value(*args, **kwargs): pass
def MGLFunctionTable_glProgramParameter4dvNV(*args, **kwargs): pass
def MGLFunctionTable_glClipPlane(*args, **kwargs): pass
def MRenderData_eyePoint_get(*args, **kwargs): pass
def new_MGeometryList(*args, **kwargs): pass
def MGLFunctionTable_glIndexdv(*args, **kwargs): pass
def MRenderData_internalData_get(*args, **kwargs): pass
def MGLFunctionTable_glPointParameterf(*args, **kwargs): pass
def MCommonRenderSettingsData_useCustomExt_get(*args, **kwargs): pass
def MGLFunctionTable_glGetQueryObjectivARB(*args, **kwargs): pass
def MRenderUtil_mainBeautyPassCustomTokenString(*args, **kwargs): pass
def MUniformParameterList_append(*args, **kwargs): pass
def MGLFunctionTable_glRasterPos2d(*args, **kwargs): pass
def delete_MGeometryRequirementsLegacy(*args, **kwargs): pass
def MGLFunctionTable_glProgramEnvParameter4f(*args, **kwargs): pass
def MGLFunctionTable_glAlphaFragmentOp3ATI(*args, **kwargs): pass
def MGLFunctionTable_glGetActiveVaryingNV(*args, **kwargs): pass
def MGLFunctionTable_glColor3b(*args, **kwargs): pass
def MViewportRenderer_registerRenderer(*args, **kwargs): pass
def MGLFunctionTable_glTexEnvfv(*args, **kwargs): pass
def MRenderData_bottom_set(*args, **kwargs): pass
def MGLFunctionTable_glExecuteProgramNV(*args, **kwargs): pass
def MRenderSetupPrivate_className(*args, **kwargs): pass
def MGeometryData_setObjectOwnsData(*args, **kwargs): pass
def MGLFunctionTable_glGetPointerv(*args, **kwargs): pass
def MGLFunctionTable_glMultiTexCoord4sv(*args, **kwargs): pass
def MCommonRenderSettingsData_namePattern_set(*args, **kwargs): pass
def MGLFunctionTable_glGetFinalCombinerInputParameterfvNV(*args, **kwargs): pass
def MGLFunctionTable_glIsList(*args, **kwargs): pass
def MRenderShadowData_swigregister(*args, **kwargs): pass
def MUniformParameter_getAsFloatArray(*args, **kwargs): pass
def MGLFunctionTable_glGetVertexAttribdv(*args, **kwargs): pass
def MGLFunctionTable_glDeleteFramebuffersEXT(*args, **kwargs): pass
def MSwatchRenderBase_renderQuality(*args, **kwargs): pass
def MGLFunctionTable_glColor3d(*args, **kwargs): pass
def MGLFunctionTable_glTexCoord3f(*args, **kwargs): pass
def MGLFunctionTable_glVertexAttribs4dvNV(*args, **kwargs): pass
def MGLFunctionTable_glGetVariantIntegervEXT(*args, **kwargs): pass
def MViewportRenderer_name(*args, **kwargs): pass
def MGLFunctionTable_glIsTexture(*args, **kwargs): pass
def MGLFunctionTable_glGenTextures(*args, **kwargs): pass
def MGLFunctionTable_glDeleteFencesNV(*args, **kwargs): pass
def MVaryingParameterList_setLength(*args, **kwargs): pass
def MUniformParameter_type(*args, **kwargs): pass
def MGLFunctionTable_glNormal3b(*args, **kwargs): pass
def MGLFunctionTable_glBindProgram(*args, **kwargs): pass


MGL_MAP1_VERTEX_ATTRIB10_4_NV = 34410

MGL_OP_ROUND_EXT = 34704

MGLFunctionTable_kMGL_Version13 = 3

MGL_TEXTURE_COORD_ARRAY_TYPE_EXT = 32905

MViewportRenderer_kExcludeFollicles = 4194304

MGL_VARIANT_EXT = 34753

kMGLext_NV_vertex_program = 72

MGL_OP_FLOOR_EXT = 34703

MViewportRenderer_kExcludeDynamicConstraints = 134217728

MGL_TEXTURE_COMPRESSED = 34465

MGL_DSDT_NV = 34549

MGL_TEXTURE_COORD_ARRAY_SIZE_EXT = 32904

MGL_VERTEX_ARRAY = 32884

MGL_STENCIL_BITS = 3415

MGL_OP_CLAMP_EXT = 34702

MGL_TEXTURE_DEPTH_TYPE = 35862

MGL_HILO_NV = 34548

MGL_INDEX_ARRAY_COUNT_EXT = 32903

MGL_TEXTURE_MAG_SIZE_NV = 34591

MGL_TEXTURE9_ARB = 33993

MGL_DOT_PRODUCT_CONST_EYE_REFLECT_CUBE_MAP_NV = 34547

MGL_MAP1_NORMAL = 3474

MGL_INDEX_ARRAY_STRIDE_EXT = 32902

MGL_FLOAT_RGB32_NV = 34953

MGL_OP_SET_GE_EXT = 34700

MGL_PIXEL_MAP_A_TO_A_SIZE = 3257

MGL_DOT_PRODUCT_REFLECT_CUBE_MAP_NV = 34546

MUniformParameter_kSemanticViewInverseTransposeMatrix = 18

MGL_INDEX_ARRAY_TYPE_EXT = 32901

MGL_RASTERIZER_DISCARD_NV = 35977

MGL_OP_MIN_EXT = 34699

MGL_COMBINER_MUX_SUM_NV = 34119

MGL_MATRIX27 = 35035

MGL_DOT_PRODUCT_DIFFUSE_CUBE_MAP_NV = 34545

MGL_SOURCE1_RGB_EXT = 34177

MGL_PASS_THROUGH_NV = 34534

kMGLext_MGLX_create_new_context = 92

MGL_MODELVIEW1_EXT = 34058

MGL_OP_MAX_EXT = 34698

kMGLext_MGLX_get_visual_from_fbconfig_sgix = 98

MGL_DOT_PRODUCT_TEXTURE_CUBE_MAP_NV = 34544

MGL_PACK_ROW_LENGTH = 3330

MGL_MAX_FRAGMENT_PROGRAM_LOCAL_PARAMETERS_NV = 34920

MGL_COLOR_ARRAY_STRIDE_EXT = 32899

MGL_OP_FRAC_EXT = 34697

MGL_TEXTURE_COMPRESSED_IMAGE_SIZE = 34464

MUniformParameter_kSemanticHWSHighlighting = 59

MGL_DOT_PRODUCT_TEXTURE_3D_NV = 34543

MGL_COLOR_ARRAY_TYPE_EXT = 32898

MGL_PN_TRIANGLES_POINT_MODE_CUBIC_ATI = 34806

MGL_OP_MADD_EXT = 34696

MGL_COLOR_ARRAY_SIZE_EXT = 32897

MGL_OP_ADD_EXT = 34695

MGL_POSITION = 4611

MGL_DOT_PRODUCT_DEPTH_REPLACE_NV = 34541

MGL_NORMAL_ARRAY_COUNT_EXT = 32896

MGL_VERTEX_WEIGHT_ARRAY_STRIDE_EXT = 34063

MGL_OP_MUL_EXT = 34694

MGL_SHADE_MODEL = 2900

MGL_VERTEX_ATTRIB_ARRAY_NORMALIZED = 34922

MGL_DOT_PRODUCT_NV = 34540

MGL_NORMAL_ARRAY_STRIDE_EXT = 32895

MGL_LOCAL_CONSTANT_DATATYPE_EXT = 34797

MGL_MATRIX26 = 35034

MGL_RED_SCALE = 3348

MGL_NORMAL_ARRAY_TYPE_EXT = 32894

MGL_COLOR_SUM_CLAMP_NV = 34127

MGL_OP_DOT3_EXT = 34692

MGL_SIGNED_INTENSITY8_NV = 34568

MUniformParameter_kSemanticProjectionInverseTransposeMatrix = 21

MGL_LUMINANCE16_ALPHA16 = 32840

MGL_TRANSFORM_FEEDBACK_BUFFER_NV = 35982

MGL_VERTEX_ARRAY_COUNT_EXT = 32893

MGL_OP_NEGATE_EXT = 34691

MGL_RGB10_A2 = 32857

MGL_OP_RECIP_SQRT_EXT = 34709

MGL_LUMINANCE12_ALPHA12 = 32839

MGL_REG_27_ATI = 35132

MGL_REG_8_ATI = 35113

MGL_SHADER_OPERATION_NV = 34527

MGL_TEXTURE_CUBE_MAP = 34067

MGL_READ_WRITE_ARB = 35002

MGL_VERTEX_ARRAY_TYPE_EXT = 32891

MGL_VERTEX_SHADER_BINDING_EXT = 34689

MGL_PACK_SKIP_IMAGES_EXT = 32875

MGL_SPECULAR = 4610

MGL_LUMINANCE8_ALPHA8 = 32837

MGL_VERTEX_ARRAY_SIZE_EXT = 32890

MGL_VERTEX_WEIGHT_ARRAY_TYPE_EXT = 34062

MGL_TRANSFORM_FEEDBACK_BUFFER_START_EXT = 35972

MGL_VERTEX_SHADER_EXT = 34688

MGL_TEXTURE_CUBE_MAP_NEGATIVE_X_ARB = 34070

MGL_PN_TRIANGLES_NORMAL_MODE_QUADRATIC_ATI = 34808

MGL_MATRIX25 = 35033

MGL_LUMINANCE4_ALPHA4 = 32835

MGL_POINT_TOKEN = 1793

MGL_MATRIX4_NV = 34356

MGL_PREVIOUS_TEXTURE_INPUT_NV = 34532

MGL_PN_TRIANGLES_NORMAL_MODE_LINEAR_ATI = 34807

MGL_TRANSPOSE_COLOR_MATRIX = 34022

MGL_LUMINANCE16 = 32834

MGL_VERTEX_ATTRIB_ARRAY_TYPE = 34341

MGL_MATRIX3_NV = 34355

MGL_Y_EXT = 34774

MGL_MAX_PROGRAM_ALU_INSTRUCTIONS_ARB = 34827

MGL_COMPRESSED_RGBA = 34030

MGL_TEXTURE_HI_SIZE_NV = 34587

MGL_GREEN = 6404

MGL_TEXTURE_RESIDENT = 32871

kMGLext_EXT_texture_filter_anisotropic = 60

MGL_PN_TRIANGLES_POINT_MODE_LINEAR_ATI = 34805

MGL_LUMINANCE8 = 32832

MGL_VERTEX_ATTRIB_ARRAY10_NV = 34394

MGL_MATRIX1_NV = 34353

MGL_PN_TRIANGLES_TESSELATION_LEVEL_ATI = 34804

MGL_READ_FRAMEBUFFER = 36008

MGL_LUMINANCE4 = 32831

MGL_UNPACK_SKIP_ROWS = 3315

MGL_VERTEX_WEIGHT_ARRAY_SIZE_EXT = 34061

MGL_OUTPUT_TEXTURE_COORD16_EXT = 34733

MGL_ALPHA16 = 32830

MGL_ARRAY_BUFFER_BINDING_ARB = 34964

MGL_MAX_TRACK_MATRICES_NV = 34351

MGL_EXPAND_NORMAL_NV = 34104

MGL_MATRIX24 = 35032

MGL_ALPHA12 = 32829

MGL_TEXTURE1_ARB = 33985

MGL_MAX_TRACK_MATRIX_STACK_DEPTH_NV = 34350

MGL_MAP1_VERTEX_ATTRIB5_4_NV = 34405

MGL_UNSIGNED_INVERT_NV = 34103

MGL_STATIC_READ_ARB = 35045

MGL_ALPHA8 = 32828

MGL_OUTPUT_FOG_EXT = 34749

MGL_SCALE_BY_FOUR_NV = 34111

kMGLext_WMGL_ARB_pixel_format = 86

MGL_ALPHA16F = 34844

MGL_ALPHA4 = 32827

MGL_MAX_TRANSFORM_FEEDBACK_SEPARATE_ATTRIBS_EXT = 35979

MGL_TRANSPOSE_NV = 34348

MGL_UNPACK_SKIP_IMAGES = 32877

MGL_SPARE0_PLUS_SECONDARY_COLOR_NV = 34098

MGL_POLYGON_OFFSET_FILL = 32823

MGL_OP_DOT4_EXT = 34693

MGL_INVERSE_NV = 34347

MGL_TEXTURE20 = 34004

MGL_POLYGON_OFFSET_LINE = 10754

MGL_IDENTITY_NV = 34346

MGL_SIGNED_LUMINANCE8_NV = 34562

MGL_OPERAND1_RGB = 34193

MGL_DISCARD_NV = 34096

MUniformParameter_kSemanticProjectionTransposeMatrix = 37

MGL_POLYGON_OFFSET_POINT = 10753

MGL_LIGHT5 = 16389

MGL_SPARE1_NV = 34095

MGL_FOG_DENSITY = 2914

MGL_MUL_ATI = 35172

MGL_POLYGON_OFFSET_UNITS = 10752

MGL_ALWAYS = 519

MGL_PROGRAM_LENGTH_NV = 34343

kMGLext_NV_vertex_array_range = 71

MGL_SECONDARY_COLOR_NV = 34093

MGL_TEXTURE_COORD_ARRAY_TYPE = 32905

MViewportRenderer_kExcludeNCloths = 33554432

MGL_REPEAT = 10497

MGL_CURRENT_ATTRIB_NV = 34342

MGL_PACK_IMAGE_HEIGHT_EXT = 32876

MGL_TEXTURE14 = 33998

MGL_PRIMARY_COLOR_NV = 34092

MGL_ATTRIB_ARRAY_TYPE_NV = 34341

MGL_SOURCE2_ALPHA = 34186

kMGLext_WMGL_ARB_pbuffer = 85

MGL_CONSTANT_COLOR1_NV = 34091

MGL_SECONDARY_COLOR_ARRAY_STRIDE_EXT = 33884

MGL_CLIENT_ACTIVE_TEXTURE_ARB = 34017

MGL_MAP1_INDEX = 3473

MGL_ATTRIB_ARRAY_STRIDE_NV = 34340

MGL_FLOAT_R16_NV = 34948

MGL_CONSTANT_COLOR0_NV = 34090

MGL_STEREO = 3123

MGL_ACTIVE_TEXTURE_ARB = 34016

MUniformParameter_kSemanticViewInverseMatrix = 17

MGL_TRANSFORM_FEEDBACK_PRIMITIVES_WRITTEN_NV = 35976

MGL_ONE_MINUS_CONSTANT_ALPHA_EXT = 32772

MGL_SOURCE0_RGB_EXT = 34176

MGL_MVP_MATRIX_EXT = 34787

MGL_VARIABLE_F_NV = 34088

MGL_TEXTURE30_ARB = 34014

MGL_MAX_TRANSFORM_FEEDBACK_INTERLEAVED_COMPONENTS_NV = 35978

MGL_PROGRAM_ERROR_STRING_NV = 34932

MGL_VERTEX_PROGRAM_NV = 34336

MGL_VARIABLE_E_NV = 34087

MGL_EDGE_FLAG_ARRAY_EXT = 32889

MGL_TEXTURE_COORD_ARRAY_SIZE = 32904

MGL_VERTEX_PROGRAM_TWO_SIDE = 34371

MGL_LINEAR_MIPMAP_LINEAR = 9987

MGL_PACK_IMAGE_HEIGHT = 32876

MGL_VARIABLE_D_NV = 34086

MGL_NEAREST_MIPMAP_LINEAR = 9986

MGL_COLOR_ATTACHMENT4 = 36068

MGL_NUM_LOOPBACK_COMPONENTS_ATI = 35188

MGL_OPERAND3_RGB_NV = 34195

MGL_VARIABLE_C_NV = 34085

MGL_SECONDARY_COLOR_ARRAY_TYPE_EXT = 33883

MGL_LINEAR_MIPMAP_NEAREST = 9985

MUniformParameter_kSemanticWorldInverseMatrix = 14

MGL_VIEWPORT_BIT = 2048

MGL_VARIABLE_A_NV = 34083

MGL_MATRIX21 = 35029

MGL_LINEAR = 9729

MGL_VERSION = 7938

MGL_COMBINE4_NV = 34051

MGL_CURRENT_VERTEX_EXT = 34786

MGL_REGISTER_COMBINERS_NV = 34082

MGL_NEAREST = 9728

MGL_OUTPUT_TEXTURE_COORD29_EXT = 34746

MGL_OPERAND2_ALPHA_EXT = 34202

MGL_VERTEX_ATTRIB_ARRAY9_NV = 34393

MGL_PROGRAM_ATTRIBS = 34988

MGL_COMPRESSED_LUMINANCE = 34026

MGL_FRAMEBUFFER_BINDING = 36006

MGL_EYE_PLANE = 9474

MGL_OPERAND1_ALPHA_EXT = 34201

MGL_FRAMEBUFFER_ATTACHMENT_OBJECT_TYPE = 36048

MGL_VERTEX_ARRAY_RANGE_POINTER_NV = 34081

MGL_OBJECT_PLANE = 9473

MGL_COLOR_MATERIAL = 2903

MGL_OPERAND0_ALPHA_EXT = 34200

MGL_MAX_VERTEX_ARRAY_RANGE_ELEMENT_NV = 34080

MUniformParameter_kSemanticColorTexture = 28

MGL_TEXTURE_LUMINANCE_TYPE = 35860

MGL_TRANSFORM_FEEDBACK_VARYINGS_EXT = 35971

MGL_SPHERE_MAP = 9218

MGL_DEPTH_TEST = 2929

MGL_VERTEX_WEIGHT_ARRAY_EXT = 34060

MGL_VERTEX_ARRAY_RANGE_LENGTH_NV = 34078

MGL_MATRIX20 = 35028

MGL_OBJECT_LINEAR = 9217

MGL_CLAMP_TO_BORDER_ARB = 33069

MGL_OPERAND0_RGB_EXT = 34192

MGL_FULL_RANGE_EXT = 34785

MGL_VERTEX_ARRAY_RANGE_NV = 34077

MGL_TRANSPOSE_TEXTURE_MATRIX = 34021

MGL_OUTPUT_TEXTURE_COORD28_EXT = 34745

MGL_SOURCE2_ALPHA_EXT = 34186

MGL_STENCIL_INDEX = 6401

MGL_X_EXT = 34773

MGL_FIXED_ONLY = 35101

MGL_TEXTURE23_ARB = 34007

MGL_INDEX_ARRAY_TYPE = 32901

MGL_TEXTURE17_ARB = 34001

MGL_TEXTURE_BORDER_VALUES_NV = 34586

MGL_RED = 6403

MGL_PACK_SKIP_IMAGES = 32875

MGL_CLAMP_READ_COLOR = 35100

MGL_DOT_PRODUCT_TEXTURE_2D_NV = 34542

MGL_TEXTURE16_ARB = 34000

MGL_LIGHT4 = 16388

MGL_MATRIX31 = 35039

MGL_VERTEX_WEIGHTING_EXT = 34057

MGL_MAP1_VERTEX_ATTRIB2_4_NV = 34402

MGL_OUTPUT_TEXTURE_COORD15_EXT = 34732

MGL_CLAMP_VERTEX_COLOR = 35098

MGL_DECAL = 8449

MGL_FOG_END = 2916

MGL_VERTEX_ARRAY_RANGE_WITHOUT_FLUSH_NV = 34099

MGL_RGBA_FLOAT_MODE = 34848

MGL_CONSTANT_ALPHA = 32771

MGL_SELECTION_BUFFER_POINTER = 3571

MGL_TEXTURE13_ARB = 33997

MGL_TEXTURE0_ARB = 33984

MGL_NORMALIZED_RANGE_EXT = 34784

MGL_MAX_RECTANGLE_TEXTURE_SIZE = 34040

MGL_VARIANT_DATATYPE_EXT = 34789

MGL_TEXTURE12_ARB = 33996

MGL_PRIMITIVES_GENERATED_NV = 35975

MGL_EVAL_BIT = 65536

MGL_PROXY_TEXTURE_RECTANGLE = 34039

MGL_MAX_CUBE_MAP_TEXTURE_SIZE = 34076

MGL_TEXTURE11_ARB = 33995

MGL_TEXTURE_2D = 3553

MGL_PIXEL_MAP_I_TO_I = 3184

MGL_HINT_BIT = 32768

MGL_PROXY_TEXTURE_3D_EXT = 32880

MGL_MAX_NAME_STACK_DEPTH = 3383

MGL_COLOR_ATTACHMENT1 = 36065

MGL_CONSTANT_EXT = 34166

MGL_TRANSFORM_FEEDBACK_BUFFER_BINDING_EXT = 35983

MGL_SWIZZLE_STR_ATI = 35190

MGL_TEXTURE_RECTANGLE = 34037

MGL_LIGHT3 = 16387

MGL_TEXTURE24 = 34008

MGL_INTERPOLATE_EXT = 34165

MGL_MODELVIEW_MATRIX1_EXT = 34054

MGL_LUMINANCE_ALPHA16F = 34847

MUniformParameter_kSemanticViewTransposeMatrix = 36

MGL_TEXTURE23 = 34007

MGL_TEXTURE_GEN_R = 3170

MGL_NORMAL_MAP = 34065

MGL_ONE_MINUS_CONSTANT_COLOR_EXT = 32770

MGL_TEXTURE22 = 34006

MGL_FUNC_ADD = 32774

MGL_NEGATIVE_ONE_EXT = 34783

kMGLext_SGIS_generate_mipmap = 78

MGL_INTENSITY16F = 34845

MGL_TEXTURE21 = 34005

MGL_RED_BIAS = 3349

MGL_EDGE_FLAG_ARRAY_STRIDE_EXT = 32908

MGL_BLEND_COLOR_EXT = 32773

MGL_TEXTURE_LUMINANCE_SIZE = 32864

MGL_RGB16F = 34843

kMGLext_NV_texture_shader = 70

MGL_TEXTURE19 = 34003

MGL_COLOR_ATTACHMENT0 = 36064

MGL_FOG_START = 2915

MGL_RGBA16F = 34842

MGL_LIGHT2 = 16386

MGL_TEXTURE18 = 34002

MGL_PHONG_HINT_WIN = 33003

MGL_ONE_MINUS_CONSTANT_ALPHA = 32772

MGL_DEPTH_BITS = 3414

MGL_UNPACK_LSB_FIRST = 3313

MGL_OBJECT_LINK_STATUS_ARB = 35714

MGL_CONSTANT_ALPHA_EXT = 32771

MGL_PROGRAM_ERROR_POSITION = 34379

MGL_POLYGON_MODE = 2880

MGL_LINE_SMOOTH_HINT = 3154

MGL_TEXTURE16 = 34000

MGL_FOG_HINT = 3156

MGL_NUM_COMPRESSED_TEXTURE_FORMATS_ARB = 34466

MGL_PROGRAM_STRING = 34344

kMGLext_MGLX_choose_fbconfig_sgix = 96

MGL_SCISSOR_BOX = 3088

MGL_TEXTURE_COORD_ARRAY_EXT = 32888

MGL_SECONDARY_COLOR_ARRAY_EXT = 33886

MGL_UNSIGNED_INT_8_8_8_8_EXT = 32821

MGL_MAX_PROGRAM_ENV_PARAMETERS = 34997

MViewportRenderer_kExcludeFluids = 2097152

MGL_SECONDARY_COLOR_ARRAY_POINTER_EXT = 33885

MGL_MAX_COLOR_ATTACHMENTS = 36063

MGL_CONSTANT_COLOR_EXT = 32769

MGL_ZOOM_X = 3350

MGL_MAX_PROGRAM_LOCAL_PARAMETERS = 34996

MUniformParameter_kSemanticFrameNumber = 47

MGL_LIGHT1 = 16385

MGL_ACCUM = 256

MViewportRenderer_kExcludeNRigids = 67108864

MGL_COMPRESSED_LUMINANCE_ARB = 34026

MGL_MODELVIEW1_STACK_DEPTH_EXT = 34050

MGL_MAX_PROGRAM_NATIVE_ADDRESS_REGISTERS = 34995

MGL_TEXTURE_GREEN_TYPE = 35857

MGL_TEXTURE11 = 33995

MGL_MATRIX19 = 35027

MGL_PROGRAM_NATIVE_ADDRESS_REGISTERS = 34994

MGL_MATRIX16 = 35024

MGL_TEXTURE10 = 33994

MGL_SAMPLE_COVERAGE_ARB = 32928

MGL_CLAMP_TO_EDGE = 33071

MGL_TRANSFORM_FEEDBACK_BUFFER_START_NV = 35972

MUniformParameter_kSemanticWorldViewProjectionInverseTransposeMatrix = 27

MGL_DOT3_RGBA = 34479

MGL_PROGRAM_ADDRESS_REGISTERS = 34992

MGL_NORMAL_ARRAY_STRIDE = 32895

MGL_TEXTURE8 = 33992

MGL_DOT3_RGB = 34478

MGL_SUBTRACT = 34023

MGL_UNSIGNED_SHORT_5_5_5_1_EXT = 32820

MGL_MAX_PROGRAM_NATIVE_ATTRIBS = 34991

MGL_TEXTURE7 = 33991

MGL_TEXTURE4 = 33988

MGL_FRAMEBUFFER_UNSUPPORTED = 36061

MGL_PREVIOUS = 34168

MGL_LIGHT0 = 16384

MGL_RESCALE_NORMAL_EXT = 32826

MGL_TEXTURE6 = 33990

MGL_PRIMARY_COLOR = 34167

MGL_MIRROR_CLAMP_TO_EDGE_ATI = 34627

MGL_MAX_PROGRAM_ATTRIBS = 34989

MGL_TEXTURE5 = 33989

MGL_CON_26_ATI = 35163

MGL_CONSTANT = 34166

MGL_TEXTURE_BINDING_CUBE_MAP_ARB = 34068

MGL_MAX_PROGRAM_TEX_INSTRUCTIONS_ARB = 34828

MGL_NEGATIVE_W_EXT = 34780

MGL_COLOR_LOGIC_OP = 3058

MGL_RGBA2 = 32853

MGL_TEXTURE3 = 33987

MGL_OUTPUT_TEXTURE_COORD23_EXT = 34740

MGL_INTERPOLATE = 34165

MGL_INDEX_LOGIC_OP = 3057

MGL_PROGRAM_NATIVE_ATTRIBS = 34990

MGL_TEXTURE_CUBE_MAP_NEGATIVE_Y = 34072

MGL_TEXTURE2 = 33986

MGL_ACCUM_GREEN_BITS = 3417

MGL_ADD_SIGNED = 34164

MGL_FRAGMENT_SHADER_ARB = 35632

MGL_LOGIC_OP_MODE = 3056

MUniformParameter_kSemanticHWSInstancedDraw = 58

MViewportRenderer_kExcludeDimensions = 4096

MGL_POLYGON_STIPPLE_BIT = 16

MGL_SRC_ALPHA = 770

MGL_TEXTURE_FREE_MEMORY_ATI = 34812

MGL_RGB_SCALE = 34163

MGL_BLEND = 3042

MGL_NICEST = 4354

MGL_FLOAT_VEC2_ARB = 35664

MGL_TEXTURE0 = 33984

MGL_MAX_TEXTURE_MAX_ANISOTROPY_EXT = 34047

MGL_BLEND_SRC = 3041

MGL_ABGR_EXT = 32768

MGL_LOGIC_OP = 3057

MGL_CLIENT_ATTRIB_STACK_DEPTH = 2993

MGL_MAP1_VERTEX_ATTRIB3_4_NV = 34403

MGL_DITHER = 3024

MGL_GENERATE_MIPMAP_SGIS = 33169

MGL_OP_INDEX_EXT = 34690

MGL_OPERAND2_RGB = 34194

MGL_POINT = 6912

MGL_VERTEX_ARRAY_STRIDE = 32892

MGL_OCCLUSION_TEST_RESULT_HP = 33126

MGL_TEXTURE15 = 33999

MGL_VERTEX_ATTRIB_ARRAY_STRIDE = 34340

MGL_UNSIGNED_BYTE_3_3_2_EXT = 32818

MGL_INDEX_MODE = 3120

MGL_PROXY_TEXTURE_3D = 32880

MGL_MAX_MODELVIEW_STACK_DEPTH = 3382

MGL_OCCLUSION_TEST_HP = 33125

MGL_LUMINANCE12_ALPHA4 = 32838

MGL_OPERAND0_RGB = 34192

MGL_TRANSFORM_FEEDBACK_BUFFER_EXT = 35982

MGL_COLOR_WRITEMASK = 3107

MGL_CURRENT_FOG_COORDINATE_EXT = 33875

MGL_FOG_SPECULAR_TEXTURE_WIN = 33004

MGL_FRONT_RIGHT = 1025

MGL_COLOR_CLEAR_VALUE = 3106

MGL_MODELVIEW0_MATRIX_EXT = 2982

MUniformParameter_kSemanticWorldViewTransposeMatrix = 38

MGL_FRONT_LEFT = 1024

MGL_INDEX_WRITEMASK = 3105

MGL_MULTISAMPLE_BIT = 536870912

MGL_MODELVIEW_STACK_DEPTH = 2979

MGL_MAGNITUDE_SCALE_NV = 34578

MGL_PHONG_WIN = 33002

MGL_HALF_FLOAT = 5131

MGL_MATRIX7 = 35015

MGL_NEGATIVE_Y_EXT = 34778

MGL_OP_EXP_BASE_2_EXT = 34705

MGL_PROGRAM_BINDING = 34423

MGL_COLOR_INDEX16_EXT = 32999

MGL_MAP1_VERTEX_ATTRIB9_4_NV = 34409

MGL_PROGRAM_UNDER_NATIVE_LIMITS = 34998

MGL_DOUBLE = 5130

kMGLext_NV_register_combiners = 69

MGL_MAX_PROGRAM_ADDRESS_REGISTERS = 34993

MGL_COLOR_INDEX12_EXT = 32998

MViewportRenderer_kExcludeHairSystems = 8388608

MGL_POINT_SMOOTH_HINT = 3153

MGL_4_BYTES = 5129

MGL_OBJECT_ACTIVE_ATTRIBUTES_ARB = 35721

MGL_PROGRAM_LENGTH = 34343

MGL_PROGRAM_FORMAT = 34934

MGL_COLOR_INDEX8_EXT = 32997

MGL_DST_ALPHA = 772

MGL_3_BYTES = 5128

MGL_OUTPUT_TEXTURE_COORD25_EXT = 34742

MGL_COLOR_INDEX4_EXT = 32996

MGL_AUTO_NORMAL = 3456

MGeometryData_kColorMask = 11

MGL_INDEX_BITS = 3409

MGL_CURRENT_VERTEX_ATTRIB = 34342

MGL_UNPACK_ROW_LENGTH = 3314

MGL_COLOR_INDEX2_EXT = 32995

MGL_TEXTURE10_ARB = 33994

MUniformParameter_kSemanticWorldInverseTransposeMatrix = 15

MGL_FLOAT = 5126

MGL_TRANSFORM_FEEDBACK_RECORD_NV = 35974

MGL_STENCIL_FUNC = 2962

MGL_PROJECTION_STACK_DEPTH = 2980

MGL_COMBINE = 34160

MGL_PRIMARY_COLOR_EXT = 34167

MGL_COPY_PIXEL_TOKEN = 1798

MGL_TEXTURE_COMPRESSED_ARB = 34465

MGL_STENCIL_CLEAR_VALUE = 2961

kMGLext_MGLX_create_pbuffer_sgix = 95

MGL_MAP1_VERTEX_ATTRIB8_4_NV = 34408

MGL_SCISSOR_TEST = 3089

MGL_CLAMP_TO_BORDER_SGIS = 33069

MGL_STENCIL_TEST = 2960

MGL_INDEX_ARRAY_EXT = 32887

MGL_INTENSITY = 32841

MGL_SOURCE3_RGB_NV = 34179

MGL_PN_TRIANGLES_POINT_MODE_ATI = 34802

MGL_CLAMP_TO_BORDER = 33069

MGL_MAX_COMBINED_TEXTURE_IMAGE_UNITS_ARB = 35661

MGL_NUM_INSTRUCTIONS_TOTAL_ATI = 35186

MGL_COMPRESSED_TEXTURE_FORMATS = 34467

MUniformParameter_kSemanticBackgroundColor = 46

MGL_PN_TRIANGLES_ATI = 34800

MGL_NUM_COMPRESSED_TEXTURE_FORMATS = 34466

MGL_SUBPIXEL_BITS = 3408

MGL_DOUBLEBUFFER = 3122

MGL_PROXY_TEXTURE_CUBE_MAP = 34075

MGL_VERTEX_ID_NV = 35963

MGL_QUERY_RESULT_AVAILABLE_ARB = 34919

MGL_CON_8_ATI = 35145

MGL_4D_COLOR_TEXTURE = 1540

MGL_COLOR_SUM = 33880

MGL_TEXTURE_STACK_DEPTH = 2981

MGL_QUERY_RESULT_ARB = 34918

MGL_FLOAT_RGBA32_NV = 34955

MGL_SAMPLE_ALPHA_TO_ONE_ARB = 32927

MGL_ZOOM_Y = 3351

MGL_W_EXT = 34776

MGL_PIXEL_MAP_A_TO_A = 3193

MUniformParameter_kSemanticBumpTexture = 30

MGL_CURRENT_QUERY_ARB = 34917

MGL_LIGHTING_BIT = 64

MViewportRenderer_kExcludePluginShapes = -2147483648

MGL_3D_COLOR = 1538

MGL_PIXEL_MAP_B_TO_B = 3192

MGL_STACK_UNDERFLOW = 1284

MGL_PIXEL_MAP_G_TO_G = 3191

MGL_MAX_TEXTURE_UNITS_ARB = 34018

MGL_DST_COLOR = 774

MGL_MULTISAMPLE = 32925

MGL_2D = 1536

MGL_PIXEL_MAP_R_TO_R = 3190

MGL_UNSIGNED_INT_10_10_10_2_EXT = 32822

MGL_PIXEL_MAP_S_TO_S_SIZE = 3249

MGL_PIXEL_COUNT_AVAILABLE_NV = 34919

MGL_VERTEX_ARRAY_TYPE = 32891

MUniformParameter_kSemanticWorldViewProjectionInverseMatrix = 26

MGL_NOTEQUAL = 517

MGL_MAP2_NORMAL = 3506

MGL_SOURCE2_RGB_EXT = 34178

MGL_TRANSFORM_FEEDBACK_BUFFER_MODE_EXT = 35967

MGL_PIXEL_MAP_I_TO_A = 3189

MGL_PIXEL_COUNT_NV = 34918

MGL_GREATER = 516

MGL_TEXTURE_CUBE_MAP_ARB = 34067

MGL_TRANSFORM_FEEDBACK_BUFFER_SIZE_NV = 35973

MGL_MATRIX10 = 35018

MGL_CURRENT_OCCLUSION_QUERY_ID_NV = 34917

MGL_LEQUAL = 515

kMGLext_MGLX_create_context_with_config_sgix = 97

MGL_Z_EXT = 34775

MGL_PIXEL_MAP_I_TO_G = 3187

MGL_TRANSPOSE_MODELVIEW_MATRIX = 34019

MGL_PIXEL_COUNTER_BITS_NV = 34916

MGL_MAP1_VERTEX_ATTRIB6_4_NV = 34406

MGL_BYTE = 5120

MGL_FLOAT_RGBA_MODE_NV = 34958

MGL_MAX_VARYING_FLOATS_ARB = 35659

MGL_SCALAR_EXT = 34750

MGL_CLIP_PLANE5 = 12293

MGL_FLOAT_CLEAR_COLOR_VALUE_NV = 34957

MGL_ONE_MINUS_DST_COLOR = 775

MGL_LINE_TOKEN = 1794

MGL_INDEX_ARRAY = 32887

MGL_SHADER_OBJECT_ARB = 35656

MGL_TEXTURE_ALPHA_TYPE = 35859

MGL_INVARIANT_DATATYPE_EXT = 34795

MGL_MAX_VIEWPORT_DIMS = 3386

MGL_REG_6_ATI = 35111

MGL_TEXTURE_LO_SIZE_NV = 34588

MGL_CLIP_PLANE3 = 12291

MGL_OUTPUT_TEXTURE_COORD13_EXT = 34730

MGL_CLIP_PLANE2 = 12290

MGL_TEXTURE_INTENSITY_TYPE = 35861

MGL_DS_SCALE_NV = 34576

MGL_COMPRESSED_ALPHA_ARB = 34025

MGL_MAP2_VERTEX_ATTRIB11_4_NV = 34427

MGL_CLIP_PLANE1 = 12289

MGL_RGBA32F = 34836

MGL_CON_3_ATI = 35140

MGL_ONE_MINUS_CONSTANT_COLOR = 32770

kMGLext_WMGL_NV_allocate_memory = 89

MGL_MAX_OPTIMIZED_VERTEX_SHADER_INVARIANTS_EXT = 34764

MGL_REFLECTION_MAP = 34066

kMGLext_WMGL_ARB_extensions_string = 83

MGL_FLOAT_RGB16_NV = 34952

MGL_VARIANT_ARRAY_TYPE_EXT = 34791

MGL_MAX_VERTEX_UNIFORM_COMPONENTS_ARB = 35658

MGL_SRC_ALPHA_SATURATE = 776

MGL_TEXTURE_3D_EXT = 32879

MGL_FLOAT_RG32_NV = 34951

MGL_ONE_MINUS_DST_ALPHA = 773

MGL_LUMINANCE12 = 32833

MGL_STENCIL_BUFFER_BIT = 1024

MGL_SEPARATE_ATTRIBS_EXT = 35981

MGL_FOG_INDEX = 2913

MGL_TEXTURE18_ARB = 34002

MGL_FLOAT_RG16_NV = 34950

MGL_MAX_TEXTURE_STACK_DEPTH = 3385

MGL_TEXTURE_PRIORITY = 32870

MGL_FLOAT_R32_NV = 34949

MGL_MATRIX2_NV = 34354

MGL_TEXTURE_INTENSITY_SIZE = 32865

MGL_SAMPLE_COVERAGE_INVERT = 32939

MGL_CURRENT_VERTEX_WEIGHT_EXT = 34059

MGL_GEQUAL = 518

MGL_RENDER = 7168

MGL_ONE_EXT = 34782

MGL_TEXTURE_1D_BINDING = 32872

MGL_FLOAT_RGBA_NV = 34947

MGL_MAP1_VERTEX_ATTRIB4_4_NV = 34404

MGL_RENDERER = 7937

MGL_FOG_COLOR = 2918

MGL_PROXY_TEXTURE_2D = 32868

kMGLext_NV_fence = 68

MGL_ALPHA_TEST = 3008

MGL_FLOAT_RGB_NV = 34946

MGL_PROGRAM_OBJECT_ARB = 35648

MGL_AUX_BUFFERS = 3072

MGL_POINT_SIZE_MAX_ARB = 33063

MGL_VERTEX_SHADER_ARB = 35633

MGL_PROXY_TEXTURE_1D = 32867

MGL_OP_LOG_BASE_2_EXT = 34706

MGL_FLOAT_RG_NV = 34945

MGL_PN_TRIANGLES_NORMAL_MODE_ATI = 34803

MGL_DRAW_BUFFER = 3073

MGL_OUTPUT_TEXTURE_COORD17_EXT = 34734

MGL_FLOAT_R_NV = 34944

MGL_SECONDARY_COLOR_ARRAY_BUFFER_BINDING_ARB = 34972

MGL_MAX_PROJECTION_STACK_DEPTH = 3384

MGL_COLOR_CLEAR_UNCLAMPED_VALUE_ATI = 34869

MGL_DECR_WRAP_EXT = 34056

MGL_TEXTURE_ALPHA_SIZE = 32863

MGL_NUM_INSTRUCTIONS_PER_PASS_ATI = 35185

MGL_ALPHA_BITS = 3413

MGL_SPOT_EXPONENT = 4613

MGL_VERTEX_SHADER_OPTIMIZED_EXT = 34772

MGL_TEXTURE_IMAGE_SIZE_ARB = 34464

MGL_TEXTURE_BLUE_SIZE = 32862

kMGLext_MGLX_destroy_pbuffer = 94

MGL_BLUE_BITS = 3412

MGL_TEXTURE25 = 34009

MGL_EQUIV = 5385

MGL_INDEX_CLEAR_VALUE = 3104

MGL_TEXTURE_GREEN_SIZE = 32861

MGL_MAX_PROGRAM_NATIVE_PARAMETERS = 34987

MGL_GREEN_BITS = 3411

MGL_MAX_EXT = 32776

MGL_TEXTURE_RED_SIZE = 32860

MGL_TEXTURE_ENV_MODE = 8704

MGL_RGBA16 = 32859

MUniformParameter_kSemanticViewportPixelSize = 45

MGL_STENCIL_INDEX16 = 36169

MGL_ALPHA_TEST_FUNC = 3009

MViewportRenderer_kExcludeImagePlane = 16777216

MGL_MAGNITUDE_BIAS_NV = 34584

MGL_RGBA12 = 32858

MGL_TEXTURE_CUBE_MAP_NEGATIVE_Z = 34074

MGL_MAX_TEXTURE_COORDS_ARB = 34929

kMGLext_ATI_fragment_shader = 65

MGL_TEXTURE2_ARB = 33986

MGL_LINE_RESET_TOKEN = 1799

MGL_MATRIX17 = 35025

MGL_STENCIL_PASS_DEPTH_FAIL = 2965

MGL_TEXTURE_BLUE_TYPE = 35858

MGL_TEXTURE_MAG_FILTER = 10240

MGL_EIGHTH_BIT_ATI = 32

MGL_EXP = 2048

MGL_VERTEX_SHADER_LOCALS_EXT = 34771

MGL_RGBA8 = 32856

MGL_MAX_PROGRAM_NATIVE_TEX_INSTRUCTIONS_ARB = 34831

MGL_LINE_STIPPLE_REPEAT = 2854

MGL_EXP2 = 2049

MGL_RGB5_A1 = 32855

MGL_VERTEX_ATTRIB_ARRAY6_NV = 34390

MGL_PROGRAM_NATIVE_PARAMETERS = 34986

MGL_MAX_PROGRAM_NATIVE_ALU_INSTRUCTIONS_ARB = 34830

MGL_MAX = 32776

MGL_RGBA4 = 32854

MGL_MAX_PROGRAM_TEX_INDIRECTIONS_ARB = 34829

MGL_CCW = 2305

MGL_MIRRORED_REPEAT_IBM = 33648

MGL_TEXTURE20_ARB = 34004

MUniformParameter_kSemanticWorldViewProjectionMatrix = 25

MGL_COEFF = 2560

MGL_RGB16 = 32852

MGL_VERTEX_ARRAY_RANGE_VALID_NV = 34079

MGL_VARIANT_ARRAY_POINTER_EXT = 34793

MGL_COLOR_TABLE_BLUE_SIZE_EXT = 32988

MGL_ORDER = 2561

MGL_OPERAND2_RGB_EXT = 34194

MGL_REFLECTION_MAP_ARB = 34066

MGL_SOURCE1_ALPHA = 34185

MGL_RGB12 = 32851

MGL_MATRIX5 = 35013

MGL_MAX_ATTRIB_STACK_DEPTH = 3381

MGL_TEXTURE_GEN_MODE = 9472

MGL_PROGRAM_NATIVE_TEX_INDIRECTIONS_ARB = 34826

MGL_DOMAIN = 2562

MGL_ISOTROPIC_BRDF_NV = 34539

MGL_VERTEX_SHADER_LOCAL_CONSTANTS_EXT = 34770

MGL_RGB10 = 32850

MGL_MAX_TEXTURE_UNITS = 34018

MGL_PIXEL_MAP_I_TO_A_SIZE = 3253

MGL_MAX_PIXEL_MAP_TABLE = 3380

MGL_MAP1_VERTEX_ATTRIB1_4_NV = 34401

MGL_CURRENT_COLOR = 2816

MGL_TRANSPOSE_CURRENT_MATRIX = 34999

MGL_CLIP_PLANE0 = 12288

MGL_MAX_PROGRAM_PARAMETERS = 34985

MGL_MAX_TEXTURE_SIZE = 3379

MGL_DT_BIAS_NV = 34583

MGL_CURRENT_INDEX = 2817

MGL_MIN_EXT = 32775

MUniformParameter_kSemanticHWSOccluder = 56

MViewportRenderer_kExcludeParticleInstancers = 1024

MGL_CURRENT_NORMAL = 2818

MGL_RGB4 = 32847

MGL_VERTEX_PROGRAM_POINT_SIZE = 34370

MGL_MAX_LIGHTS = 3377

MGL_EDGE_FLAG_ARRAY_BUFFER_BINDING_ARB = 34971

MGL_R3_G3_B2 = 10768

MGL_OUTPUT_TEXTURE_COORD12_EXT = 34729

MGL_MAX_EVAL_ORDER = 3376

MGL_POINT_SIZE_MIN_ARB = 33062

MGL_CURRENT_RASTER_COLOR = 2820

MGL_INTENSITY16 = 32845

MGL_TEXTURE_BORDER_COLOR = 4100

MGL_FRAGMENT_PROGRAM_ARB = 34820

MUniformParameter_kSemanticFarClipPlane = 49

MGL_CURRENT_RASTER_INDEX = 2821

MCommonRenderSettingsData_kFullPathTmp = 2

MGL_MAP2_VERTEX_ATTRIB6_4_NV = 34422

MGL_INTENSITY12 = 32844

MGL_FRAMEBUFFER_INCOMPLETE_ATTACHMENT = 36054

MGL_MAX_LIST_NESTING = 2865

MGL_CURRENT_RASTER_TEXTURE_COORDS = 2822

MGL_PROGRAM_PARAMETERS = 34984

kMGLext_texture_array = 82

MGL_ALPHA_BIAS = 3357

MGL_TEXTURE13 = 33997

MGL_CURRENT_RASTER_POSITION = 2823

MGL_SAMPLES = 32937

MGL_MIN = 32775

MGL_INTENSITY4 = 32842

MGL_ALPHA_SCALE = 3356

MGL_CURRENT_RASTER_POSITION_VALID = 2824

MGL_BLUE_BIAS = 3355

MGL_SUB_ATI = 35173

MGL_CURRENT_RASTER_DISTANCE = 2825

MGL_PROGRAM_NATIVE_TEX_INSTRUCTIONS_ARB = 34825

MGL_MAX_TEXTURE_COORDS_NV = 34929

MGL_INVERSE_TRANSPOSE_NV = 34349

MGL_SEPARATE_SPECULAR_COLOR = 33274

MGL_POINT_SMOOTH = 2832

MGL_RENDERBUFFER_STENCIL_SIZE = 36181

MGL_MAX_CUBE_MAP_TEXTURE_SIZE_ARB = 34076

MGL_SAMPLE_COVERAGE_VALUE = 32938

MGL_FRAGMENT_PROGRAM_NV = 34928

MGL_NEGATIVE_X_EXT = 34777

MGL_VERTEX_SHADER_VARIANTS_EXT = 34768

MGL_ZERO_EXT = 34781

MGL_RENDERBUFFER_DEPTH_SIZE = 36180

MGL_REG_3_ATI = 35108

MGL_FENCE_CONDITION_NV = 34036

MGL_OUTPUT_TEXTURE_COORD11_EXT = 34728

MGL_RGBA_FLOAT_MODE_ATI = 34848

MGL_UNSIGNED_INT_S8_S8_8_8_REV_NV = 34523

kMGLext_ATI_texture_mirror_once = 67

MGL_MAX_PROGRAM_NATIVE_TEMPORARIES = 34983

MGL_FENCE_STATUS_NV = 34035

MGL_RENDER_MODE = 3136

MGL_GPU_MEMORY_INFO_EVICTED_MEMORY_NVX = 36939

MGL_RENDERBUFFER_BLUE_SIZE = 36178

MGL_GPU_MEMORY_INFO_EVICTION_COUNT_NVX = 36938

MGL_REG_11_ATI = 35116

MGL_DONT_CARE = 4352

MGL_RENDERBUFFER_GREEN_SIZE = 36177

MGL_TEXTURE_COMPONENTS = 4099

MGL_CND0_ATI = 35179

MGL_ACCUM_ALPHA_BITS = 3419

MGL_GPU_MEMORY_INFO_CURRENT_AVAILABLE_VIDMEM_NVX = 36937

MGL_PROGRAM_NATIVE_ALU_INSTRUCTIONS_ARB = 34824

MGL_RENDERBUFFER_RED_SIZE = 36176

MGL_CND_ATI = 35178

MGL_UNPACK_SKIP_PIXELS = 3316

MGL_REG_31_ATI = 35136

MGL_OPERAND1_ALPHA = 34201

MGL_BIAS_BIT_ATI = 8

MGL_BOOL_VEC3_ARB = 35672

MGL_GPU_MEMORY_INFO_DEDICATED_VIDMEM_NVX = 36935

MGL_VERTEX_SHADER_INSTRUCTIONS_EXT = 34767

MGL_TEXTURE_COMPRESSION_HINT_ARB = 34031

MGL_OUTPUT_TEXTURE_COORD10_EXT = 34727

MGL_TEXTURE_INTERNAL_FORMAT = 4099

MGL_STENCIL_INDEX4 = 36167

MGL_COMBINER7_NV = 34135

MGL_DOT4_ATI = 35175

MGL_RGB5 = 32848

MGL_RENDERBUFFER_FREE_MEMORY_ATI = 34813

MGL_STENCIL_INDEX1 = 36166

MGL_COLOR_ATTACHMENT10 = 36074

MGLFunctionTable_kMGL_Version15 = 5

MGL_INVALID_ENUM = 1280

MGL_RENDERBUFFER_INTERNAL_FORMAT = 36164

MUniformParameter_kSemanticLocalViewer = 44

MGLFunctionTable_kMGL_Version14 = 4

MGL_2_BYTES = 5127

MGL_AUX3 = 1036

MGL_MAX_CLIP_PLANES = 3378

MGL_RENDERBUFFER_HEIGHT = 36163

MGL_TEXTURE_CUBE_MAP_POSITIVE_Z = 34073

MGL_REG_30_ATI = 35135

MGL_AUX2 = 1035

MGL_STENCIL_FAIL = 2964

MGL_VARIANT_ARRAY_EXT = 34792

MGL_VERTEX_ATTRIB_ARRAY15_NV = 34399

MGL_ONE_MINUS_SRC_ALPHA = 771

MGL_OPERAND0_ALPHA = 34200

MGL_AUX1 = 1034

MGL_MAX_OPTIMIZED_VERTEX_SHADER_LOCALS_EXT = 34766

MGL_RENDERBUFFER = 36161

MCommonRenderSettingsData_kFullPathImage = 1

MGL_MODELVIEW_MATRIX = 2982

MGL_AUX0 = 1033

MGL_VERTEX_ATTRIB_ARRAY5_NV = 34389

MGL_MAX_PROGRAM_TEMPORARIES = 34981

MCommonRenderSettingsData_kRelativePath = 0

MGL_FRONT_AND_BACK = 1032

MGL_REG_22_ATI = 35127

MGL_BOOL_ARB = 35670

MGL_UNSIGNED_INT_S8_S8_8_8_NV = 34522

MGL_STENCIL_ATTACHMENT = 36128

MGL_VECTOR_EXT = 34751

MGL_MAP2_VERTEX_ATTRIB2_4_NV = 34418

MGL_CON_30_ATI = 35167

MGL_PERSPECTIVE_CORRECTION_HINT = 3152

MGL_MATRIX_MODE = 2976

MGL_TEXTURE1 = 33985

MGL_MAX_VERTEX_SHADER_INVARIANTS_EXT = 34759

MGL_DEPTH_ATTACHMENT = 36096

MGL_CON_29_ATI = 35166

MGL_PROGRAM_TEX_INSTRUCTIONS_ARB = 34822

MGL_COLOR_ATTACHMENT15 = 36079

MGL_CON_28_ATI = 35165

MGL_R = 8194

MGL_BACK = 1029

MGL_COLOR_ATTACHMENT14 = 36078

MGL_MATRIX0 = 35008

MGL_CON_27_ATI = 35164

MGL_FRONT = 1028

MGL_COLOR_ATTACHMENT13 = 36077

MGL_POLYGON_SMOOTH = 2881

MGL_BACK_RIGHT = 1027

MGL_VERTEX_SHADER_INVARIANTS_EXT = 34769

MGL_COLOR_ATTACHMENT12 = 36076

MGL_PROGRAM_TEMPORARIES = 34980

MGL_CON_25_ATI = 35162

MGL_BACK_LEFT = 1026

MGL_INT_VEC4_ARB = 35669

MGL_STENCIL = 6146

MGL_INVARIANT_VALUE_EXT = 34794

MGL_COLOR_ATTACHMENT11 = 36075

MGL_CON_24_ATI = 35161

MGL_REG_0_ATI = 35105

MGL_TRANSFORM_FEEDBACK_VARYING_MAX_LENGTH_EXT = 35958

MGL_VERTEX_PROGRAM = 34336

MGL_CON_23_ATI = 35160

MGL_MATRIX_EXT = 34752

MGL_PROGRAM_ALU_INSTRUCTIONS_ARB = 34821

MGL_REG_4_ATI = 35109

MGL_COLOR_ATTACHMENT9 = 36073

MGL_CON_22_ATI = 35159

MGL_MODELVIEW_PROJECTION_NV = 34345

MGL_PACK_SKIP_ROWS = 3331

MGL_PACK_SKIP_PIXELS = 3332

MGL_COLOR_ATTACHMENT8 = 36072

MGL_CON_21_ATI = 35158

MGL_MAP2_VERTEX_ATTRIB1_4_NV = 34417

MGL_COLOR_ATTACHMENT7 = 36071

MGL_CON_20_ATI = 35157

MGL_POLYGON_STIPPLE = 2882

MGL_INTERLEAVED_ATTRIBS_NV = 35980

MGL_CONSTANT_COLOR = 32769

MGL_COLOR_ATTACHMENT6 = 36070

MGL_MAX_PROGRAM_NATIVE_INSTRUCTIONS = 34979

kMGLext_framebuffer_multisample = 81

MGL_CON_19_ATI = 35156

MGL_TEXTURE12 = 33996

MGL_MAP1_GRID_SEGMENTS = 3537

MGL_MAP_COLOR = 3344

MGL_INT_VEC3_ARB = 35668

MGL_COLOR_ATTACHMENT5 = 36069

MGL_TEXTURE_BORDER = 4101

MGL_UNPACK_IMAGE_HEIGHT_EXT = 32878

MGL_TRANSPOSE_TEXTURE_MATRIX_ARB = 34021

MGL_MAP_STENCIL = 3345

MGL_FOG = 2912

MGL_OUTPUT_TEXTURE_COORD0_EXT = 34717

MGL_CON_17_ATI = 35154

MGL_INDEX_SHIFT = 3346

MGL_VERTEX_STATE_PROGRAM_NV = 34337

MGL_COLOR_ALPHA_PAIRING_ATI = 35189

MGL_COLOR_ATTACHMENT3 = 36067

MGL_CON_16_ATI = 35153

MGL_TEXTURE_MIN_FILTER = 10241

MGL_INDEX_OFFSET = 3347

MGL_VERTEX_ATTRIB_ARRAY2_NV = 34386

MGL_MAX_PROGRAM_MATRIX_STACK_DEPTH = 34350

MGL_PIXEL_MAP_I_TO_G_SIZE = 3251

MGL_OUTPUT_TEXTURE_COORD27_EXT = 34744

MGL_OBJECT_COMPILE_STATUS_ARB = 35713

MGL_ACCUM_CLEAR_VALUE = 2944

MGL_CON_15_ATI = 35152

MGL_SPARE0_NV = 34094

MGL_OUTPUT_TEXTURE_COORD26_EXT = 34743

MGL_DEPTH_FUNC = 2932

MGL_PROGRAM_NATIVE_INSTRUCTIONS = 34978

MGL_CON_14_ATI = 35151

MViewportRenderer_kExcludeSubdivSurfaces = 1048576

MGL_STREAM_DRAW_ARB = 35040

MGL_VIBRANCE_SCALE_NV = 34579

MGL_DEPTH_CLEAR_VALUE = 2931

MGL_PROGRAM_NATIVE_TEMPORARIES = 34982

MGL_VERTEX_ATTRIB_ARRAY_POINTER = 34373

MGL_CON_13_ATI = 35150

MGL_POLYGON_OFFSET_FACTOR = 32824

MGL_OUTPUT_TEXTURE_COORD24_EXT = 34741

MGL_REG_10_ATI = 35115

MGL_VERTEX_ATTRIB_ARRAY4_NV = 34388

MGL_SOURCE0_RGB = 34176

MGL_DEPTH_WRITEMASK = 2930

MGL_OUTPUT_TEXTURE_COORD22_EXT = 34739

MGL_TEXTURE_MAX_ANISOTROPY_EXT = 34046

MGL_CON_12_ATI = 35149

MGL_GREEN_SCALE = 3352

MGL_FRAMEBUFFER_INCOMPLETE_READ_BUFFER = 36060

MGL_UNPACK_ALIGNMENT = 3317

MGL_REG_26_ATI = 35131

MGL_TEXTURE7_ARB = 33991

MGL_GREEN_BIAS = 3353

MGeometryData_kUserData = 12

MGL_FRAMEBUFFER_INCOMPLETE_DRAW_BUFFER = 36059

MGL_TRANSFORM_FEEDBACK_VARYINGS_NV = 35971

MGL_MAX_PROGRAM_MATRICES = 34351

MGL_LUMINANCE16F = 34846

MGL_CON_10_ATI = 35147

MGL_BLUE_SCALE = 3354

MGL_OBJECT_DELETE_STATUS_ARB = 35712

MGL_TEXTURE_WRAP_R_EXT = 32882

MGL_FRAMEBUFFER_INCOMPLETE_FORMATS = 36058

MGL_CON_9_ATI = 35146

MGL_CULL_FACE = 2884

MGL_ACTIVE_VARYING_MAX_LENGTH_NV = 35970

MGL_LINE_SMOOTH = 2848

MGL_MAX_PROGRAM_INSTRUCTIONS = 34977

MGL_INTENSITY8 = 32843

MGL_FRAMEBUFFER_INCOMPLETE_DUPLICATE_ATTACHMENT = 36056

MGL_UNSIGNED_IDENTITY_NV = 34102

MGL_VERTEX_ATTRIB_ARRAY8_NV = 34392

MGL_CON_7_ATI = 35144

MGL_TRANSPOSE_MODELVIEW_MATRIX_ARB = 34019

MGL_LINE_WIDTH_RANGE = 2850

MGL_FRAMEBUFFER_INCOMPLETE_MISSING_ATTACHMENT = 36055

MUniformParameter_kSemanticViewProjectionInverseTransposeMatrix = 43

MGL_CON_6_ATI = 35143

MGeometryData_kMaxDataTypeIndex = 13

MGL_NUM_INPUT_INTERPOLATOR_COMPONENTS_ATI = 35187

MGL_LIST_BIT = 131072

MGL_TEXTURE_BINDING_1D = 32872

MGL_CON_5_ATI = 35142

MGL_OP_SET_LT_EXT = 34701

MGL_LINE_STIPPLE = 2852

MGL_MATRIX15 = 35023

MGL_TEXTURE_BIT = 262144

MGL_MAX_VERTEX_ATTRIBS = 34921

MGL_CON_4_ATI = 35141

MGL_LINE_STIPPLE_PATTERN = 2853

MGL_OBJECT_SUBTYPE_ARB = 35663

MGL_POLYGON_SMOOTH_HINT = 3155

MGL_SCISSOR_BIT = 524288

MGL_CULL_FACE_MODE = 2885

MGL_PROJECTION_MATRIX = 2983

MGL_ALL_ATTRIB_BITS = 1048575

MGL_PROGRAM_INSTRUCTIONS = 34976

MGL_CON_2_ATI = 35139

MGL_LIST_MODE = 2864

MGL_DT_SCALE_NV = 34577

MGL_OPERAND2_ALPHA = 34202

MGL_SRC_COLOR = 768

MGL_CON_1_ATI = 35138

MGL_CLAMP = 10496

MGL_STATIC_COPY_ARB = 35046

MGL_MAP1_VERTEX_ATTRIB0_4_NV = 34400

MGL_ONE_MINUS_SRC_COLOR = 769

MGL_UNSIGNED_SHORT_4_4_4_4_EXT = 32819

MGL_CON_0_ATI = 35137

MGL_LIST_BASE = 2866

MUniformParameter_kSemanticWorldViewInverseMatrix = 23

MGL_FRAGMENT_PROGRAM_BINDING_NV = 34931

MGL_VIEWPORT = 2978

MGL_MODULATE = 8448

MGL_REG_24_ATI = 35129

MGL_LIST_INDEX = 2867

kMGLext_MGLX_destroy_window = 93

MGL_NORMALIZE = 2977

MGL_SOURCE0_ALPHA = 34184

MGL_Q = 8195

MViewportRenderer_kExcludeStrokes = 524288

MGL_OBJECT_TYPE_ARB = 35662

MGL_STENCIL_PASS_DEPTH_PASS = 2966

MGL_COLOR_TABLE_LUMINANCE_SIZE_EXT = 32990

MGL_OUTPUT_TEXTURE_COORD8_EXT = 34725

MGL_STENCIL_WRITEMASK = 2968

MGL_STENCIL_REF = 2967

MGL_REG_28_ATI = 35133

MGL_SWIZZLE_STRQ_ATI = 35194

MGL_OUTPUT_TEXTURE_COORD7_EXT = 34724

MGL_VERTEX_ARRAY_STRIDE_EXT = 32892

MUniformParameter_kSemanticHWSEdgeLevel = 54

MGL_TEXTURE_WRAP_T = 10243

MGL_EDGE_FLAG = 2883

MGL_TEXTURE_GEQUAL_R_SGIX = 33181

MGL_TEXTURE_COMPRESSION_HINT = 34031

MGL_SWIZZLE_STRQ_DQ_ATI = 35195

MGL_EXTENSIONS = 7939

MGL_VERTEX_WEIGHT_ARRAY_POINTER_EXT = 34064

MGL_COLOR_INDEX1_EXT = 32994

MGL_MAX_TEXTURE_IMAGE_UNITS_NV = 34930

MGL_BLEND_DST = 3040

MGL_ALPHA_TEST_REF = 3010

MGL_REG_25_ATI = 35130

MGL_VENDOR = 7936

MGL_PIXEL_COUNTER_BITS_ARB = 34916

MGL_COLOR_TABLE_INTENSITY_SIZE_EXT = 32991

MGL_INVALID_VALUE = 1281

MGL_PACK_ALIGNMENT = 3333

MGL_SOURCE2_RGB = 34178

MUniformParameter_kSemanticWorldViewMatrix = 22

MGL_FRONT_FACE = 2886

MGL_MAP1_VERTEX_ATTRIB12_4_NV = 34412

MGL_EMISSION = 5632

MGL_REG_23_ATI = 35128

MGL_LIGHTING = 2896

MGL_COLOR_TABLE_ALPHA_SIZE_EXT = 32989

MGL_SET = 5391

MGL_OUTPUT_TEXTURE_COORD21_EXT = 34738

kMGLext_packed_depth_stencil = 80

MGL_DECR = 7683

MGL_MAP1_GRID_DOMAIN = 3536

MGL_TEXTURE_GEN_Q = 3171

MGL_LO_SCALE_NV = 34575

MGL_LESS = 513

MGL_UNPACK_IMAGE_HEIGHT = 32878

MGL_INCR = 7682

MGL_UNPACK_SWAP_BYTES = 3312

MGL_TEXTURE_WRAP_S = 10242

MGL_TEXTURE29_ARB = 34013

MGL_COLOR_TABLE_GREEN_SIZE_EXT = 32987

MUniformParameter_kSemanticTime = 34

MGL_EQUAL = 514

MGL_MAX_TRANSFORM_FEEDBACK_INTERLEAVED_COMPONENTS_EXT = 35978

MGL_TEXTURE_LEQUAL_R_SGIX = 33180

MGL_REG_20_ATI = 35125

MGL_COLOR_TABLE_RED_SIZE_EXT = 32986

MUniformParameter_kSemanticProjectionInverseMatrix = 20

MGL_NUM_PASSES_ATI = 35184

MGL_PROXY_TEXTURE_CUBE_MAP_ARB = 34075

MGL_COPY_INVERTED = 5388

MGL_ATTRIB_ARRAY_SIZE_NV = 34339

MGL_ADD = 260

MGL_MAP2_GRID_SEGMENTS = 3539

MGL_SAMPLE_BUFFERS = 32936

MGL_REG_18_ATI = 35123

MGL_COLOR_MATERIAL_FACE = 2901

MGL_MAP1_VERTEX_ATTRIB11_4_NV = 34411

MGL_NEGATIVE_Z_EXT = 34779

MGL_INVERT = 5386

MGL_MIRROR_CLAMP_ATI = 34626

MGL_BITMAP_TOKEN = 1796

MGL_SECONDARY_COLOR_ARRAY_SIZE_EXT = 33882

MGL_NUM_GENERAL_COMBINERS_NV = 34126

MGL_REG_16_ATI = 35121

MGL_PIXEL_MAP_I_TO_B = 3188

MGL_DRAW_PIXEL_TOKEN = 1797

MGL_OBJECT_SHADER_SOURCE_LENGTH_ARB = 35720

MGL_NOR = 5384

MGL_PROGRAM_PARAMETER_NV = 34372

MGL_FEEDBACK = 7169

MGL_NAND = 5390

MGL_T2F_N3F_V3F = 10795

MGL_COMBINE_ALPHA = 34162

MGL_OR = 5383

MGL_TRANSPOSE_PROJECTION_MATRIX = 34020

MGL_NUM_FRAGMENT_CONSTANTS_ATI = 35183

MGL_FILL = 6914

MGL_PACK_SWAP_BYTES = 3328

MGL_REG_21_ATI = 35126

MGL_TEXTURE6_ARB = 33990

MGL_T2F_C4UB_V3F = 10793

MGL_NOOP = 5381

MGL_NORMAL_MAP_ARB = 34065

MGL_SCALE_BY_ONE_HALF_NV = 34112

MGL_LINE = 6913

MGL_PROGRAM_RESIDENT_NV = 34375

MGL_CON_11_ATI = 35148

MGL_AND_INVERTED = 5380

kMGLext_MGLX_choose_fbconfig = 91

MGL_LIGHT_MODEL_TWO_SIDE = 2898

MGL_TEXTURE_WIDTH = 4096

MGL_RGB8 = 32849

MGL_PROGRAM_TARGET_NV = 34374

MGL_VARIABLE_G_NV = 34089

MGL_ATTRIB_STACK_DEPTH = 2992

MGL_MAX_GENERAL_COMBINERS_NV = 34125

MGL_READ_BUFFER = 3074

MGL_BITMAP = 6656

MGL_ATTRIB_ARRAY_POINTER_NV = 34373

MGL_SIGNED_RGB8_UNSIGNED_ALPHA8_NV = 34573

MGL_AND_REVERSE = 5378

MGL_VBO_FREE_MEMORY_ATI = 34811

MGL_SHORT = 5122

MGL_LUMINANCE_ALPHA = 6410

MGL_OR_INVERTED = 5389

MGL_RGB32F = 34837

MUniformParameter_kSemanticViewProjectionTransposeMatrix = 42

MGL_UNSIGNED_INT = 5125

MGL_C3F_V3F = 10788

MGL_NUM_FRAGMENT_REGISTERS_ATI = 35182

MGL_CLEAR = 5376

MGL_REG_7_ATI = 35112

MGL_REPLACE = 7681

MGL_C4UB_V3F = 10787

MGL_MATRIX14 = 35022

MGL_VARIANT_ARRAY_STRIDE_EXT = 34790

MGL_COMPILE_AND_EXECUTE = 4865

MGL_RGB = 6407

MGL_POINT_SIZE_RANGE = 2834

MGL_COMPILE = 4864

kMGLext_NV_transform_feedback = 76

MGL_ELEMENT_ARRAY_BUFFER_ARB = 34963

MGL_LIGHT_MODEL_AMBIENT = 2899

MViewportRenderer_kExcludeMotionTrails = 1073741824

MGL_CURRENT_MATRIX_STACK_DEPTH_NV = 34368

MGL_QUADRATIC_ATTENUATION = 4617

MGL_STENCIL_VALUE_MASK = 2963

MGL_ARRAY_BUFFER_ARB = 34962

MGL_MATRIX7_NV = 34359

MGL_TRACK_MATRIX_TRANSFORM_NV = 34377

MGL_RENDERBUFFER_ALPHA_SIZE = 36179

MGL_MODELVIEW0_STACK_DEPTH_EXT = 2979

MGL_MULT = 259

MGL_EDGE_FLAG_ARRAY_POINTER = 32915

MGL_CONSTANT_ATTENUATION = 4615

MGL_MATRIX30 = 35038

MGL_MATRIX5_NV = 34357

MGL_PIXEL_MAP_I_TO_B_SIZE = 3252

MGL_SPOT_CUTOFF = 4614

MGL_SEPARATE_ATTRIBS_NV = 35981

MGL_DEPTH_COMPONENT = 6402

MGL_INDEX_ARRAY_POINTER = 32913

MGL_COMBINE_RGB = 34161

MGL_MATRIX28 = 35036

MGL_EYE_LINEAR = 9216

MGL_COLOR_ARRAY_POINTER = 32912

MGL_PROGRAM_TEX_INDIRECTIONS_ARB = 34823

MGL_POINT_SIZE_GRANULARITY = 2835

MGL_SPOT_DIRECTION = 4612

MViewportRenderer_kExcludeLocators = 2048

MGL_COLOR_INDEX = 6400

MGL_COLOR_TABLE_WIDTH_EXT = 32985

MGL_NORMAL_ARRAY_POINTER = 32911

MGL_LINE_WIDTH_GRANULARITY = 2851

MGL_TEXTURE_COORD_ARRAY_STRIDE = 32906

MGL_RENDERBUFFER_BINDING = 36007

MGL_OBJECT_ATTACHED_OBJECTS_ARB = 35717

MGL_MAX_TRANSFORM_FEEDBACK_SEPARATE_ATTRIBS_NV = 35979

MGL_MAX_TRANSFORM_FEEDBACK_SEPARATE_COMPONENTS_EXT = 35968

MGL_DRAW_FRAMEBUFFER = 36009

MUniformParameter_kSemanticHWSFaceLevel = 53

MGL_DEPTH = 6145

MGL_OR_REVERSE = 5387

MGL_EDGE_FLAG_ARRAY_STRIDE = 32908

MGL_DIFFUSE = 4609

MGL_COLOR = 6144

MGL_TRANSFORM_BIT = 4096

MGL_COMPRESSED_RGB = 34029

MGL_REG_2_ATI = 35107

MGL_AMBIENT = 4608

MGL_OUTPUT_TEXTURE_COORD14_EXT = 34731

MGL_SMOOTH = 7425

MGL_COMPRESSED_INTENSITY = 34028

MGL_TEXTURE_GEN_S = 3168

MGL_LIGHT7 = 16391

MGL_MAP2_VERTEX_4 = 3512

MGL_MATRIX22 = 35030

MGL_SIGNED_RGB_UNSIGNED_ALPHA_NV = 34572

MGL_COMPRESSED_LUMINANCE_ALPHA = 34027

MGL_UNSIGNED_BYTE = 5121

MGL_LIGHT6 = 16390

MGL_VERTEX_ATTRIB_ARRAY14_NV = 34398

MGL_COLOR_TABLE_FORMAT_EXT = 32984

MGL_TEXTURE29 = 34013

MGL_COLOR_INDEXES = 5635

MGL_XOR = 5382

MGL_COMPRESSED_ALPHA = 34025

MGL_CURRENT_TEXTURE_COORDS = 2819

MGL_OBJECT_INFO_LOG_LENGTH_ARB = 35716

MGL_CURRENT_SECONDARY_COLOR_EXT = 33881

MGL_UNPACK_SKIP_IMAGES_EXT = 32877

MGL_AMBIENT_AND_DIFFUSE = 5634

MGL_FRAMEBUFFER = 36160

MGL_RETURN = 258

MGL_TEXTURE28_ARB = 34012

MGL_COLOR_ARRAY_STRIDE = 32899

MUniformParameter_kSemanticOpaqueDepthTexture = 33

MGL_COLOR_SUM_EXT = 33880

MGL_RASTERIZER_DISCARD_EXT = 35977

MGL_TEXTURE_COMPARE_MODE_ARB = 34892

MGL_MATRIX18 = 35026

kMGLext_NV_fragment_program = 73

MGL_COLOR_ARRAY_TYPE = 32898

MGL_PIXEL_MAP_R_TO_R_SIZE = 3254

MGL_OPERAND3_ALPHA_NV = 34203

MGL_FOG_COORDINATE_ARRAY_EXT = 33879

MGL_LUMINANCE_ALPHA32F = 34841

MGL_FLAT = 7424

MGL_COLOR_ARRAY_SIZE = 32897

MGL_DSDT_MAG_NV = 34550

MGL_FOG_COORDINATE_ARRAY_POINTER_EXT = 33878

MGL_INT = 5124

MGL_SAMPLE_COVERAGE = 32928

MGL_LUMINANCE32F = 34840

kMGLext_EXT_transform_feedback = 62

MGL_OUTPUT_TEXTURE_COORD4_EXT = 34721

MGL_FOG_COORDINATE_ARRAY_STRIDE_EXT = 33877

MGL_T4F_C4F_N3F_V4F = 10797

MGL_NORMAL_ARRAY_TYPE = 32894

MGL_FOG_COORDINATE_ARRAY_TYPE_EXT = 33876

MGL_TEXTURE28 = 34012

MGL_ALPHA32F = 34838

MViewportRenderer_kExcludeHulls = 262144

MGL_TEXTURE_CUBE_MAP_POSITIVE_Y = 34071

MGL_OBJECT_VALIDATE_STATUS_ARB = 35715

MGL_FASTEST = 4353

MGL_LIGHT_MODEL_LOCAL_VIEWER = 2897

MGL_MATRIX13 = 35021

MGL_TEXTURE_CUBE_MAP_NEGATIVE_X = 34070

MGL_OUTPUT_TEXTURE_COORD20_EXT = 34737

MGL_MATRIX12 = 35020

MGL_ADD_SIGNED_EXT = 34164

MGL_MAP1_TEXTURE_COORD_1 = 3475

MGL_PIXEL_MAP_G_TO_G_SIZE = 3255

MGL_FOG_COORDINATE_EXT = 33873

MGL_MATRIX11 = 35019

MGL_PACK_LSB_FIRST = 3329

MUniformParameter_kSemanticWorldViewInverseTransposeMatrix = 24

MGL_TEXTURE5_ARB = 33989

MGL_RGB_SCALE_EXT = 34163

MGeometryData_kPrimitiveCenter = 10

MGL_FOG_COORDINATE_SOURCE_EXT = 33872

MGL_MAP2_TEXTURE_COORD_4 = 3510

MGL_GPU_MEMORY_INFO_TOTAL_AVAILABLE_MEMORY_NVX = 36936

MGL_SOURCE1_RGB = 34177

MGL_COMPRESSED_RGBA_S3TC_DXT5_EXT = 33779

kMGLext_MGLX_create_pbuffer = 90

MGL_MATRIX9 = 35017

MGL_PROGRAM_ERROR_POSITION_NV = 34379

MGL_SELECTION_BUFFER_SIZE = 3572

MGL_COMBINE_RGB_EXT = 34161

MGL_ALL_COMPLETED_NV = 34034

MGL_OFFSET_TEXTURE_2D_NV = 34536

MGL_COMPRESSED_RGBA_S3TC_DXT3_EXT = 33778

MGL_PIXEL_MAP_S_TO_S = 3185

MGL_MATRIX8 = 35016

MGL_COMBINE_EXT = 34160

MGL_COMPRESSED_RGBA_S3TC_DXT1_EXT = 33777

MGL_E_TIMES_F_NV = 34097

MGL_TEXTURE25_ARB = 34009

MGL_EMBOSS_MAP_NV = 34143

MGL_SECONDARY_INTERPOLATOR_ATI = 35181

MGL_COMPRESSED_RGB_S3TC_DXT1_EXT = 33776

MGL_KEEP = 7680

MGL_MAX_PN_TRIANGLES_TESSELATION_LEVEL_ATI = 34801

MGL_MATRIX6 = 35014

MGL_FRAGMENT_DEPTH_EXT = 33874

MGL_EMBOSS_CONSTANT_NV = 34142

MGL_LERP_ATI = 35177

MGL_REG_15_ATI = 35120

MGL_EMBOSS_LIGHT_NV = 34141

kMGLext_frame_buffer_object = 79

MGL_OP_CROSS_PRODUCT_EXT = 34711

MGL_MAP2_TEXTURE_COORD_3 = 3509

MGL_MATRIX4 = 35012

MGL_PRIMITIVE_RESTART_INDEX_NV = 34137

MGL_STACK_OVERFLOW = 1283

MGL_SINGLE_COLOR = 33273

kMGLext_NV_primitive_restart = 75

MGL_MATRIX3 = 35011

MGL_SIGNED_RGB8_NV = 34559

MGL_VERTEX_PROGRAM_BINDING_NV = 34378

MViewportRenderer_kExcludeNParticles = 536870912

MGL_VIBRANCE_BIAS_NV = 34585

MGL_PRIMITIVE_RESTART_NV = 34136

MGL_LIGHT_MODEL_COLOR_CONTROL = 33272

MGL_MATRIX2 = 35010

MGL_TEXTURE8_ARB = 33992

MGL_STENCIL_INDEX8 = 36168

MGL_REG_19_ATI = 35124

MGL_CULL_VERTEX_OBJECT_POSITION_EXT = 33196

MGL_OUTPUT_TEXTURE_COORD31_EXT = 34748

MGL_MATRIX1 = 35009

MGL_TEXTURE24_ARB = 34008

MGL_COMBINER6_NV = 34134

MGL_OUT_OF_MEMORY = 1285

MGL_CULL_VERTEX_EYE_POSITION_EXT = 33195

MGL_COMBINER5_NV = 34133

MGL_MAD_ATI = 35176

MGL_CULL_VERTEX_EXT = 33194

MGL_VERTEX_ATTRIB_ARRAY3_NV = 34387

MGL_REG_14_ATI = 35119

MGL_COMBINER4_NV = 34132

MGL_SOURCE1_ALPHA_EXT = 34185

MGL_ARRAY_ELEMENT_LOCK_COUNT_EXT = 33193

MGL_MAP2_TEXTURE_COORD_2 = 3508

MGL_FEEDBACK_BUFFER_TYPE = 3570

MGL_TEXTURE_ENV = 8960

MGL_COMBINER3_NV = 34131

MGL_S = 8192

MGL_INVALID_OPERATION = 1282

MGL_ARRAY_ELEMENT_LOCK_FIRST_EXT = 33192

MGL_TEXTURE30 = 34014

MGL_FEEDBACK_BUFFER_SIZE = 3569

MGL_COMBINER2_NV = 34130

MGL_PROGRAM_FORMAT_ASCII = 34933

MGL_FEEDBACK_BUFFER_POINTER = 3568

MGL_COMBINER1_NV = 34129

MGL_SWIZZLE_STR_DR_ATI = 35192

MGL_TEXTURE = 5890

MGL_TEXTURE_COMPARE_FAIL_VALUE_ARB = 32959

MUniformParameter_kSemanticHWSObjectLevel = 52

MGL_CURRENT_MATRIX_STACK_DEPTH = 34368

MGL_LOAD = 257

MGL_COMBINER0_NV = 34128

MGL_TEXTURE_1D = 3552

MGLFunctionTable_kMGL_Version20 = 6

MGL_RGBA_MODE = 3121

MGL_REG_1_ATI = 35106

MGL_CURRENT_MATRIX = 34369

MGL_REG_13_ATI = 35118

MGL_CLIENT_ACTIVE_TEXTURE = 34017

MGL_MULTISAMPLE_BIT_ARB = 536870912

MGL_TEXTURE_COMPARE_OPERATOR_SGIX = 33179

MGL_MAP2_TEXTURE_COORD_1 = 3507

MGL_MAP2_GRID_DOMAIN = 3538

MGL_NEVER = 512

MGL_ACTIVE_TEXTURE = 34016

MGL_TEXTURE_COMPARE_SGIX = 33178

MGL_VERTEX_ATTRIB_ARRAY13_NV = 34397

MGL_TRACK_MATRIX_NV = 34376

MGL_COMBINER_SUM_OUTPUT_NV = 34124

MGL_COMPARE_R_TO_TEXTURE_ARB = 34894

MGL_OFFSET_TEXTURE_2D_SCALE_NV = 34530

MGL_COMBINER_AB_DOT_PRODUCT_NV = 34117

MGL_INCR_WRAP_EXT = 34055

MGL_TEXTURE9 = 33993

MGL_COMBINER_CD_OUTPUT_NV = 34123

MViewportRenderer_kExcludePivots = 16384

MGL_TEXTURE_COMPARE_FUNC_ARB = 34893

kMGLext_WMGL_ARB_buffer_region = 84

MGL_DOT3_RGBA_EXT = 34479

MGL_TEXTURE22_ARB = 34006

MUniformParameter_kSemanticHWSVertexLevel = 55

MGL_TEXTURE27_ARB = 34011

MGL_COMBINER_AB_OUTPUT_NV = 34122

MGL_TRANSFORM_FEEDBACK_PRIMITIVES_WRITTEN_EXT = 35976

MGL_DOT3_RGBA_ARB = 34479

MGL_COMBINER_BIAS_NV = 34121

MGL_DOT3_ATI = 35174

MGL_TEXTURE_CUBE_MAP_POSITIVE_Z_ARB = 34073

MGL_DEPTH_TEXTURE_MODE_ARB = 34891

MGL_DOT3_RGB_EXT = 34478

MGL_REG_12_ATI = 35117

MGL_COMBINER_SCALE_NV = 34120

MGL_TEXTURE_DEPTH_SIZE_ARB = 34890

MGL_SAMPLE_ALPHA_TO_ONE = 32927

MGL_DOT3_RGB_ARB = 34478

MGL_VERTEX_ATTRIB_ARRAY_ENABLED = 34338

MGL_OUTPUT_COLOR1_EXT = 34716

MGL_DEPTH_COMPONENT32_ARB = 33191

MGL_LINE_WIDTH = 2849

MGL_C4UB_V2F = 10786

MGL_COMPRESSED_TEXTURE_FORMATS_ARB = 34467

MGL_T4F_V4F = 10792

MGL_COMBINER_CD_DOT_PRODUCT_NV = 34118

MGL_TEXTURE_DT_SIZE_NV = 34590

MGL_DEPTH_COMPONENT24_ARB = 33190

MGL_COMBINER_COMPONENT_USAGE_NV = 34116

kMGLext_ARB_sync = 63

MViewportRenderer_kExcludeCVs = 131072

MViewportRenderer_kExcludeSelectHandles = 8192

MGL_DEPTH_COMPONENT16_ARB = 33189

MGL_TEXTURE21_ARB = 34005

MGL_COLOR_ARRAY_EXT = 32886

MGL_POINT_DISTANCE_ATTENUATION_ARB = 33065

MGL_OUTPUT_TEXTURE_COORD19_EXT = 34736

MGL_MAP2_INDEX = 3505

MGL_COMBINER_MAPPING_NV = 34115

MGL_REG_29_ATI = 35134

MGL_SAMPLE_ALPHA_TO_COVERAGE_ARB = 32926

MGL_LEFT = 1030

MGL_MAX_VERTEX_SHADER_VARIANTS_EXT = 34758

MGL_MAP2_COLOR_4 = 3504

MGL_DEPTH_RANGE = 2928

MGL_FRAMEBUFFER_INCOMPLETE_DIMENSIONS = 36057

MGL_TEXTURE4_ARB = 33988

MGL_COMBINER_INPUT_NV = 34114

MGL_POLYGON = 9

MGL_REG_5_ATI = 35110

MGL_COMPRESSED_RGBA_ARB = 34030

MGL_INTENSITY32F = 34839

MGL_BIAS_BY_NEGATIVE_ONE_HALF_NV = 34113

MGL_RIGHT = 1031

MGL_INTERLEAVED_ATTRIBS_EXT = 35980

MGL_BLEND_COLOR = 32773

MGL_ACTIVE_VARYINGS_NV = 35969

MUniformParameter_kSemanticProjectionMatrix = 19

MGL_COMPRESSED_RGB_ARB = 34029

MGL_T2F_V3F = 10791

MUniformParameter_kSemanticNormalTexture = 29

MGL_NORMAL_ARRAY_EXT = 32885

MGL_COMPRESSED_INTENSITY_ARB = 34028

MGL_MAX_CLIENT_ATTRIB_STACK_DEPTH = 3387

MGL_TRANSPOSE_COLOR_MATRIX_ARB = 34022

MGL_FUNC_ADD_EXT = 32774

MGL_TRANSFORM_FEEDBACK_BUFFER_MODE_NV = 35967

MGL_POINT_SIZE = 2833

MGL_COMPRESSED_LUMINANCE_ALPHA_ARB = 34027

MGL_COPY = 5379

MGL_SCALE_BY_TWO_NV = 34110

MGL_DOT2_ADD_ATI = 35180

MGL_UNSIGNED_NORMALIZED = 35863

MGL_TRANSFORM_FEEDBACK_ATTRIBS_NV = 35966

MGL_SAMPLES_PASSED_ARB = 35092

MUniformParameter_kSemanticViewProjectionMatrix = 40

MGL_MAP1_TEXTURE_COORD_2 = 3476

MGL_SIGNED_NEGATE_NV = 34109

MGL_UNSIGNED_SHORT = 5123

MGL_GENERIC_ATTRIB_NV = 35965

MGL_TEXTURE_CUBE_MAP_POSITIVE_X = 34069

MGL_TEXTURE_2D_BINDING = 32873

MGL_OPERAND1_RGB_EXT = 34193

MGL_SIGNED_IDENTITY_NV = 34108

MGL_PRIMITIVE_ID_NV = 35964

MGL_VARIANT_VALUE_EXT = 34788

MGL_3D = 1537

MGL_TEXTURE26_ARB = 34010

MGL_DEPENDENT_GB_TEXTURE_2D_NV = 34538

MGL_HALF_BIAS_NEGATE_NV = 34107

MGL_TEXTURE31_ARB = 34015

MGL_MAX_OPTIMIZED_VERTEX_SHADER_VARIANTS_EXT = 34763

MGL_TEXTURE31 = 34015

kMGLext_NV_occlusion_query = 74

MGL_C4F_N3F_V3F = 10790

MViewportRenderer_kExcludeManipulators = 268435456

MGL_TEXTURE_GEN_T = 3169

MGL_HALF_BIAS_NORMAL_NV = 34106

MGL_TEXTURE_BINDING_2D = 32873

MGL_CLIP_DISTANCE_NV = 35962

MGL_VERTEX_ARRAY_EXT = 32884

MGL_VERTEX_ATTRIB_ARRAY1_NV = 34385

MGL_MAP1_COLOR_4 = 3472

MGL_EXPAND_NEGATE_NV = 34105

MGL_RENDERBUFFER_WIDTH = 36162

MGL_TEXTURE_COORD_NV = 35961

MGL_POLYGON_TOKEN = 1795

MGL_OUTPUT_TEXTURE_COORD30_EXT = 34747

MGL_CULL_FRAGMENT_NV = 34535

MGL_TEXTURE19_ARB = 34003

MGL_TEXTURE_3D = 32879

MGL_BACK_SECONDARY_COLOR_NV = 35960

MGL_NAME_STACK_DEPTH = 3440

MGL_TEXTURE_HEIGHT = 4097

MGL_ADD_ATI = 35171

MGL_BACK_PRIMARY_COLOR_NV = 35959

MGL_CLAMP_FRAGMENT_COLOR = 35099

MGL_CONST_EYE_NV = 34533

MGL_REG_9_ATI = 35114

MGL_FRAMEBUFFER_COMPLETE = 36053

MGL_BUFFER_MAP_POINTER_ARB = 35005

MGL_MAP1_VERTEX_4 = 3480

MGL_ACCUM_BLUE_BITS = 3418

MGL_FRAMEBUFFER_ATTACHMENT_TEXTURE_3D_ZOFFSET = 36052

MGL_MAX_OPTIMIZED_VERTEX_SHADER_INSTRUCTIONS_EXT = 34762

MGL_BUFFER_MAPPED_ARB = 35004

MGL_N3F_V3F = 10789

MGL_TEXTURE_CUBE_MAP_NEGATIVE_Y_ARB = 34072

MGL_FRAMEBUFFER_ATTACHMENT_TEXTURE_CUBE_MAP_FACE = 36051

MGL_BUFFER_ACCESS_ARB = 35003

MGL_MAX_OPTIMIZED_VERTEX_SHADER_LOCAL_CONSTANTS_EXT = 34765

MGL_MAX_3D_TEXTURE_SIZE_EXT = 32883

MGL_RED_BITS = 3410

MGL_ACCUM_RED_BITS = 3416

MGL_FRAMEBUFFER_ATTACHMENT_TEXTURE_LEVEL = 36050

MGL_SWIZZLE_STQ_ATI = 35191

MGL_PROJECTION = 5889

MGL_BUFFER_USAGE_ARB = 34661

MUniformParameter_kSemanticHWSPrimitiveCountPerInstance = 51

MGL_OFFSET_TEXTURE_2D_MATRIX_NV = 34529

MGL_LUMINANCE6_ALPHA2 = 32836

MGL_SHININESS = 5633

MGL_FRAMEBUFFER_ATTACHMENT_OBJECT_NAME = 36049

MGL_CULL_MODES_NV = 34528

MGL_VERTEX_ARRAY_SIZE = 32890

MGL_TEXTURE17 = 34001

MGL_MOV_ATI = 35169

MGL_MATRIX23 = 35031

MGL_MAX_PROGRAM_NATIVE_TEX_INDIRECTIONS_ARB = 34832

MGL_LUMINANCE = 6409

MGL_SAMPLE_COVERAGE_INVERT_ARB = 32939

MGL_T = 8193

MGL_WRITE_ONLY_ARB = 35001

MGL_MAP1_VERTEX_3 = 3479

MGL_MAX_VERTEX_TEXTURE_IMAGE_UNITS_ARB = 35660

MGL_TEXTURE_SHADER_NV = 34526

MUniformParameter_kSemanticNearClipPlane = 48

MGL_MAX_VERTEX_SHADER_LOCALS_EXT = 34761

MGL_READ_ONLY_ARB = 35000

MGL_VERTEX_ATTRIB_ARRAY12_NV = 34396

MGL_SHADER_CONSISTENT_NV = 34525

MGL_VERTEX_PROGRAM_TWO_SIDE_NV = 34371

MGL_MAX_RENDERBUFFER_SIZE = 34024

MGL_DYNAMIC_COPY_ARB = 35050

MGL_TEXTURE_DEPTH = 32881

MGL_MAX_3D_TEXTURE_SIZE = 32883

MGL_DSDT_MAG_INTENSITY_NV = 34524

kMGLext_NVX_gpu_memory_info = 77

MGL_INVALID_FRAMEBUFFER_OPERATION = 1286

MGL_DYNAMIC_READ_ARB = 35049

MGL_DEPTH_BIAS = 3359

MGL_PIXEL_MAP_I_TO_R_SIZE = 3250

MGL_MAX_FRAGMENT_UNIFORM_COMPONENTS_ARB = 35657

MUniformParameter_kSemanticNormalizationTexture = 31

MGL_DYNAMIC_DRAW_ARB = 35048

MGL_MAX_TRANSFORM_FEEDBACK_SEPARATE_COMPONENTS_NV = 35968

MGL_VARIABLE_B_NV = 34084

MGL_CON_31_ATI = 35168

MGL_SOURCE3_ALPHA_NV = 34187

MGL_RGBA_UNSIGNED_DOT_PRODUCT_MAPPING_NV = 34521

MGL_RGBA = 6408

MGL_OBJECT_ACTIVE_ATTRIBUTE_MAX_LENGTH_ARB = 35722

MGL_MAP1_TEXTURE_COORD_4 = 3478

MGL_SAMPLE_ALPHA_TO_COVERAGE = 32926

MGL_MAP2_VERTEX_ATTRIB15_4_NV = 34431

MUniformParameter_kSemanticWorldTransposeMatrix = 35

MGL_FUNC_REVERSE_SUBTRACT_EXT = 32779

MGL_MAX_VERTEX_SHADER_LOCAL_CONSTANTS_EXT = 34760

MGL_STATIC_DRAW_ARB = 35044

MGL_PIXEL_MAP_I_TO_R = 3186

MGL_MAP2_VERTEX_ATTRIB14_4_NV = 34430

MGL_OUTPUT_TEXTURE_COORD9_EXT = 34726

MGL_VERTEX_PROGRAM_POINT_SIZE_NV = 34370

MGL_FUNC_REVERSE_SUBTRACT = 32779

MGL_TEXTURE_DS_SIZE_NV = 34589

MGL_COLOR_ARRAY_COUNT_EXT = 32900

MGL_STREAM_COPY_ARB = 35042

MGL_MAP2_VERTEX_ATTRIB13_4_NV = 34429

MGL_SIGNED_RGB_NV = 34558

MGL_STREAM_READ_ARB = 35041

MGL_CURRENT_MATRIX_NV = 34369

MGL_MAP2_VERTEX_ATTRIB12_4_NV = 34428

MGL_TEXTURE_ENV_COLOR = 8705

MGL_FUNC_SUBTRACT = 32778

MGL_TEXTURE_CUBE_MAP_POSITIVE_X_ARB = 34069

MGL_OUTPUT_TEXTURE_COORD18_EXT = 34735

MGL_BLEND_EQUATION_EXT = 32777

MGL_CLIENT_ALL_ATTRIB_BITS = -1

MGL_VERTEX_ATTRIB_ARRAY_BUFFER_BINDING_ARB = 34975

MGL_AND = 5377

MGL_SOURCE0_ALPHA_EXT = 34184

MGL_TEXTURE3_ARB = 33987

MGL_BLEND_EQUATION = 32777

MGL_WEIGHT_ARRAY_BUFFER_BINDING_ARB = 34974

MGL_MAP1_TEXTURE_COORD_3 = 3477

MGL_MAP2_VERTEX_ATTRIB9_4_NV = 34425

MGL_FLOAT_MAT4_ARB = 35676

MGL_PRIMITIVES_GENERATED_EXT = 35975

MGL_FOG_COORDINATE_ARRAY_BUFFER_BINDING_ARB = 34973

MGL_MAP2_VERTEX_ATTRIB8_4_NV = 34424

kMGLext_WMGL_ARB_render_texture = 88

MGL_FLOAT_MAT3_ARB = 35675

MViewportRenderer_kExcludeGrid = 65536

MGL_TEXTURE_WRAP_R = 32882

MGL_MAP2_VERTEX_ATTRIB7_4_NV = 34423

MUniformParameter_kSemanticHWSFrontCCW = 57

MGL_FLOAT_MAT2_ARB = 35674

MGL_TEXTURE15_ARB = 33999

MGL_BOOL_VEC4_ARB = 35673

MGL_TEXTURE_COORD_ARRAY_BUFFER_BINDING_ARB = 34970

MUniformParameter_kSemanticWorldViewProjectionTransposeMatrix = 39

MGL_MAP2_VERTEX_ATTRIB5_4_NV = 34421

MGL_INDEX_ARRAY_BUFFER_BINDING_ARB = 34969

MGL_TEXTURE_BINDING_CUBE_MAP = 34068

MGL_MAP2_VERTEX_ATTRIB4_4_NV = 34420

MGL_ALPHA = 6406

MGL_BOOL_VEC2_ARB = 35671

MGL_COLOR_ARRAY_BUFFER_BINDING_ARB = 34968

MGL_FRAGMENT_SHADER_ATI = 35104

MGL_T2F_C4F_N3F_V3F = 10796

MGL_MAP2_VERTEX_ATTRIB3_4_NV = 34419

MGL_DS_BIAS_NV = 34582

MGL_TRANSFORM_FEEDBACK_BUFFER_BINDING_NV = 35983

MGL_NORMAL_ARRAY_BUFFER_BINDING_ARB = 34967

MGL_V3F = 10785

MGL_EDGE_FLAG_ARRAY = 32889

MGL_VERTEX_ATTRIB_ARRAY0_NV = 34384

MGL_T2F_C3F_V3F = 10794

MGL_HI_BIAS_NV = 34580

MGL_REG_17_ATI = 35122

MGL_ELEMENT_ARRAY_BUFFER_BINDING_ARB = 34965

MGL_MAP2_VERTEX_ATTRIB0_4_NV = 34416

MGL_TEXTURE14_ARB = 33998

MGL_INT_VEC2_ARB = 35667

MGL_OFFSET_TEXTURE_2D_BIAS_NV = 34531

MGL_MAP1_VERTEX_ATTRIB15_4_NV = 34415

MGL_FUNC_SUBTRACT_EXT = 32778

MGL_PIXEL_MAP_B_TO_B_SIZE = 3256

MGL_FLOAT_VEC4_ARB = 35666

MGL_MAP1_VERTEX_ATTRIB14_4_NV = 34414

MGL_MATRIX0_NV = 34352

MGL_BLUE = 6405

MGL_FLOAT_VEC3_ARB = 35665

MGL_CON_18_ATI = 35155

MGL_POINT_FADE_THRESHOLD_SIZE_ARB = 33064

MGL_MAP1_VERTEX_ATTRIB13_4_NV = 34413

MGL_VERTEX_ARRAY_BUFFER_BINDING_ARB = 34966

MGL_MAX_VERTEX_SHADER_INSTRUCTIONS_EXT = 34757

MGL_TEXTURE_RED_TYPE = 35856

MGL_V2F = 10784

MGL_TEXTURE_MATRIX = 2984

MGL_TEXTURE_COORD_ARRAY = 32888

MGL_INDEX_ARRAY_STRIDE = 32902

MGL_HI_SCALE_NV = 34574

kMGLext_NUMBER_OF_EXTENSIONS = 99

MGL_MODELVIEW = 5888

MGL_CLIP_VOLUME_CLIPPING_HINT_EXT = 33008

kMGLext_ATI_meminfo = 66

MUniformParameter_kSemanticHWSPrimitiveBase = 50

MGL_SWIZZLE_STQ_DQ_ATI = 35193

MGL_OBJECT_ACTIVE_UNIFORM_MAX_LENGTH_ARB = 35719

MUniformParameter_kSemanticViewProjectionInverseMatrix = 41

MGL_BGRA_EXT = 32993

MGL_LO_BIAS_NV = 34581

MGL_OBJECT_ACTIVE_UNIFORMS_ARB = 35718

MGL_BGR_EXT = 32992

MGL_COLOR_MATERIAL_PARAMETER = 2902

MGL_OUTPUT_TEXTURE_COORD6_EXT = 34723

MGL_FOG_MODE = 2917

MGL_DSDT8_MAG8_INTENSITY8_NV = 34571

MGL_LOCAL_CONSTANT_VALUE_EXT = 34796

MGL_OUTPUT_TEXTURE_COORD5_EXT = 34722

MGL_DSDT8_MAG8_NV = 34570

MGL_LOCAL_EXT = 34756

MGL_SELECT = 7170

MGL_VERTEX_ATTRIB_ARRAY11_NV = 34395

MGL_MATRIX6_NV = 34358

MGL_DSDT8_NV = 34569

MGL_MULTISAMPLE_ARB = 32925

MGL_SAMPLE_COVERAGE_VALUE_ARB = 32938

MGL_MAP1_VERTEX_ATTRIB7_4_NV = 34407

MGL_CLIP_PLANE4 = 12292

MGL_OUTPUT_TEXTURE_COORD3_EXT = 34720

MGL_BUFFER_SIZE_ARB = 34660

MGL_SAMPLES_ARB = 32937

MGL_OUTPUT_TEXTURE_COORD2_EXT = 34719

MGL_TEXTURE27 = 34011

MGL_DEPTH_SCALE = 3358

MGL_SIGNED_INTENSITY_NV = 34567

MGL_VERTEX_ARRAY_POINTER = 32910

MGL_SAMPLE_BUFFERS_ARB = 32936

MGL_TEXTURE_FLOAT_COMPONENTS_NV = 34956

MGL_TRANSFORM_FEEDBACK_BUFFER_SIZE_EXT = 35973

MGL_3D_COLOR_TEXTURE = 1539

MGL_OUTPUT_TEXTURE_COORD1_EXT = 34718

MGL_SIGNED_ALPHA8_NV = 34566

MGL_TEXTURE_CUBE_MAP_POSITIVE_Y_ARB = 34071

MGL_MAP2_VERTEX_ATTRIB10_4_NV = 34426

MGL_PREVIOUS_EXT = 34168

MGL_NEAREST_MIPMAP_NEAREST = 9984

MGL_SIGNED_ALPHA_NV = 34565

MGL_DEPENDENT_AR_TEXTURE_2D_NV = 34537

MGL_TEXTURE_CUBE_MAP_NEGATIVE_Z_ARB = 34074

MGL_SIGNED_LUMINANCE8_ALPHA8_NV = 34564

MGL_LOCAL_CONSTANT_EXT = 34755

MGL_PROGRAM_ERROR_STRING = 34932

MGL_OUTPUT_COLOR0_EXT = 34715

MGL_TEXTURE_COORD_ARRAY_POINTER = 32914

MGL_SIGNED_LUMINANCE_ALPHA_NV = 34563

MGL_COLOR_ARRAY = 32886

kMGLext_texture_compression_s3tc = 61

MGL_OUTPUT_VERTEX_EXT = 34714

MViewportRenderer_kExcludeTextures = 32768

MGL_FOG_BIT = 128

MGL_EDGE_FLAG_ARRAY_POINTER_EXT = 32915

MGL_OP_MOV_EXT = 34713

MGL_VERTEX_ATTRIB_ARRAY_SIZE = 34339

MGL_TEXTURE26 = 34010

MGL_SIGNED_LUMINANCE_NV = 34561

MGL_TEXTURE_COORD_ARRAY_POINTER_EXT = 32914

MGL_OP_MULTIPLY_MATRIX_EXT = 34712

MGL_MAX_TEXTURE_IMAGE_UNITS_ARB = 34930

MGL_TEXTURE_COORD_ARRAY_COUNT_EXT = 32907

MViewportRenderer_kExcludeDynamics = 512

MGL_INDEX_ARRAY_POINTER_EXT = 32913

MGL_PIXEL_MAP_I_TO_I_SIZE = 3248

MGL_MATRIX29 = 35037

MGL_QUADS = 7

MGL_COLOR_ARRAY_POINTER_EXT = 32912

MGL_COLOR_BUFFER_BIT = 16384

MGL_OP_SUB_EXT = 34710

MGL_COLOR_ATTACHMENT2 = 36066

MGL_SIGNED_RGBA8_NV = 34556

MGL_INVARIANT_EXT = 34754

MGL_NORMAL_ARRAY_POINTER_EXT = 32911

kMGLext_WMGL_ARB_make_current_read = 87

MGL_TEXTURE_BINDING_RECTANGLE = 34038

MGL_SIGNED_RGBA_NV = 34555

MGL_CW = 2304

MGL_VERTEX_ARRAY_POINTER_EXT = 32910

MGL_NORMAL_ARRAY = 32885

MGL_OP_RECIP_EXT = 34708

MGL_TEXTURE_DEPTH_EXT = 32881

MGL_TRANSPOSE_PROJECTION_MATRIX_ARB = 34020

MGL_SIGNED_HILO16_NV = 34554

MGL_EDGE_FLAG_ARRAY_COUNT_EXT = 32909

MGL_VERTEX_ATTRIB_ARRAY7_NV = 34391

MGL_OP_POWER_EXT = 34707

MGL_SIGNED_HILO_NV = 34553

MGL_PROGRAM_STRING_NV = 34344

MGL_FLOAT_RGBA16_NV = 34954

MGL_MAP2_VERTEX_3 = 3511

MGL_HILO16_NV = 34552

MGL_PASS_THROUGH_TOKEN = 1792

MGL_MODELVIEW0_EXT = 5888

MGL_COMBINE_ALPHA_EXT = 34162

MGL_LINEAR_ATTENUATION = 4616

MGL_ACCUM_BUFFER_BIT = 512

MGL_DSDT_MAG_VIB_NV = 34551

MGL_TEXTURE_COORD_ARRAY_STRIDE_EXT = 32906

MGL_ENABLE_BIT = 8192


